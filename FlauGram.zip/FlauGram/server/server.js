'use strict';
// Мини-сервер общего чата. Без зависимостей, нужен только Node.js 18+.
// Запуск: node server.js   (порт: PORT, по умолчанию 8080)

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT) || Number(process.env.SERVER_PORT) || 8080; // SERVER_PORT выдаёт Pterodactyl/Wispbyte
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'messages.jsonl');
const TRUST_PROXY = !!process.env.TRUST_PROXY; // за nginx/Cloudflare: брать IP из X-Forwarded-For
const KEEP = 1000;        // сколько сообщений хранить
const TAIL = 50;          // сколько отдавать новому клиенту
const WAIT_MS = 25000;    // long-poll
const MAX_TEXT = 500;
const MAX_NICK = 20;
const RATE_LIMIT = 8;     // сообщений на IP за 10 секунд

let messages = [];
let nextId = 1;

try {
  const lines = fs.readFileSync(DATA_FILE, 'utf8').split('\n').filter(Boolean);
  for (const l of lines.slice(-KEEP)) {
    try { messages.push(JSON.parse(l)); } catch { /* битая строка */ }
  }
  if (messages.length) nextId = messages[messages.length - 1].id + 1;
  fs.writeFileSync(DATA_FILE, messages.map(m => JSON.stringify(m) + '\n').join(''));
} catch { /* файла ещё нет */ }

const log = fs.createWriteStream(DATA_FILE, { flags: 'a' });
log.on('error', e => console.error('log error:', e.message));

let waiters = [];
const hits = new Map();

function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < 10000);
  if (arr.length >= RATE_LIMIT) { hits.set(ip, arr); return true; }
  arr.push(now);
  hits.set(ip, arr);
  return false;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > 10000) hits.delete(k);
}, 60000).unref();

function clientIp(req) {
  if (TRUST_PROXY) {
    const f = (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (f) return f;
  }
  return req.socket.remoteAddress || '?';
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function payload(list, reset) {
  return { messages: list, last: nextId - 1, reset: !!reset };
}

function cleanNick(s) {
  return String(s || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
}
function cleanText(s) {
  return String(s || '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
}
const len = s => [...s].length;
const cut = (s, n) => [...s].slice(0, n).join('');

function handleMessages(req, res, url) {
  const raw = url.searchParams.get('after');
  const after = raw === null ? NaN : parseInt(raw, 10);

  // первый запрос клиента или сервер перезапущен с чистой историей
  if (Number.isNaN(after) || after < 0) return send(res, 200, payload(messages.slice(-TAIL), false));
  if (after > nextId - 1) return send(res, 200, payload(messages.slice(-TAIL), true));

  const fresh = messages.filter(m => m.id > after);
  if (fresh.length) return send(res, 200, payload(fresh, false));

  const w = { after, res };
  w.timer = setTimeout(() => {
    waiters = waiters.filter(x => x !== w);
    send(res, 200, payload([], false));
  }, WAIT_MS);
  waiters.push(w);
  res.on('close', () => {
    clearTimeout(w.timer);
    waiters = waiters.filter(x => x !== w);
  });
}

function wake() {
  const current = waiters;
  waiters = [];
  for (const w of current) {
    clearTimeout(w.timer);
    send(w.res, 200, payload(messages.filter(m => m.id > w.after), false));
  }
}

function handleSend(req, res) {
  const ip = clientIp(req);
  let size = 0;
  const chunks = [];
  let aborted = false;

  req.on('data', c => {
    size += c.length;
    if (size > 4096) {
      aborted = true;
      send(res, 413, { error: 'too large' });
      req.destroy();
      return;
    }
    chunks.push(c);
  });
  req.on('error', () => {});
  req.on('end', () => {
    if (aborted) return;
    let data;
    try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
    catch { return send(res, 400, { error: 'bad json' }); }

    let nick = cleanNick(data && data.nick);
    let text = cleanText(data && data.text);
    if (len(nick) < 2) return send(res, 400, { error: 'nick too short' });
    if (!text) return send(res, 400, { error: 'empty' });
    if (limited(ip)) return send(res, 429, { error: 'slow down' });

    nick = cut(nick, MAX_NICK);
    text = cut(text, MAX_TEXT);

    const msg = { id: nextId++, nick, text, ts: Date.now() };
    messages.push(msg);
    if (messages.length > KEEP + 200) messages = messages.slice(-KEEP);
    log.write(JSON.stringify(msg) + '\n');
    wake();
    send(res, 200, { ok: true, id: msg.id });
  });
}

const server = http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, 'http://localhost'); }
  catch { return send(res, 400, { error: 'bad url' }); }

  if (req.method === 'GET' && url.pathname === '/messages') return handleMessages(req, res, url);
  if (req.method === 'POST' && url.pathname === '/send') return handleSend(req, res);
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/health')) {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('worldchat ok\n');
  }
  send(res, 404, { error: 'not found' });
});

server.listen(PORT, '0.0.0.0', () => console.log('worldchat server on :' + PORT));
