#!/usr/bin/env python3
"""Мини-сервер общего чата. Только стандартная библиотека, Python 3.8+.

Запуск: python3 server.py   (порт: PORT, по умолчанию 8080)
Протокол тот же, что у server.js, приложение менять не нужно.
"""
import json
import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PORT") or os.environ.get("SERVER_PORT") or "8080")  # SERVER_PORT выдаёт Pterodactyl/Wispbyte
DATA_FILE = os.environ.get(
    "DATA_FILE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "messages.jsonl")
)
TRUST_PROXY = bool(os.environ.get("TRUST_PROXY"))  # за nginx/Cloudflare: IP из X-Forwarded-For
KEEP = 1000        # сколько сообщений хранить
TAIL = 50          # сколько отдавать новому клиенту
WAIT_SEC = 25      # long-poll
MAX_TEXT = 500
MAX_NICK = 20
RATE_LIMIT = 8     # сообщений на IP за 10 секунд

cond = threading.Condition()   # защищает messages / next_id и будит long-poll
messages = []
next_id = 1

hits = {}
hits_lock = threading.Lock()


def load():
    global next_id
    try:
        with open(DATA_FILE, encoding="utf-8") as f:
            lines = [l for l in f.read().split("\n") if l]
    except OSError:
        lines = []
    for l in lines[-KEEP:]:
        try:
            messages.append(json.loads(l))
        except ValueError:
            pass  # битая строка
    if messages:
        next_id = messages[-1]["id"] + 1
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        for m in messages:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")


load()
log = open(DATA_FILE, "a", encoding="utf-8")


def limited(ip):
    now = time.time()
    with hits_lock:
        arr = [t for t in hits.get(ip, []) if now - t < 10]
        if len(arr) >= RATE_LIMIT:
            hits[ip] = arr
            return True
        arr.append(now)
        hits[ip] = arr
        if len(hits) > 10000:  # чистка старых адресов
            for k in [k for k, v in hits.items() if not v or now - v[-1] > 10]:
                del hits[k]
        return False


def clean_nick(s):
    s = re.sub(r"[\x00-\x1f\x7f]", " ", str(s or ""))
    return re.sub(r"\s+", " ", s).strip()


def clean_text(s):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str(s or "")).strip()


class Handler(BaseHTTPRequestHandler):
    server_version = "worldchat"

    def log_message(self, *args):
        pass

    def client_ip(self):
        if TRUST_PROXY:
            fwd = (self.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
            if fwd:
                return fwd
        return self.client_address[0]

    def reply(self, code, obj, ctype="application/json; charset=utf-8"):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def payload(self, lst, reset=False):
        return {"messages": lst, "last": next_id - 1, "reset": reset}

    def do_GET(self):
        url = urlparse(self.path)
        if url.path in ("/", "/health"):
            return self.reply(200, b"worldchat ok\n", "text/plain; charset=utf-8")
        if url.path != "/messages":
            return self.reply(404, {"error": "not found"})

        raw = parse_qs(url.query).get("after", [None])[0]
        try:
            after = int(raw) if raw is not None else -1
        except ValueError:
            after = -1

        with cond:
            # первый запрос клиента
            if after < 0:
                return self.reply(200, self.payload(messages[-TAIL:]))
            # сервер перезапущен с чистой историей
            if after > next_id - 1:
                return self.reply(200, self.payload(messages[-TAIL:], True))
            if next_id - 1 <= after:
                cond.wait_for(lambda: next_id - 1 > after, timeout=WAIT_SEC)
            fresh = [m for m in messages if m["id"] > after]
            data = self.payload(fresh)
        self.reply(200, data)

    def do_POST(self):
        global next_id, messages
        if urlparse(self.path).path != "/send":
            return self.reply(404, {"error": "not found"})

        try:
            size = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            size = 0
        if size <= 0 or size > 4096:
            return self.reply(413 if size > 4096 else 400, {"error": "bad size"})
        try:
            data = json.loads(self.rfile.read(size).decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError
        except ValueError:
            return self.reply(400, {"error": "bad json"})

        nick = clean_nick(data.get("nick"))
        text = clean_text(data.get("text"))
        if len(nick) < 2:
            return self.reply(400, {"error": "nick too short"})
        if not text:
            return self.reply(400, {"error": "empty"})
        if limited(self.client_ip()):
            return self.reply(429, {"error": "slow down"})

        with cond:
            msg = {"id": next_id, "nick": nick[:MAX_NICK], "text": text[:MAX_TEXT], "ts": int(time.time() * 1000)}
            next_id += 1
            messages.append(msg)
            if len(messages) > KEEP + 200:
                messages = messages[-KEEP:]
            log.write(json.dumps(msg, ensure_ascii=False) + "\n")
            log.flush()
            cond.notify_all()
        self.reply(200, {"ok": True, "id": msg["id"]})


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128


if __name__ == "__main__":
    print("worldchat server on :%d" % PORT, flush=True)
    try:
        Server(("0.0.0.0", PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        pass
