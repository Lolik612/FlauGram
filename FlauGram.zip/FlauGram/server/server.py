#!/usr/bin/env python3
"""FlauGram: сервер личных сообщений. Только стандартная библиотека, Python 3.8+.

Запуск: python3 server.py   (порт берётся из PORT или SERVER_PORT, иначе 8080)
Данные лежат в flaugram.db (SQLite) рядом со скриптом.
"""
import hashlib
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PORT") or os.environ.get("SERVER_PORT") or "8080")
HERE = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.environ.get("DB_FILE", os.path.join(HERE, "flaugram.db"))
TRUST_PROXY = bool(os.environ.get("TRUST_PROXY"))  # за nginx/Cloudflare: IP из X-Forwarded-For
WAIT_SEC = 25          # long-poll
MAX_TEXT = 1000
NAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  username_lc TEXT NOT NULL UNIQUE,
  token_hash TEXT NOT NULL UNIQUE,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_id INTEGER NOT NULL,
  to_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  reply_to INTEGER,
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS msg_to ON messages(to_id, id);
CREATE INDEX IF NOT EXISTS msg_from ON messages(from_id, id);
CREATE TABLE IF NOT EXISTS reads(
  user_id INTEGER NOT NULL,
  peer_id INTEGER NOT NULL,
  last_id INTEGER NOT NULL,
  PRIMARY KEY(user_id, peer_id)
);
"""

# cond одновременно защищает базу (одно соединение на все потоки) и будит long-poll.
# Это RLock внутри, поэтому вложенные with cond безопасны.
cond = threading.Condition()
db = sqlite3.connect(DB_FILE, check_same_thread=False, isolation_level=None)
db.row_factory = sqlite3.Row
db.executescript(SCHEMA)

hits = {}
hits_lock = threading.Lock()


def limited(key, limit, window):
    """True, если ключ превысил limit событий за window секунд."""
    now = time.time()
    with hits_lock:
        arr = [t for t in hits.get(key, []) if now - t < window]
        if len(arr) >= limit:
            hits[key] = arr
            return True
        arr.append(now)
        hits[key] = arr
        if len(hits) > 20000:
            for k in [k for k, v in hits.items() if not v or now - v[-1] > 3600]:
                del hits[k]
        return False


def now_ms():
    return int(time.time() * 1000)


def sha(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def clean_text(s):
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str(s or "")).strip()
    return s[:MAX_TEXT]


def norm_name(s):
    return str(s or "").strip().lstrip("@")


def user_by_name(name):
    return db.execute("SELECT * FROM users WHERE username_lc=?", (norm_name(name).lower(),)).fetchone()


MSG_SQL = """
SELECT m.id, uf.username AS frm, ut.username AS too, m.text, m.ts,
       r.id AS rid, ru.username AS rfrm, r.text AS rtext
FROM messages m
JOIN users uf ON uf.id = m.from_id
JOIN users ut ON ut.id = m.to_id
LEFT JOIN messages r ON r.id = m.reply_to
LEFT JOIN users ru ON ru.id = r.from_id
"""


def msg_obj(r):
    o = {"id": r["id"], "from": r["frm"], "to": r["too"], "text": r["text"], "ts": r["ts"], "reply": None}
    if r["rid"] is not None:
        o["reply"] = {"id": r["rid"], "from": r["rfrm"], "text": (r["rtext"] or "")[:120]}
    return o


def set_read(me_id, peer_id, upto):
    db.execute(
        "INSERT INTO reads(user_id, peer_id, last_id) VALUES(?,?,?) "
        "ON CONFLICT(user_id, peer_id) DO UPDATE SET last_id = MAX(last_id, excluded.last_id)",
        (me_id, peer_id, upto),
    )


def to_int(v, default=None):
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except (TypeError, ValueError):
        return default


class Handler(BaseHTTPRequestHandler):
    server_version = "flaugram"

    def log_message(self, *args):
        pass

    # ---------- вспомогательное ----------

    def client_ip(self):
        if TRUST_PROXY:
            fwd = (self.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
            if fwd:
                return fwd
        return self.client_address[0]

    def reply(self, code, obj, ctype="application/json; charset=utf-8"):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def auth(self):
        h = self.headers.get("Authorization") or ""
        if not h.startswith("Bearer "):
            return None
        tok = h[7:].strip()
        if not tok or len(tok) > 200:
            return None
        with cond:
            return db.execute("SELECT * FROM users WHERE token_hash=?", (sha(tok),)).fetchone()

    def read_json(self):
        size = to_int(self.headers.get("Content-Length"), 0)
        if size <= 0 or size > 8192:
            return None
        try:
            d = json.loads(self.rfile.read(size).decode("utf-8"))
        except ValueError:
            return None
        return d if isinstance(d, dict) else None

    # ---------- GET ----------

    def do_GET(self):
        url = urlparse(self.path)
        path = url.path
        if path in ("/", "/health"):
            return self.reply(200, b"flaugram ok\n", "text/plain; charset=utf-8")
        routes = {
            "/me": self.get_me,
            "/search": self.get_search,
            "/dialogs": self.get_dialogs,
            "/history": self.get_history,
            "/updates": self.get_updates,
        }
        fn = routes.get(path)
        if fn is None:
            return self.reply(404, {"error": "not found"})
        me = self.auth()
        if me is None:
            return self.reply(401, {"error": "unauthorized"})
        fn(me, parse_qs(url.query))

    def get_me(self, me, qs):
        self.reply(200, {"id": me["id"], "username": me["username"]})

    def get_search(self, me, qs):
        q = norm_name((qs.get("q") or [""])[0]).lower()[:20]
        if not q:
            return self.reply(200, {"users": []})
        with cond:
            rows = db.execute(
                "SELECT username FROM users WHERE id != ? AND instr(username_lc, ?) > 0 "
                "ORDER BY (instr(username_lc, ?) = 1) DESC, length(username_lc), username_lc LIMIT 20",
                (me["id"], q, q),
            ).fetchall()
        self.reply(200, {"users": [r["username"] for r in rows]})

    def get_dialogs(self, me, qs):
        with cond:
            rows = db.execute(
                """
                WITH conv AS (
                  SELECT CASE WHEN from_id = :me THEN to_id ELSE from_id END AS peer, MAX(id) AS last_id
                  FROM messages WHERE from_id = :me OR to_id = :me GROUP BY peer
                )
                SELECT u.username AS username, m.text AS text, m.ts AS ts, (m.from_id = :me) AS mine,
                       (SELECT COUNT(*) FROM messages x
                         WHERE x.from_id = conv.peer AND x.to_id = :me
                           AND x.id > COALESCE((SELECT last_id FROM reads
                                                WHERE user_id = :me AND peer_id = conv.peer), 0)) AS unread
                FROM conv
                JOIN messages m ON m.id = conv.last_id
                JOIN users u ON u.id = conv.peer
                ORDER BY m.id DESC
                """,
                {"me": me["id"]},
            ).fetchall()
        out = [
            {"user": r["username"], "text": r["text"][:120], "ts": r["ts"], "mine": bool(r["mine"]), "unread": r["unread"]}
            for r in rows
        ]
        self.reply(200, {"dialogs": out})

    def get_history(self, me, qs):
        peer_name = (qs.get("with") or [""])[0]
        limit = min(max(to_int((qs.get("limit") or ["50"])[0], 50), 1), 200)
        before = to_int((qs.get("before") or [None])[0])
        with cond:
            peer = user_by_name(peer_name)
            if peer is None:
                return self.reply(404, {"error": "no such user"})
            sql = MSG_SQL + "WHERE ((m.from_id=? AND m.to_id=?) OR (m.from_id=? AND m.to_id=?)) "
            params = [me["id"], peer["id"], peer["id"], me["id"]]
            if before is not None:
                sql += "AND m.id < ? "
                params.append(before)
            sql += "ORDER BY m.id DESC LIMIT ?"
            params.append(limit)
            rows = db.execute(sql, params).fetchall()
            if before is None:
                top = db.execute(
                    "SELECT COALESCE(MAX(id), 0) FROM messages WHERE from_id=? AND to_id=?", (peer["id"], me["id"])
                ).fetchone()[0]
                if top:
                    set_read(me["id"], peer["id"], top)
        rows.reverse()
        self.reply(200, {"messages": [msg_obj(r) for r in rows], "with": peer["username"]})

    def get_updates(self, me, qs):
        uid = me["id"]
        after = to_int((qs.get("after") or [None])[0])
        with cond:
            maxid = db.execute("SELECT COALESCE(MAX(id), 0) FROM messages").fetchone()[0]
            if after is None or after < 0:
                data = {"messages": [], "last": maxid, "reset": False}   # «начать с текущего момента»
            elif after > maxid:
                data = {"messages": [], "last": maxid, "reset": True}    # база была очищена
            else:
                def has_new():
                    return db.execute(
                        "SELECT 1 FROM messages WHERE id > ? AND (to_id = ? OR from_id = ?) LIMIT 1", (after, uid, uid)
                    ).fetchone() is not None

                if not has_new():
                    cond.wait_for(has_new, timeout=WAIT_SEC)
                rows = db.execute(
                    MSG_SQL + "WHERE m.id > ? AND (m.to_id = ? OR m.from_id = ?) ORDER BY m.id LIMIT 200",
                    (after, uid, uid),
                ).fetchall()
                data = {
                    "messages": [msg_obj(r) for r in rows],
                    "last": rows[-1]["id"] if rows else after,
                    "reset": False,
                }
        self.reply(200, data)

    # ---------- POST ----------

    def do_POST(self):
        path = urlparse(self.path).path
        if path not in ("/register", "/send", "/read"):
            return self.reply(404, {"error": "not found"})
        if path == "/register":
            return self.post_register()
        me = self.auth()
        if me is None:
            return self.reply(401, {"error": "unauthorized"})
        return self.post_send(me) if path == "/send" else self.post_read(me)

    def post_register(self):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        name = norm_name(d.get("username"))
        if not NAME_RE.match(name):
            return self.reply(400, {"error": "bad username"})
        if limited(("reg", self.client_ip()), 20, 3600):
            return self.reply(429, {"error": "slow down"})
        token = secrets.token_urlsafe(32)
        try:
            with cond:
                cur = db.execute(
                    "INSERT INTO users(username, username_lc, token_hash, created) VALUES(?,?,?,?)",
                    (name, name.lower(), sha(token), now_ms()),
                )
                uid = cur.lastrowid
        except sqlite3.IntegrityError:
            return self.reply(409, {"error": "taken"})
        self.reply(200, {"token": token, "username": name, "id": uid})

    def post_send(self, me):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        text = clean_text(d.get("text"))
        if not text:
            return self.reply(400, {"error": "empty"})
        if limited(("send", me["id"]), 10, 10):
            return self.reply(429, {"error": "slow down"})
        with cond:
            peer = user_by_name(d.get("to"))
            if peer is None:
                return self.reply(404, {"error": "no such user"})
            if peer["id"] == me["id"]:
                return self.reply(400, {"error": "self"})
            reply_to = None
            rid = to_int(d.get("reply_to"))
            if rid is not None:
                ok = db.execute(
                    "SELECT 1 FROM messages WHERE id=? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?))",
                    (rid, me["id"], peer["id"], peer["id"], me["id"]),
                ).fetchone()
                if ok:
                    reply_to = rid
            cur = db.execute(
                "INSERT INTO messages(from_id, to_id, text, reply_to, ts) VALUES(?,?,?,?,?)",
                (me["id"], peer["id"], text, reply_to, now_ms()),
            )
            row = db.execute(MSG_SQL + "WHERE m.id = ?", (cur.lastrowid,)).fetchone()
            data = {"ok": True, "message": msg_obj(row)}
            cond.notify_all()
        self.reply(200, data)

    def post_read(self, me):
        d = self.read_json()
        upto = to_int(d.get("upto")) if d else None
        if d is None or upto is None:
            return self.reply(400, {"error": "bad request"})
        with cond:
            peer = user_by_name(d.get("with"))
            if peer is None:
                return self.reply(404, {"error": "no such user"})
            set_read(me["id"], peer["id"], max(upto, 0))
        self.reply(200, {"ok": True})


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128


if __name__ == "__main__":
    print("flaugram server on :%d (db: %s)" % (PORT, DB_FILE), flush=True)
    try:
        Server(("0.0.0.0", PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        pass
