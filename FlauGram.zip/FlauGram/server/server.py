#!/usr/bin/env python3
"""FlauGram: сервер личных сообщений. Только стандартная библиотека, Python 3.8+.

Запуск: python3 server.py   (порт берётся из PORT или SERVER_PORT, иначе 8080)
Данные: flaugram.db (SQLite) и папка media/ (фото и аватарки) рядом со скриптом.
"""
import hashlib
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PORT") or os.environ.get("SERVER_PORT") or "8080")
HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR", HERE)
DB_FILE = os.environ.get("DB_FILE", os.path.join(DATA_DIR, "flaugram.db"))
MEDIA_DIR = os.environ.get("MEDIA_DIR", os.path.join(DATA_DIR, "media"))
TRUST_PROXY = bool(os.environ.get("TRUST_PROXY"))  # за nginx/Cloudflare: IP из X-Forwarded-For
WAIT_SEC = 25              # long-poll
MAX_TEXT = 1000
MAX_NAME = 32              # отображаемое имя
MAX_BIO = 200              # описание профиля
MAX_PHOTO = 6 * 1024 * 1024
MAX_AVATAR = 1024 * 1024
OWNER = (os.environ.get("OWNER_USERNAME") or "ofernote").strip().lower()   # аккаунт с галочкой
MAX_CHATS = 20             # сколько групп и каналов может создать один человек
NAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
MEDIA_RE = re.compile(r"^[0-9a-f]{32}\.(jpg|png)$")

os.makedirs(MEDIA_DIR, exist_ok=True)

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  username_lc TEXT NOT NULL UNIQUE,
  token_hash TEXT NOT NULL UNIQUE,
  created INTEGER NOT NULL,
  display_name TEXT NOT NULL DEFAULT '',
  display_lc TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  avatar INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_id INTEGER NOT NULL,
  to_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  reply_to INTEGER,
  ts INTEGER NOT NULL,
  photo TEXT,
  pw INTEGER NOT NULL DEFAULT 0,
  ph INTEGER NOT NULL DEFAULT 0,
  chat_id INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS chats(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  title_lc TEXT NOT NULL,
  bio TEXT NOT NULL DEFAULT '',
  avatar INTEGER NOT NULL DEFAULT 0,
  owner_id INTEGER NOT NULL,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS members(
  chat_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  joined INTEGER NOT NULL,
  PRIMARY KEY(chat_id, user_id)
);
CREATE INDEX IF NOT EXISTS members_user ON members(user_id);
CREATE INDEX IF NOT EXISTS msg_to ON messages(to_id, id);
CREATE INDEX IF NOT EXISTS msg_from ON messages(from_id, id);
CREATE TABLE IF NOT EXISTS reads(
  user_id INTEGER NOT NULL,
  peer_id INTEGER NOT NULL,
  last_id INTEGER NOT NULL,
  PRIMARY KEY(user_id, peer_id)
);
"""

# cond одновременно защищает базу (одно соединение на все потоки) и будит long-poll.
# Это RLock внутри, поэтому вложенные with cond безопасны.
cond = threading.Condition()
db = sqlite3.connect(DB_FILE, check_same_thread=False, isolation_level=None)
db.row_factory = sqlite3.Row
db.executescript(SCHEMA)


def migrate():
    """Старая база (до профилей и фото) получает недостающие колонки."""
    want = {
        "users": [
            ("display_name", "TEXT NOT NULL DEFAULT ''"),
            ("display_lc", "TEXT NOT NULL DEFAULT ''"),
            ("bio", "TEXT NOT NULL DEFAULT ''"),
            ("avatar", "INTEGER NOT NULL DEFAULT 0"),
        ],
        "messages": [
            ("photo", "TEXT"),
            ("pw", "INTEGER NOT NULL DEFAULT 0"),
            ("ph", "INTEGER NOT NULL DEFAULT 0"),
            ("chat_id", "INTEGER NOT NULL DEFAULT 0"),
        ],
    }
    for table, cols in want.items():
        have = {r["name"] for r in db.execute("PRAGMA table_info(%s)" % table)}
        for name, ddl in cols:
            if name not in have:
                db.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, name, ddl))
    db.execute("UPDATE users SET display_lc = username_lc WHERE display_lc = ''")
    db.execute("CREATE INDEX IF NOT EXISTS msg_chat ON messages(chat_id, id)")


migrate()

hits = {}
hits_lock = threading.Lock()


def limited(key, limit, window):
    """True, если ключ превысил limit событий за window секунд."""
    now = time.time()
    with hits_lock:
        arr = [t for t in hits.get(key, []) if now - t < window]
        if len(arr) >= limit:
            hits[key] = arr
            return True
        arr.append(now)
        hits[key] = arr
        if len(hits) > 20000:
            for k in [k for k, v in hits.items() if not v or now - v[-1] > 3600]:
                del hits[k]
        return False


def now_ms():
    return int(time.time() * 1000)


def sha(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def clean_text(s):
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str(s or "")).strip()
    return s[:MAX_TEXT]


def clean_name(s):
    s = re.sub(r"[\x00-\x1f\x7f]", " ", str(s or ""))
    return re.sub(r"\s+", " ", s).strip()[:MAX_NAME].strip()


def clean_bio(s):
    s = re.sub(r"[\x00-\x09\x0b\x0c\x0e-\x1f\x7f]", "", str(s or ""))
    s = re.sub(r"\n{3,}", "\n\n", s.replace("\r", ""))
    return s.strip()[:MAX_BIO].strip()


def norm_name(s):
    return str(s or "").strip().lstrip("@")


def to_int(v, default=None):
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except (TypeError, ValueError):
        return default


def dname(row):
    return row["display_name"] or row["username"]


def user_obj(row):
    return {
        "username": row["username"],
        "display_name": dname(row),
        "bio": row["bio"],
        "avatar": row["avatar"],
        "verified": row["username"].lower() == OWNER,
    }


def user_by_name(name):
    return db.execute("SELECT * FROM users WHERE username_lc=?", (norm_name(name).lower(),)).fetchone()


def get_chat(cid):
    return db.execute("SELECT * FROM chats WHERE id=?", (cid,)).fetchone()


def is_member(cid, uid):
    return db.execute("SELECT 1 FROM members WHERE chat_id=? AND user_id=?", (cid, uid)).fetchone() is not None


def chat_obj(c, uid):
    n = db.execute("SELECT COUNT(*) FROM members WHERE chat_id=?", (c["id"],)).fetchone()[0]
    return {
        "id": c["id"],
        "kind": c["kind"],
        "title": c["title"],
        "bio": c["bio"],
        "avatar": c["avatar"],
        "members": n,
        "member": is_member(c["id"], uid),
        "owner": c["owner_id"] == uid,
    }


def chat_avatar_path(cid):
    return os.path.join(MEDIA_DIR, "chat_%d.img" % cid)


def sniff(data):
    """Тип картинки по первым байтам: 'jpg', 'png' или None."""
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    return None


MSG_SQL = """
SELECT m.id, uf.username AS frm, uf.display_name AS frm_name, uf.avatar AS frm_av,
       ut.username AS too, m.text, m.ts, m.photo, m.pw, m.ph, m.chat_id, c.title AS chat_title,
       r.id AS rid, ru.username AS rfrm, ru.display_name AS rname, r.text AS rtext, r.photo AS rphoto
FROM messages m
JOIN users uf ON uf.id = m.from_id
LEFT JOIN users ut ON ut.id = m.to_id
LEFT JOIN chats c ON c.id = m.chat_id
LEFT JOIN messages r ON r.id = m.reply_to
LEFT JOIN users ru ON ru.id = r.from_id
"""


def msg_obj(r):
    o = {
        "id": r["id"],
        "from": r["frm"],
        "from_name": r["frm_name"] or r["frm"],
        "from_avatar": r["frm_av"],
        "from_verified": r["frm"].lower() == OWNER,
        "chat": r["chat_id"],
        "chat_title": r["chat_title"] or "",
        "to": r["too"] or "",
        "text": r["text"],
        "ts": r["ts"],
        "photo": r["photo"],
        "w": r["pw"],
        "h": r["ph"],
        "reply": None,
    }
    if r["rid"] is not None:
        o["reply"] = {
            "id": r["rid"],
            "from": r["rfrm"],
            "from_name": r["rname"] or r["rfrm"],
            "text": (r["rtext"] or "")[:120],
            "photo": bool(r["rphoto"]),
        }
    return o


def set_read(me_id, peer_id, upto):
    db.execute(
        "INSERT INTO reads(user_id, peer_id, last_id) VALUES(?,?,?) "
        "ON CONFLICT(user_id, peer_id) DO UPDATE SET last_id = MAX(last_id, excluded.last_id)",
        (me_id, peer_id, upto),
    )


def avatar_path(uid):
    return os.path.join(MEDIA_DIR, "avatar_%d.img" % uid)


def write_file(path, data):
    tmp = path + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


class Handler(BaseHTTPRequestHandler):
    server_version = "flaugram"

    def log_message(self, *args):
        pass

    # ---------- вспомогательное ----------

    def client_ip(self):
        if TRUST_PROXY:
            fwd = (self.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
            if fwd:
                return fwd
        return self.client_address[0]

    def reply(self, code, obj, ctype="application/json; charset=utf-8"):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_file(self, path, ctype, cache="no-store"):
        try:
            size = os.path.getsize(path)
            f = open(path, "rb")
        except OSError:
            return self.reply(404, {"error": "not found"})
        try:
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", cache)
            self.end_headers()
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            f.close()

    def auth(self):
        h = self.headers.get("Authorization") or ""
        if not h.startswith("Bearer "):
            return None
        tok = h[7:].strip()
        if not tok or len(tok) > 200:
            return None
        with cond:
            return db.execute("SELECT * FROM users WHERE token_hash=?", (sha(tok),)).fetchone()

    def read_json(self):
        size = to_int(self.headers.get("Content-Length"), 0)
        if size <= 0 or size > 8192:
            return None
        try:
            d = json.loads(self.rfile.read(size).decode("utf-8"))
        except ValueError:
            return None
        return d if isinstance(d, dict) else None

    def body(self, limit):
        """Сырое тело запроса (картинка). При ошибке сам отвечает и возвращает None."""
        size = to_int(self.headers.get("Content-Length"), 0)
        if size <= 0:
            self.reply(400, {"error": "empty body"})
            return None
        if size > limit:
            self.close_connection = True
            self.reply(413, {"error": "too large"})
            return None
        data = self.rfile.read(size)
        if len(data) != size:
            self.reply(400, {"error": "short body"})
            return None
        return data

    # ---------- GET ----------

    def do_GET(self):
        url = urlparse(self.path)
        path = url.path
        if path in ("/", "/health"):
            return self.reply(200, b"flaugram ok\n", "text/plain; charset=utf-8")
        routes = {
            "/me": self.get_me,
            "/user": self.get_user,
            "/search": self.get_search,
            "/dialogs": self.get_dialogs,
            "/history": self.get_history,
            "/updates": self.get_updates,
            "/avatar": self.get_avatar,
            "/chat": self.get_chat_info,
            "/chat/members": self.get_chat_members,
            "/chat/avatar": self.get_chat_avatar,
        }
        fn = routes.get(path)
        if fn is None and not path.startswith("/media/"):
            return self.reply(404, {"error": "not found"})
        me = self.auth()
        if me is None:
            return self.reply(401, {"error": "unauthorized"})
        if fn is None:
            return self.get_media(me, path[len("/media/"):])
        fn(me, parse_qs(url.query))

    def get_me(self, me, qs):
        o = user_obj(me)
        o["id"] = me["id"]
        self.reply(200, o)

    def get_user(self, me, qs):
        with cond:
            u = user_by_name((qs.get("name") or [""])[0])
        if u is None:
            return self.reply(404, {"error": "no such user"})
        self.reply(200, user_obj(u))

    def get_search(self, me, qs):
        q = norm_name((qs.get("q") or [""])[0]).lower()[:MAX_NAME]
        if not q:
            return self.reply(200, {"users": [], "chats": []})
        with cond:
            rows = db.execute(
                "SELECT * FROM users WHERE id != ? AND (instr(username_lc, ?) > 0 OR instr(display_lc, ?) > 0) "
                "ORDER BY (instr(username_lc, ?) = 1) DESC, (instr(display_lc, ?) = 1) DESC, "
                "length(username_lc), username_lc LIMIT 20",
                (me["id"], q, q, q, q),
            ).fetchall()
            chats = db.execute(
                "SELECT * FROM chats WHERE instr(title_lc, ?) > 0 "
                "ORDER BY (instr(title_lc, ?) = 1) DESC, length(title_lc), id LIMIT 10",
                (q, q),
            ).fetchall()
            chats = [chat_obj(c, me["id"]) for c in chats]
        self.reply(200, {"users": [user_obj(r) for r in rows], "chats": chats})

    def get_dialogs(self, me, qs):
        with cond:
            rows = db.execute(
                """
                WITH conv AS (
                  SELECT CASE WHEN from_id = :me THEN to_id ELSE from_id END AS peer, MAX(id) AS last_id
                  FROM messages WHERE from_id = :me OR to_id = :me GROUP BY peer
                )
                SELECT u.username AS username, u.display_name AS display_name, u.bio AS bio, u.avatar AS avatar,
                       m.text AS text, m.ts AS ts, (m.from_id = :me) AS mine, (m.photo IS NOT NULL) AS photo,
                       (SELECT COUNT(*) FROM messages x
                         WHERE x.from_id = conv.peer AND x.to_id = :me
                           AND x.id > COALESCE((SELECT last_id FROM reads
                                                WHERE user_id = :me AND peer_id = conv.peer), 0)) AS unread
                FROM conv
                JOIN messages m ON m.id = conv.last_id
                JOIN users u ON u.id = conv.peer
                ORDER BY m.id DESC
                """,
                {"me": me["id"]},
            ).fetchall()
        out = []
        for r in rows:
            out.append({
                "user": r["username"],
                "display_name": r["display_name"] or r["username"],
                "bio": r["bio"],
                "avatar": r["avatar"],
                "text": r["text"][:120],
                "ts": r["ts"],
                "mine": bool(r["mine"]),
                "photo": bool(r["photo"]),
                "unread": r["unread"],
                "kind": "user",
                "chat": 0,
                "verified": r["username"].lower() == OWNER,
            })
        with cond:
            crows = db.execute(
                "SELECT c.* FROM chats c JOIN members mb ON mb.chat_id = c.id AND mb.user_id = ?", (me["id"],)
            ).fetchall()
            for c in crows:
                last = db.execute(
                    "SELECT m.text, m.ts, m.photo, m.from_id, u.display_name AS dn, u.username AS un "
                    "FROM messages m JOIN users u ON u.id = m.from_id WHERE m.chat_id = ? ORDER BY m.id DESC LIMIT 1",
                    (c["id"],),
                ).fetchone()
                unread = db.execute(
                    "SELECT COUNT(*) FROM messages WHERE chat_id = ? AND from_id != ? AND id > "
                    "COALESCE((SELECT last_id FROM reads WHERE user_id = ? AND peer_id = ?), 0)",
                    (c["id"], me["id"], me["id"], -c["id"]),
                ).fetchone()[0]
                out.append({
                    "user": "",
                    "display_name": c["title"],
                    "bio": c["bio"],
                    "avatar": c["avatar"],
                    "text": (last["text"] if last else "")[:120],
                    "ts": last["ts"] if last else c["created"],
                    "mine": bool(last and last["from_id"] == me["id"]),
                    "photo": bool(last and last["photo"]),
                    "unread": unread,
                    "kind": c["kind"],
                    "chat": c["id"],
                    "sender": (last["dn"] or last["un"]) if last else "",
                    "verified": False,
                })
        out.sort(key=lambda d: d["ts"], reverse=True)
        self.reply(200, {"dialogs": out})

    def get_history(self, me, qs):
        peer_name = (qs.get("with") or [""])[0]
        limit = min(max(to_int((qs.get("limit") or ["50"])[0], 50), 1), 200)
        before = to_int((qs.get("before") or [None])[0])
        cid = to_int((qs.get("chat") or [None])[0])
        with cond:
            if cid:
                c = get_chat(cid)
                if c is None:
                    return self.reply(404, {"error": "no such chat"})
                if not is_member(cid, me["id"]):
                    return self.reply(403, {"error": "not a member"})
                peer = None
                sql = MSG_SQL + "WHERE m.chat_id=? "
                params = [cid]
            else:
                peer = user_by_name(peer_name)
                if peer is None:
                    return self.reply(404, {"error": "no such user"})
                sql = MSG_SQL + "WHERE ((m.from_id=? AND m.to_id=?) OR (m.from_id=? AND m.to_id=?)) "
                params = [me["id"], peer["id"], peer["id"], me["id"]]
            if before is not None:
                sql += "AND m.id < ? "
                params.append(before)
            sql += "ORDER BY m.id DESC LIMIT ?"
            params.append(limit)
            rows = db.execute(sql, params).fetchall()
            if before is None:
                if cid:
                    top = db.execute("SELECT COALESCE(MAX(id), 0) FROM messages WHERE chat_id=?", (cid,)).fetchone()[0]
                    if top:
                        set_read(me["id"], -cid, top)
                else:
                    top = db.execute(
                        "SELECT COALESCE(MAX(id), 0) FROM messages WHERE from_id=? AND to_id=?", (peer["id"], me["id"])
                    ).fetchone()[0]
                    if top:
                        set_read(me["id"], peer["id"], top)
        rows.reverse()
        self.reply(200, {"messages": [msg_obj(r) for r in rows], "with": peer["username"] if peer else ""})

    def get_updates(self, me, qs):
        uid = me["id"]
        after = to_int((qs.get("after") or [None])[0])
        with cond:
            maxid = db.execute("SELECT COALESCE(MAX(id), 0) FROM messages").fetchone()[0]
            if after is None or after < 0:
                data = {"messages": [], "last": maxid, "reset": False}   # «начать с текущего момента»
            elif after > maxid:
                data = {"messages": [], "last": maxid, "reset": True}    # база была очищена
            else:
                def has_new():
                    return db.execute(
                        "SELECT 1 FROM messages WHERE id > ? AND (to_id = ? OR from_id = ? "
                        "OR chat_id IN (SELECT chat_id FROM members WHERE user_id = ?)) LIMIT 1",
                        (after, uid, uid, uid),
                    ).fetchone() is not None

                if not has_new():
                    cond.wait_for(has_new, timeout=WAIT_SEC)
                rows = db.execute(
                    MSG_SQL + "WHERE m.id > ? AND (m.to_id = ? OR m.from_id = ? "
                    "OR m.chat_id IN (SELECT chat_id FROM members WHERE user_id = ?)) ORDER BY m.id LIMIT 200",
                    (after, uid, uid, uid),
                ).fetchall()
                data = {
                    "messages": [msg_obj(r) for r in rows],
                    "last": rows[-1]["id"] if rows else after,
                    "reset": False,
                }
        self.reply(200, data)

    def get_avatar(self, me, qs):
        with cond:
            u = user_by_name((qs.get("name") or [""])[0])
        if u is None or not u["avatar"]:
            return self.reply(404, {"error": "no avatar"})
        path = avatar_path(u["id"])
        try:
            with open(path, "rb") as f:
                kind = sniff(f.read(8))
        except OSError:
            return self.reply(404, {"error": "no avatar"})
        self.send_file(path, "image/png" if kind == "png" else "image/jpeg")

    def get_media(self, me, name):
        if not MEDIA_RE.match(name):
            return self.reply(404, {"error": "not found"})
        with cond:
            row = db.execute("SELECT from_id, to_id, chat_id FROM messages WHERE photo = ?", (name,)).fetchone()
            ok = row is not None and (
                me["id"] in (row["from_id"], row["to_id"]) or (row["chat_id"] and is_member(row["chat_id"], me["id"]))
            )
        if not ok:
            return self.reply(404, {"error": "not found"})
        ctype = "image/png" if name.endswith(".png") else "image/jpeg"
        self.send_file(os.path.join(MEDIA_DIR, name), ctype, "private, max-age=31536000, immutable")

    # ---------- POST ----------

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/register":
            return self.post_register()
        routes = {
            "/send": self.post_send,
            "/read": self.post_read,
            "/profile": self.post_profile,
            "/avatar": self.post_avatar,
            "/avatar/remove": self.post_avatar_remove,
            "/chat/create": self.post_chat_create,
            "/chat/join": self.post_chat_join,
            "/chat/leave": self.post_chat_leave,
            "/chat/delete": self.post_chat_delete,
            "/chat/edit": self.post_chat_edit,
            "/chat/avatar/remove": self.post_chat_avatar_remove,
        }
        if path == "/photo":
            fn = lambda me: self.post_photo(me, parse_qs(parsed.query))
        elif path == "/chat/avatar":
            fn = lambda me: self.post_chat_avatar(me, parse_qs(parsed.query))
        else:
            fn = routes.get(path)
            if fn is None:
                return self.reply(404, {"error": "not found"})
        me = self.auth()
        if me is None:
            return self.reply(401, {"error": "unauthorized"})
        fn(me)

    def post_register(self):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        name = norm_name(d.get("username"))
        if not NAME_RE.match(name):
            return self.reply(400, {"error": "bad username"})
        display = clean_name(d.get("display_name")) or name
        if limited(("reg", self.client_ip()), 20, 3600):
            return self.reply(429, {"error": "slow down"})
        token = secrets.token_urlsafe(32)
        try:
            with cond:
                cur = db.execute(
                    "INSERT INTO users(username, username_lc, token_hash, created, display_name, display_lc) "
                    "VALUES(?,?,?,?,?,?)",
                    (name, name.lower(), sha(token), now_ms(), display, display.lower()),
                )
                uid = cur.lastrowid
        except sqlite3.IntegrityError:
            return self.reply(409, {"error": "taken"})
        self.reply(200, {"token": token, "username": name, "display_name": display, "id": uid})

    def post_profile(self, me):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        if limited(("profile", me["id"]), 30, 3600):
            return self.reply(429, {"error": "slow down"})
        display = me["display_name"] or me["username"]
        bio = me["bio"]
        if "display_name" in d:
            display = clean_name(d.get("display_name"))
            if not display:
                return self.reply(400, {"error": "empty name"})
        if "bio" in d:
            bio = clean_bio(d.get("bio"))
        with cond:
            db.execute(
                "UPDATE users SET display_name=?, display_lc=?, bio=? WHERE id=?",
                (display, display.lower(), bio, me["id"]),
            )
            row = db.execute("SELECT * FROM users WHERE id=?", (me["id"],)).fetchone()
        self.reply(200, user_obj(row))

    def post_avatar(self, me):
        data = self.body(MAX_AVATAR)
        if data is None:
            return
        if sniff(data) is None:
            return self.reply(400, {"error": "bad image"})
        if limited(("avatar", me["id"]), 20, 3600):
            return self.reply(429, {"error": "slow down"})
        write_file(avatar_path(me["id"]), data)
        with cond:
            # версия растёт всегда, даже после удаления: по ней клиент понимает, что картинка новая
            ver = max((me["avatar"] or 0) + 1, int(time.time()))
            db.execute("UPDATE users SET avatar=? WHERE id=?", (ver, me["id"]))
            row = db.execute("SELECT * FROM users WHERE id=?", (me["id"],)).fetchone()
        self.reply(200, user_obj(row))

    def post_avatar_remove(self, me):
        with cond:
            db.execute("UPDATE users SET avatar=0 WHERE id=?", (me["id"],))
            row = db.execute("SELECT * FROM users WHERE id=?", (me["id"],)).fetchone()
        try:
            os.remove(avatar_path(me["id"]))
        except OSError:
            pass
        self.reply(200, user_obj(row))

    def resolve(self, me, to, chat_id):
        """Кому пишем. Возвращает (to_id, chat_id, код_ошибки). Вызывать под cond."""
        if chat_id:
            c = get_chat(chat_id)
            if c is None:
                return 0, 0, 404
            if not is_member(c["id"], me["id"]):
                return 0, 0, 403
            if c["kind"] == "channel" and c["owner_id"] != me["id"]:
                return 0, 0, 403          # в канал пишет только владелец
            return 0, c["id"], None
        peer = user_by_name(to)
        if peer is None:
            return 0, 0, 404
        if peer["id"] == me["id"]:
            return 0, 0, 400
        return peer["id"], 0, None

    def reply_to_for(self, me, to_id, cid, rid):
        """Ответить можно только на сообщение из этой же переписки."""
        if rid is None:
            return None
        if cid:
            ok = db.execute("SELECT 1 FROM messages WHERE id=? AND chat_id=?", (rid, cid)).fetchone()
        else:
            ok = db.execute(
                "SELECT 1 FROM messages WHERE id=? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?))",
                (rid, me["id"], to_id, to_id, me["id"]),
            ).fetchone()
        return rid if ok else None

    def post_send(self, me):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        text = clean_text(d.get("text"))
        if not text:
            return self.reply(400, {"error": "empty"})
        if limited(("send", me["id"]), 10, 10):
            return self.reply(429, {"error": "slow down"})
        with cond:
            to_id, cid, err = self.resolve(me, d.get("to"), to_int(d.get("chat"), 0))
            if err:
                return self.reply(err, {"error": "cannot send"})
            reply_to = self.reply_to_for(me, to_id, cid, to_int(d.get("reply_to")))
            cur = db.execute(
                "INSERT INTO messages(from_id, to_id, text, reply_to, ts, chat_id) VALUES(?,?,?,?,?,?)",
                (me["id"], to_id, text, reply_to, now_ms(), cid),
            )
            row = db.execute(MSG_SQL + "WHERE m.id = ?", (cur.lastrowid,)).fetchone()
            data = {"ok": True, "message": msg_obj(row)}
            cond.notify_all()
        self.reply(200, data)

    def post_photo(self, me, qs):
        data = self.body(MAX_PHOTO)
        if data is None:
            return
        kind = sniff(data)
        if kind is None:
            return self.reply(400, {"error": "bad image"})
        if limited(("photo", me["id"]), 6, 60):
            return self.reply(429, {"error": "slow down"})
        caption = clean_text((qs.get("caption") or [""])[0])
        w = min(max(to_int((qs.get("w") or ["0"])[0], 0), 0), 8192)
        h = min(max(to_int((qs.get("h") or ["0"])[0], 0), 0), 8192)
        name = "%s.%s" % (secrets.token_hex(16), kind)
        path = os.path.join(MEDIA_DIR, name)
        with cond:
            to_id, cid, err = self.resolve(me, (qs.get("to") or [""])[0], to_int((qs.get("chat") or ["0"])[0], 0))
            if err:
                return self.reply(err, {"error": "cannot send"})
            reply_to = self.reply_to_for(me, to_id, cid, to_int((qs.get("reply_to") or [None])[0]))
            write_file(path, data)
            cur = db.execute(
                "INSERT INTO messages(from_id, to_id, text, reply_to, ts, photo, pw, ph, chat_id) "
                "VALUES(?,?,?,?,?,?,?,?,?)",
                (me["id"], to_id, caption, reply_to, now_ms(), name, w, h, cid),
            )
            row = db.execute(MSG_SQL + "WHERE m.id = ?", (cur.lastrowid,)).fetchone()
            out = {"ok": True, "message": msg_obj(row)}
            cond.notify_all()
        self.reply(200, out)

    def post_read(self, me):
        d = self.read_json()
        upto = to_int(d.get("upto")) if d else None
        if d is None or upto is None:
            return self.reply(400, {"error": "bad request"})
        cid = to_int(d.get("chat"), 0)
        with cond:
            if cid:
                if not is_member(cid, me["id"]):
                    return self.reply(403, {"error": "not a member"})
                set_read(me["id"], -cid, max(upto, 0))
            else:
                peer = user_by_name(d.get("with"))
                if peer is None:
                    return self.reply(404, {"error": "no such user"})
                set_read(me["id"], peer["id"], max(upto, 0))
        self.reply(200, {"ok": True})

    # ---------- группы и каналы ----------

    def get_chat_info(self, me, qs):
        with cond:
            c = get_chat(to_int((qs.get("id") or [None])[0], 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            o = chat_obj(c, me["id"])
        self.reply(200, o)

    def get_chat_members(self, me, qs):
        cid = to_int((qs.get("id") or [None])[0], 0)
        with cond:
            c = get_chat(cid)
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            if not is_member(cid, me["id"]):
                return self.reply(403, {"error": "not a member"})
            rows = db.execute(
                "SELECT u.* FROM members mb JOIN users u ON u.id = mb.user_id WHERE mb.chat_id = ? "
                "ORDER BY (u.id = ?) DESC, mb.joined LIMIT 200",
                (cid, c["owner_id"]),
            ).fetchall()
            users = []
            for r in rows:
                o = user_obj(r)
                o["owner"] = r["id"] == c["owner_id"]
                users.append(o)
        self.reply(200, {"users": users})

    def get_chat_avatar(self, me, qs):
        with cond:
            c = get_chat(to_int((qs.get("id") or [None])[0], 0))
        if c is None or not c["avatar"]:
            return self.reply(404, {"error": "no avatar"})
        path = chat_avatar_path(c["id"])
        try:
            with open(path, "rb") as f:
                kind = sniff(f.read(8))
        except OSError:
            return self.reply(404, {"error": "no avatar"})
        self.send_file(path, "image/png" if kind == "png" else "image/jpeg")

    def post_chat_create(self, me):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        kind = d.get("kind")
        if kind not in ("group", "channel"):
            return self.reply(400, {"error": "bad kind"})
        title = clean_name(d.get("title"))
        if not title:
            return self.reply(400, {"error": "empty title"})
        if limited(("chatnew", me["id"]), 10, 3600):
            return self.reply(429, {"error": "slow down"})
        bio = clean_bio(d.get("bio"))
        with cond:
            n = db.execute("SELECT COUNT(*) FROM chats WHERE owner_id=?", (me["id"],)).fetchone()[0]
            if n >= MAX_CHATS:
                return self.reply(400, {"error": "too many chats"})
            cur = db.execute(
                "INSERT INTO chats(kind, title, title_lc, bio, owner_id, created) VALUES(?,?,?,?,?,?)",
                (kind, title, title.lower(), bio, me["id"], now_ms()),
            )
            db.execute("INSERT INTO members(chat_id, user_id, joined) VALUES(?,?,?)", (cur.lastrowid, me["id"], now_ms()))
            o = chat_obj(get_chat(cur.lastrowid), me["id"])
        self.reply(200, o)

    def post_chat_join(self, me):
        d = self.read_json() or {}
        with cond:
            c = get_chat(to_int(d.get("id"), 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            db.execute("INSERT OR IGNORE INTO members(chat_id, user_id, joined) VALUES(?,?,?)", (c["id"], me["id"], now_ms()))
            # старые сообщения не считаем непрочитанными
            top = db.execute("SELECT COALESCE(MAX(id), 0) FROM messages WHERE chat_id=?", (c["id"],)).fetchone()[0]
            set_read(me["id"], -c["id"], top)
            o = chat_obj(c, me["id"])
            cond.notify_all()
        self.reply(200, o)

    def post_chat_leave(self, me):
        d = self.read_json() or {}
        with cond:
            c = get_chat(to_int(d.get("id"), 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            if c["owner_id"] == me["id"]:
                return self.reply(400, {"error": "owner cannot leave"})
            db.execute("DELETE FROM members WHERE chat_id=? AND user_id=?", (c["id"], me["id"]))
            db.execute("DELETE FROM reads WHERE user_id=? AND peer_id=?", (me["id"], -c["id"]))
            o = chat_obj(c, me["id"])
        self.reply(200, o)

    def post_chat_delete(self, me):
        d = self.read_json() or {}
        with cond:
            c = get_chat(to_int(d.get("id"), 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            if c["owner_id"] != me["id"]:
                return self.reply(403, {"error": "owner only"})
            photos = [r["photo"] for r in db.execute(
                "SELECT photo FROM messages WHERE chat_id=? AND photo IS NOT NULL", (c["id"],))]
            db.execute("DELETE FROM messages WHERE chat_id=?", (c["id"],))
            db.execute("DELETE FROM members WHERE chat_id=?", (c["id"],))
            db.execute("DELETE FROM reads WHERE peer_id=?", (-c["id"],))
            db.execute("DELETE FROM chats WHERE id=?", (c["id"],))
        for p in photos + [None]:
            try:
                os.remove(chat_avatar_path(c["id"]) if p is None else os.path.join(MEDIA_DIR, p))
            except OSError:
                pass
        self.reply(200, {"ok": True})

    def post_chat_edit(self, me):
        d = self.read_json()
        if d is None:
            return self.reply(400, {"error": "bad json"})
        with cond:
            c = get_chat(to_int(d.get("id"), 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            if c["owner_id"] != me["id"]:
                return self.reply(403, {"error": "owner only"})
            title, bio = c["title"], c["bio"]
            if "title" in d:
                title = clean_name(d.get("title"))
                if not title:
                    return self.reply(400, {"error": "empty title"})
            if "bio" in d:
                bio = clean_bio(d.get("bio"))
            db.execute("UPDATE chats SET title=?, title_lc=?, bio=? WHERE id=?", (title, title.lower(), bio, c["id"]))
            o = chat_obj(get_chat(c["id"]), me["id"])
        self.reply(200, o)

    def post_chat_avatar(self, me, qs):
        data = self.body(MAX_AVATAR)
        if data is None:
            return
        if sniff(data) is None:
            return self.reply(400, {"error": "bad image"})
        if limited(("avatar", me["id"]), 20, 3600):
            return self.reply(429, {"error": "slow down"})
        with cond:
            c = get_chat(to_int((qs.get("id") or [None])[0], 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            if c["owner_id"] != me["id"]:
                return self.reply(403, {"error": "owner only"})
            write_file(chat_avatar_path(c["id"]), data)
            ver = max((c["avatar"] or 0) + 1, int(time.time()))
            db.execute("UPDATE chats SET avatar=? WHERE id=?", (ver, c["id"]))
            o = chat_obj(get_chat(c["id"]), me["id"])
        self.reply(200, o)

    def post_chat_avatar_remove(self, me):
        d = self.read_json() or {}
        with cond:
            c = get_chat(to_int(d.get("id"), 0))
            if c is None:
                return self.reply(404, {"error": "no such chat"})
            if c["owner_id"] != me["id"]:
                return self.reply(403, {"error": "owner only"})
            db.execute("UPDATE chats SET avatar=0 WHERE id=?", (c["id"],))
            o = chat_obj(get_chat(c["id"]), me["id"])
        try:
            os.remove(chat_avatar_path(c["id"]))
        except OSError:
            pass
        self.reply(200, o)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128


if __name__ == "__main__":
    print("flaugram server on :%d (db: %s)" % (PORT, DB_FILE), flush=True)
    try:
        Server(("0.0.0.0", PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        pass
