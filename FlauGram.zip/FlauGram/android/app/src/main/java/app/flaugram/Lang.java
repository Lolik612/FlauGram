package app.flaugram;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import java.util.Locale;

/** Выбор языка приложения: авто (как в телефоне), русский или английский. */
final class Lang {
    private Lang() { }

    static String get(Context c) {
        SharedPreferences p = c.getSharedPreferences("flaugram", Context.MODE_PRIVATE);
        String l = p.getString("lang", "auto");
        return "ru".equals(l) || "en".equals(l) ? l : "auto";
    }

    static Context wrap(Context base) {
        String l = get(base);
        if ("auto".equals(l)) return base;
        Locale loc = new Locale(l);
        Locale.setDefault(loc);
        Configuration conf = new Configuration(base.getResources().getConfiguration());
        conf.setLocale(loc);
        return base.createConfigurationContext(conf);
    }
}
