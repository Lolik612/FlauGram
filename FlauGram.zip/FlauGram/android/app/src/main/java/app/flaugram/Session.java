package app.flaugram;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** Состояние входа и настройки. Хранится в SharedPreferences «flaugram» (их же читает фоновая служба). */
final class Session {
    private Session() { }

    static SharedPreferences prefs;
    static String token, me;
    static String meName = "", meBio = "";
    static long meAvatar;
    static boolean admin, verified, dark = true;
    static String email = "";
    static boolean mailEnabled;
    static long keyNext;
    static final Set<String> muted = new HashSet<>();

    static void load(Context c) {
        prefs = c.getSharedPreferences("flaugram", Context.MODE_PRIVATE);
        token = prefs.getString("token", null);
        me = prefs.getString("me", null);
        meName = prefs.getString("me_name", me == null ? "" : me);
        meBio = prefs.getString("me_bio", "");
        meAvatar = prefs.getLong("me_avatar", 0);
        admin = prefs.getBoolean("me_admin", false);
        verified = prefs.getBoolean("me_verified", false);
        dark = prefs.getBoolean("dark", true);
        email = prefs.getString("me_email", "");
        mailEnabled = prefs.getBoolean("mail_on", false);
        keyNext = prefs.getLong("key_next", 0);
        muted.clear();
        muted.addAll(prefs.getStringSet("muted", new HashSet<String>()));
    }

    static boolean loggedIn() {
        return token != null && me != null;
    }

    static void login(String tok, String name, String display, String bio, long avatar) {
        token = tok;
        me = name;
        meName = display == null || display.isEmpty() ? name : display;
        meBio = bio == null ? "" : bio;
        meAvatar = avatar;
        prefs.edit().putString("token", tok).putString("me", name).putString("me_name", meName)
                .putString("me_bio", meBio).putLong("me_avatar", avatar).remove("notif_after").apply();
    }

    static void saveMe(String display, String bio, long avatar, boolean isAdmin, boolean isVerified) {
        meName = display == null || display.isEmpty() ? me : display;
        meBio = bio == null ? "" : bio;
        meAvatar = avatar;
        admin = isAdmin;
        verified = isVerified;
        prefs.edit().putString("me_name", meName).putString("me_bio", meBio).putLong("me_avatar", avatar)
                .putBoolean("me_admin", isAdmin).putBoolean("me_verified", isVerified).apply();
    }

    static void logout() {
        token = null;
        me = null;
        admin = false;
        verified = false;
        muted.clear();
        prefs.edit().remove("token").remove("me").remove("me_name").remove("me_bio").remove("me_avatar")
                .remove("me_admin").remove("me_verified").remove("me_email").remove("mail_on").remove("key_next").remove("notif_after").remove("muted").apply();
    }

    static void setMail(String mail, boolean enabled, long next) {
        email = mail == null ? "" : mail;
        mailEnabled = enabled;
        keyNext = next;
        prefs.edit().putString("me_email", email).putBoolean("mail_on", enabled).putLong("key_next", next).apply();
    }

    /** Новый ключ доступа после перевыпуска; фоновая служба читает его из тех же настроек. */
    static void setToken(String tok) {
        token = tok;
        prefs.edit().putString("token", tok).remove("notif_after").apply();
    }

    static boolean isMuted(String key) {
        return muted.contains(key);
    }

    static void setMuted(String key, boolean on) {
        if (on) muted.add(key); else muted.remove(key);
        prefs.edit().putStringSet("muted", new HashSet<>(muted)).apply();
    }
}
