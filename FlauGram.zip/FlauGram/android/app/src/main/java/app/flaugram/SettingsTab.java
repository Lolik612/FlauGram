package app.flaugram;

import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Вкладка «Настройки»: карточки с переключателями. Никаких системных диалогов. */
final class SettingsTab extends Tab {
    private LinearLayout body;

    SettingsTab(ShellScreen shell) {
        super(shell);
    }

    @Override
    View build() {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(p.bg);
        sv.setVerticalScrollBarEnabled(false);
        body = ui.vertical();
        body.setPadding(ui.dp(16), ui.dp(14), ui.dp(16), navPad());
        sv.addView(body, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        fill();
        return sv;
    }

    @Override
    void onSelected() {
        fill();
        Updater.listener = this::refreshUpdate;
    }

    @Override
    void onMeChanged() {
        if (body != null) fill();
    }

    private LinearLayout group() {
        LinearLayout g = ui.card();
        body.addView(g, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        return g;
    }

    private void add(LinearLayout g, View row) {
        if (g.getChildCount() > 0) g.addView(ui.divider());
        g.addView(row);
    }

    private TextView chevron(String text) {
        TextView t = ui.label(text, 15, p.sub, false);
        return t;
    }

    private void fill() {
        body.removeAllViews();
        // шапка: большая круглая аватарка по центру, имя и юзернейм
        LinearLayout head = ui.vertical();
        head.setGravity(Gravity.CENTER_HORIZONTAL);
        head.setPadding(0, ui.dp(6), 0, ui.dp(20));
        AvatarView av = new AvatarView(a, ui.dp(104), 0);
        av.bindMe();
        av.image().setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        head.addView(av, ui.lp(ui.dp(104), ui.dp(104)));
        NameLine nl = new NameLine(a, 24, p.text, true, 22).center();
        nl.set(Session.meName, Session.me, null);
        head.addView(nl, ui.lpm(Ui.WRAP, Ui.WRAP, 24, 12, 24, 0));
        TextView un = ui.label("@" + Session.me, 16, p.sub, false);
        un.setGravity(Gravity.CENTER);
        head.addView(un, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 2, 0, 0));
        body.addView(head, ui.lp(Ui.MATCH, Ui.WRAP));

        // изменить профиль
        LinearLayout g0 = group();
        LinearLayout r0 = ui.settingRow(R.drawable.ic_person, 0xFF1E9BF0, ui.t(R.string.edit_profile), ui.t(R.string.username_fixed), null);
        r0.setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        add(g0, r0);

        // основное
        LinearLayout g1 = group();
        final Toggle notif = new Toggle(a, p.accent, 0xFF48484A, Session.prefs.getBoolean("notify", true));
        notif.setListener(on -> {
            Session.prefs.edit().putBoolean("notify", on).apply();
            if (on) {
                a.askNotifPermission();
                PollService.start(a);
            } else {
                PollService.stop(a);
            }
        });
        LinearLayout r1 = ui.settingRow(R.drawable.ic_bell, 0xFFFF9F0A, ui.t(R.string.set_notifications), ui.t(R.string.set_notifications_sub), notif);
        r1.setOnClickListener(v -> notif.set(!notif.isOn(), true));
        add(g1, r1);
        final Toggle dark = new Toggle(a, p.accent, 0xFF48484A, Session.dark);
        dark.setListener(on -> {
            Session.prefs.edit().putBoolean("dark", on).apply();
            a.restart();
        });
        LinearLayout r2 = ui.settingRow(R.drawable.ic_moon, 0xFF5E5CE6, ui.t(R.string.set_dark), null, dark);
        r2.setOnClickListener(v -> dark.set(!dark.isOn(), true));
        add(g1, r2);
        String cur = Lang.get(a);
        String langName = "ru".equals(cur) ? "Русский" : "en".equals(cur) ? "English" : ui.t(R.string.lang_auto);
        LinearLayout r3 = ui.settingRow(R.drawable.ic_globe, 0xFF30B0C7, ui.t(R.string.menu_language), null, chevron(langName));
        r3.setOnClickListener(v -> languageSheet());
        add(g1, r3);

        // фон
        LinearLayout g2 = group();
        LinearLayout r4 = ui.settingRow(R.drawable.ic_refresh, 0xFF34C759, ui.t(R.string.menu_battery), ui.t(R.string.set_battery_sub), null);
        r4.setOnClickListener(v -> new Sheet(a).title(ui.t(R.string.battery_title)).text(ui.t(R.string.battery_message))
                .buttons(ui.t(R.string.close), ui.t(R.string.open_settings), false, () -> {
                    try {
                        a.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception e) {
                        a.toast(ui.t(R.string.battery_fallback));
                    }
                }).show());
        add(g2, r4);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            LinearLayout r5 = ui.settingRow(R.drawable.ic_close, 0xFF8E8E93, ui.t(R.string.menu_hide_notif), null, null);
            r5.setOnClickListener(v -> new Sheet(a).title(ui.t(R.string.hide_title)).text(ui.t(R.string.hide_message))
                    .buttons(ui.t(R.string.close), ui.t(R.string.open_settings), false, () -> {
                        try {
                            Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                            i.putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                            i.putExtra(Settings.EXTRA_CHANNEL_ID, PollService.CH_BG);
                            a.startActivity(i);
                        } catch (Exception e) {
                            a.toast(ui.t(R.string.battery_fallback));
                        }
                    }).show());
            add(g2, r5);
        }

        // обновление
        LinearLayout g3 = group();
        updateRow = ui.settingRow(R.drawable.ic_download, 0xFF0A84FF, ui.t(R.string.set_update), "", null);
        updateSub = (TextView) ((LinearLayout) updateRow.getChildAt(1)).getChildAt(1);
        add(g3, updateRow);
        final Toggle auto = new Toggle(a, p.accent, 0xFF48484A, Updater.auto(a));
        auto.setListener(on -> {
            Updater.setAuto(a, on);
            if (on) Updater.manual(a);
        });
        LinearLayout r6 = ui.settingRow(R.drawable.ic_check, 0xFF30D158, ui.t(R.string.set_auto_update), ui.t(R.string.set_auto_update_sub), auto);
        r6.setOnClickListener(v -> auto.set(!auto.isOn(), true));
        add(g3, r6);
        refreshUpdate();

        // админка
        if (Session.admin) {
            LinearLayout g4 = group();
            LinearLayout r7 = ui.settingRow(R.drawable.ic_shield, 0xFFFF453A, ui.t(R.string.admin_title), ui.t(R.string.admin_sub), null);
            r7.setOnClickListener(v -> a.push(new AdminScreen(a)));
            add(g4, r7);
        }

        // аккаунт
        LinearLayout g5 = group();
        LinearLayout r8 = ui.settingRow(R.drawable.ic_key, 0xFF8E8E93, ui.t(R.string.menu_account), ui.t(R.string.set_key_sub), null);
        r8.setOnClickListener(v -> keySheet(a));
        add(g5, r8);
        LinearLayout r9 = ui.settingRow(R.drawable.ic_logout, 0xFFFF453A, ui.t(R.string.menu_logout), null, null);
        r9.setOnClickListener(v -> Sheet.confirm(a, ui.t(R.string.menu_logout), ui.t(R.string.logout_confirm), ui.t(R.string.logout), true,
                () -> a.logout(null)));
        add(g5, r9);

        TextView ver = ui.label("FlauGram " + BuildConfig.VERSION_NAME, 13, p.sub, false);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, ui.dp(4), 0, ui.dp(6));
        body.addView(ver, ui.lp(Ui.MATCH, Ui.WRAP));
    }

    private LinearLayout updateRow;
    private TextView updateSub;

    /** Подпись и действие строки обновления зависят от состояния Updater. */
    private void refreshUpdate() {
        if (updateRow == null || updateSub == null) return;
        int st = Updater.state;
        Updater.Info i = Updater.info;
        String text;
        View.OnClickListener click;
        int color = p.sub;
        if (st == Updater.CHECKING) {
            text = ui.t(R.string.update_checking);
            click = null;
        } else if (st == Updater.DOWNLOADING) {
            text = ui.t(R.string.update_downloading, Updater.progress);
            click = null;
        } else if (st == Updater.INSTALLING) {
            text = ui.t(R.string.update_installing);
            click = null;
        } else if (st == Updater.READY) {
            text = Updater.canInstall(a) ? ui.t(R.string.update_install_tap) : ui.t(R.string.update_need_permission);
            color = p.accent;
            click = v -> {
                if (!Updater.canInstall(a)) {
                    new Sheet(a).title(ui.t(R.string.update_perm_title)).text(ui.t(R.string.update_perm_text))
                            .buttons(ui.t(R.string.cancel), ui.t(R.string.open_settings), false, () -> {
                                try {
                                    a.startActivity(Updater.permissionIntent(a));
                                } catch (Exception e) {
                                    a.toast(ui.t(R.string.battery_fallback));
                                }
                            }).show();
                } else {
                    Updater.installReady(a);
                }
            };
        } else if (st == Updater.AVAILABLE && i != null) {
            text = ui.t(R.string.update_available_row, i.name);
            color = p.accent;
            click = v -> Updater.installNow(a);
        } else if (st == Updater.ERROR) {
            text = Updater.error.isEmpty() ? ui.t(R.string.update_failed) : Updater.error;
            color = p.danger;
            click = v -> Updater.manual(a);
        } else if (st == Updater.LATEST) {
            text = ui.t(R.string.update_latest) + " · " + BuildConfig.VERSION_NAME;
            click = v -> Updater.manual(a);
        } else {
            text = ui.t(R.string.update_tap_check) + " · " + BuildConfig.VERSION_NAME;
            click = v -> Updater.manual(a);
        }
        updateSub.setText(text);
        updateSub.setTextColor(color);
        updateRow.setOnClickListener(click);
    }

    private void languageSheet() {
        final String[] codes = {"auto", "ru", "en"};
        final String[] names = {ui.t(R.string.lang_auto), "Русский", "English"};
        String cur = Lang.get(a);
        Sheet s = new Sheet(a).title(ui.t(R.string.menu_language));
        for (int i = 0; i < 3; i++) {
            final String code = codes[i];
            boolean on = cur.equals(code);
            s.item(on ? R.drawable.ic_check : 0, names[i], on ? p.accent : 0, () -> {
                Session.prefs.edit().putString("lang", code).apply();
                a.restart();
            });
        }
        s.show();
    }

    /** Ключ входа: показывается в панели, копируется одним нажатием. */
    static void keySheet(final MainActivity a) {
        Ui ui = a.ui;
        Sheet s = new Sheet(a).title(ui.t(R.string.menu_account)).text(ui.t(R.string.account_message));
        TextView k = ui.label(Session.token == null ? "" : Session.token, 14, ui.p.text, false);
        k.setBackground(ui.rounded(ui.p.input, 14));
        k.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        k.setTextIsSelectable(true);
        s.view(k);
        s.buttons(ui.t(R.string.close), ui.t(R.string.copy_key), false, () -> a.copy(Session.token));
        s.show();
    }
}
