package app.flaugram;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/** Обои чата: сплошной фон темы или мягкий градиент. Рисуются кодом, без картинок. */
final class Wallpapers {
    private Wallpapers() { }

    static final int COUNT = 7;

    private static final int[][] DARK = {
            {0xFF2B1B3D, 0xFF0F1B3D}, {0xFF0B3040, 0xFF0A1530}, {0xFF123524, 0xFF0A1A16},
            {0xFF3D1F2E, 0xFF1A1030}, {0xFF3A2A12, 0xFF1A1220}, {0xFF1A1A1E, 0xFF000000}};
    private static final int[][] LIGHT = {
            {0xFFFFE6F0, 0xFFE6EEFF}, {0xFFD9F2FF, 0xFFE9F0FF}, {0xFFDDF5E4, 0xFFEAF7F0},
            {0xFFFBE0EA, 0xFFEDE4FA}, {0xFFFFF0D6, 0xFFF9E6F0}, {0xFFEDEDF0, 0xFFFFFFFF}};

    /** id 0: цвет темы. 1..6: градиенты. */
    static Drawable get(int id, Palette p) {
        if (id <= 0 || id >= COUNT) return new ColorDrawable(p.bg);
        int[] c = (p.dark ? DARK : LIGHT)[id - 1];
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, c);
        return g;
    }

    static String name(Ui ui, int id) {
        switch (id) {
            case 1: return ui.t(R.string.wp_dusk);
            case 2: return ui.t(R.string.wp_ocean);
            case 3: return ui.t(R.string.wp_forest);
            case 4: return ui.t(R.string.wp_rose);
            case 5: return ui.t(R.string.wp_amber);
            case 6: return ui.t(R.string.wp_night);
            default: return ui.t(R.string.wp_plain);
        }
    }
}
