package app.flaugram;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Главный экран: четыре вкладки и плавающая панель снизу, как в референсе. */
final class ShellScreen extends Screen {
    private Tab[] tabs;
    private FrameLayout tabHost;
    private LinearLayout[] items;
    private TextView unreadBadge;
    private AvatarView navAvatar;
    private int current = 0;

    ShellScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        tabs = new Tab[]{new ChatsTab(this), new ContactsTab(this), new SettingsTab(this), new ProfileTab(this)};
        FrameLayout frame = new FrameLayout(a);
        frame.setBackgroundColor(p.bg);
        tabHost = new FrameLayout(a);
        frame.addView(tabHost, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        LinearLayout nav = ui.horizontal();
        nav.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6));
        android.graphics.drawable.GradientDrawable bg = ui.rounded(p.nav, 36);
        bg.setStroke(Math.max(1, ui.dp(1)), p.divider);
        nav.setBackground(bg);
        nav.setElevation(ui.dp(12));
        items = new LinearLayout[4];
        int[] icons = {R.drawable.ic_chat, R.drawable.ic_person, R.drawable.ic_gear, 0};
        String[] names = {ui.t(R.string.tab_chats), ui.t(R.string.tab_contacts), ui.t(R.string.tab_settings), ui.t(R.string.tab_profile)};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout item = ui.vertical();
            item.setGravity(Gravity.CENTER);
            item.setPadding(ui.dp(2), ui.dp(7), ui.dp(2), ui.dp(6));
            item.setClickable(true);
            FrameLayout iconBox = new FrameLayout(a);
            iconBox.setClipChildren(false);
            if (i == 3) {
                navAvatar = new AvatarView(a, ui.dp(26), ui.dp(38));
                navAvatar.setGlow(p.accent);
                navAvatar.bindMe();
                iconBox.addView(navAvatar, new FrameLayout.LayoutParams(ui.dp(38), ui.dp(38), Gravity.CENTER));
            } else {
                iconBox.addView(ui.icon(icons[i], 26, p.text), new FrameLayout.LayoutParams(ui.dp(26), ui.dp(26), Gravity.CENTER));
            }
            if (i == 0) {
                unreadBadge = ui.label("", 11, 0xFF000000, true);
                unreadBadge.setGravity(Gravity.CENTER);
                unreadBadge.setMinWidth(ui.dp(18));
                unreadBadge.setPadding(ui.dp(4), 0, ui.dp(4), 0);
                unreadBadge.setBackground(ui.rounded(0xFFFFFFFF, 10));
                unreadBadge.setVisibility(View.GONE);
                FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(Ui.WRAP, ui.dp(19), Gravity.TOP | Gravity.END);
                bp.setMargins(0, -ui.dp(6), -ui.dp(10), 0);
                iconBox.addView(unreadBadge, bp);
            }
            item.addView(iconBox, ui.lp(ui.dp(40), ui.dp(38)));
            TextView t = ui.label(names[i], 12, p.text, true);
            t.setSingleLine(true);
            t.setGravity(Gravity.CENTER);
            item.addView(t, ui.lp(Ui.WRAP, Ui.WRAP));
            item.setOnClickListener(v -> select(idx));
            items[i] = item;
            nav.addView(item, ui.lpw(0, Ui.WRAP, 1f));
        }
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM);
        np.setMargins(ui.dp(14), 0, ui.dp(14), ui.dp(14));
        frame.addView(nav, np);
        select(0);
        stale();
        return frame;
    }

    void select(int i) {
        current = i;
        tabHost.removeAllViews();
        tabHost.addView(tabs[i].view(), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        for (int k = 0; k < items.length; k++) {
            items[k].setBackground(k == i ? ui.ripple(p.navSel, 30) : ui.ripple(0x00000000, 30));
        }
        a.hideKeyboard();
        tabs[i].onSelected();
    }

    void setUnread(int n) {
        if (unreadBadge == null) return;
        if (n <= 0) {
            unreadBadge.setVisibility(View.GONE);
        } else {
            unreadBadge.setText(n > 99 ? "99+" : String.valueOf(n));
            unreadBadge.setVisibility(View.VISIBLE);
        }
    }

    @Override
    void onShow() {
        if (tabs != null && stale()) tabs[current].onSelected();
    }

    @Override
    void onReads(String with, long upto) {
        for (Tab t : tabs) t.onReads(with, upto);
    }

    @Override
    void onUpdates(List<Model.Msg> list) {
        for (Tab t : tabs) t.onUpdates(list);
    }

    @Override
    void onMeChanged() {
        if (navAvatar != null) navAvatar.bindMe();
        for (Tab t : tabs) t.onMeChanged();
    }

    @Override
    boolean onBack() {
        if (current != 0) {
            select(0);
            return true;
        }
        return false;
    }
}
