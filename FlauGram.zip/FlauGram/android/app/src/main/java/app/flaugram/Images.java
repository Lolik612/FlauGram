package app.flaugram;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Картинки: подготовка к отправке, загрузка с сервера, кэш, круглые аватарки и буквы вместо них. */
final class Images {
    private Images() { }

    static final class Encoded {
        byte[] data;
        int w, h;
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8 / 1024)) {
                @Override
                protected int sizeOf(String key, Bitmap b) {
                    return b.getByteCount() / 1024;
                }
            };

    // ------------------------------------------------------------------ подготовка к отправке

    /** Читает картинку из галереи, поворачивает по EXIF, уменьшает и сжимает в JPEG. null при ошибке. */
    static Encoded encode(Context c, Uri uri, int maxSide, boolean square, int maxBytes) {
        try {
            byte[] src = readAll(c.getContentResolver(), uri, 40 * 1024 * 1024);
            if (src == null) return null;

            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(src, 0, src.length, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxSide && o.outHeight / (sample * 2) >= maxSide) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeByteArray(src, 0, src.length, o);
            if (bmp == null) return null;

            int rot = exifRotation(src);
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                if (r != bmp) bmp.recycle();
                bmp = r;
            }

            int sw = bmp.getWidth(), sh = bmp.getHeight();
            Rect from;
            int tw, th;
            if (square) {
                int side = Math.min(sw, sh);
                from = new Rect((sw - side) / 2, (sh - side) / 2, (sw - side) / 2 + side, (sh - side) / 2 + side);
                tw = th = Math.min(side, maxSide);
            } else {
                from = new Rect(0, 0, sw, sh);
                float k = Math.min(1f, (float) maxSide / Math.max(sw, sh));
                tw = Math.max(1, Math.round(sw * k));
                th = Math.max(1, Math.round(sh * k));
            }

            for (int attempt = 0; attempt < 4; attempt++) {
                // белая подложка, чтобы прозрачные PNG не стали чёрными
                Bitmap out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(out);
                cv.drawColor(Color.WHITE);
                Paint pt = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
                cv.drawBitmap(bmp, from, new Rect(0, 0, tw, th), pt);
                for (int q = 85; q >= 50; q -= 15) {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    out.compress(Bitmap.CompressFormat.JPEG, q, bo);
                    if (bo.size() <= maxBytes) {
                        Encoded e = new Encoded();
                        e.data = bo.toByteArray();
                        e.w = tw;
                        e.h = th;
                        return e;
                    }
                }
                tw = Math.max(1, tw * 3 / 4);
                th = Math.max(1, th * 3 / 4);
            }
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static int exifRotation(byte[] src) {
        if (Build.VERSION.SDK_INT < 24) return 0;
        try {
            ExifInterface ex = new ExifInterface(new ByteArrayInputStream(src));
            int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) return 90;
            if (o == ExifInterface.ORIENTATION_ROTATE_180) return 180;
            if (o == ExifInterface.ORIENTATION_ROTATE_270) return 270;
        } catch (Throwable ignored) {
            // нет EXIF — оставляем как есть
        }
        return 0;
    }

    private static byte[] readAll(ContentResolver cr, Uri uri, int limit) throws Exception {
        InputStream in = cr.openInputStream(uri);
        if (in == null) return null;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (out.size() > limit) {
                in.close();
                return null;
            }
        }
        in.close();
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ аватарки

    static int nameColor(String name) {
        int hue = (name.toLowerCase(Locale.ROOT).hashCode() & 0x7fffffff) % 360;
        return Color.HSVToColor(new float[]{hue, 0.55f, 0.75f});
    }

    private static Bitmap letter(String name, int size) {
        String key = "l:" + name + ":" + size;
        Bitmap b = CACHE.get(key);
        if (b != null) return b;
        b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(nameColor(name));
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p);
        String s = name.isEmpty() ? "?" : new String(Character.toChars(name.codePointAt(0))).toUpperCase(Locale.ROOT);
        p.setColor(Color.WHITE);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(size * 0.45f);
        p.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = p.getFontMetrics();
        cv.drawText(s, size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p);
        CACHE.put(key, b);
        return b;
    }

    private static Bitmap circleOf(Bitmap src, int size) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        BitmapShader sh = new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        float k = Math.max((float) size / src.getWidth(), (float) size / src.getHeight());
        Matrix m = new Matrix();
        m.postScale(k, k);
        m.postTranslate((size - src.getWidth() * k) / 2f, (size - src.getHeight() * k) / 2f);
        sh.setLocalMatrix(m);
        p.setShader(sh);
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p);
        return out;
    }

    /** Показывает аватарку человека: сразу букву на цветном круге, потом (если есть) фото. */
    static void avatar(ImageView iv, String user, String display, long version, int size, String token) {
        avatarAt(iv, "u:" + user.toLowerCase(Locale.ROOT), "/avatar?name=" + Api.enc(user),
                display == null || display.isEmpty() ? user : display, version, size, token);
    }

    /** То же для группы или канала. */
    static void chatAvatar(ImageView iv, long chatId, String title, long version, int size, String token) {
        avatarAt(iv, "c:" + chatId, "/chat/avatar?id=" + chatId, title, version, size, token);
    }

    private static void avatarAt(final ImageView iv, String id, final String path, String shown, long version,
                                 final int size, final String token) {
        final String key = "av:" + id + ":" + version + ":" + size;
        iv.setTag(key);
        if (version <= 0) {
            iv.setImageBitmap(letter(shown, size));
            return;
        }
        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            iv.setImageBitmap(hit);
            return;
        }
        iv.setImageBitmap(letter(shown, size));
        POOL.execute(() -> {
            byte[] data = Api.getBytes(path, token);
            if (data == null) return;
            final Bitmap raw = decode(data, size * 2);
            if (raw == null) return;
            final Bitmap round = circleOf(raw, size);
            raw.recycle();
            CACHE.put(key, round);
            MAIN.post(() -> {
                if (key.equals(iv.getTag())) iv.setImageBitmap(round);
            });
        });
    }

    /** То же самое, но блокирующе и возвращает Bitmap (для уведомлений). Вызывать только из фона. */
    static Bitmap avatarSync(String user, String display, long version, int size, String token) {
        String shown = display == null || display.isEmpty() ? user : display;
        String key = "av:u:" + user.toLowerCase(Locale.ROOT) + ":" + version + ":" + size;
        if (version > 0) {
            Bitmap hit = CACHE.get(key);
            if (hit != null) return hit;
            byte[] data = Api.getBytes("/avatar?name=" + Api.enc(user), token);
            Bitmap raw = data == null ? null : decode(data, size * 2);
            if (raw != null) {
                Bitmap round = circleOf(raw, size);
                raw.recycle();
                CACHE.put(key, round);
                return round;
            }
        }
        return letter(shown, size);
    }

    /** Своя картинка значка подтверждения. Пока грузится, место пустое. */
    static void badge(final ImageView iv, String user, final long version, final int size, final String token) {
        final String key = "bd:" + user.toLowerCase(Locale.ROOT) + ":" + version + ":" + size;
        iv.setTag(key);
        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            iv.setImageBitmap(hit);
            return;
        }
        iv.setImageBitmap(null);
        final String path = "/badge?name=" + Api.enc(user);
        POOL.execute(() -> {
            byte[] data = Api.getBytes(path, token);
            if (data == null) return;
            final Bitmap raw = decode(data, size * 2);
            if (raw == null) return;
            final Bitmap round = circleOf(raw, size);
            raw.recycle();
            CACHE.put(key, round);
            MAIN.post(() -> {
                if (key.equals(iv.getTag())) iv.setImageBitmap(round);
            });
        });
    }

    // ------------------------------------------------------------------ фото в переписке

    /** Загружает фото сообщения и показывает его в ImageView. */
    static void photo(final ImageView iv, final String file, final String token, final int maxSide) {
        final String key = "ph:" + file + ":" + maxSide;
        iv.setTag(key);
        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            iv.setImageBitmap(hit);
            return;
        }
        iv.setImageBitmap(null);
        POOL.execute(() -> {
            byte[] data = Api.getBytes("/media/" + file, token);
            if (data == null) return;
            final Bitmap b = decode(data, maxSide);
            if (b == null) return;
            CACHE.put(key, b);
            MAIN.post(() -> {
                if (key.equals(iv.getTag())) iv.setImageBitmap(b);
            });
        });
    }

    private static Bitmap decode(byte[] data, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (o.outWidth <= 0) return null;
            int s = 1;
            while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Сбросить кэш аватарок пользователя (после смены своей). */
    static void forget() {
        CACHE.evictAll();
    }
}
