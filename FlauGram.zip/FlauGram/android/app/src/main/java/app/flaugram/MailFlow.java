package app.flaugram;

import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

/** Всё, что связано с почтой: окно кода, привязка адреса, перевыпуск и восстановление ключа. */
final class MailFlow {
    private MailFlow() { }

    interface Code {
        void got(String code);
    }

    /** Понятный текст ошибки по ответу сервера. */
    static String err(MainActivity a, Api.Res r) {
        if (r.netFail) return a.netMsg();
        String e = r.json == null ? "" : r.json.optString("error");
        Ui ui = a.ui;
        switch (e) {
            case "bad email": return ui.t(R.string.mail_bad_email);
            case "email_taken": return ui.t(R.string.mail_taken);
            case "same": return ui.t(R.string.mail_same);
            case "mail_failed": return ui.t(R.string.mail_failed);
            case "mail_off": return ui.t(R.string.mail_off);
            case "bad code": return ui.t(R.string.mail_bad_code);
            case "email_required": return ui.t(R.string.mail_bad_email);
            case "taken": return ui.t(R.string.err_username_taken);
            case "bad username": return ui.t(R.string.err_username_invalid);
            case "wait": return ui.t(R.string.mail_wait, Math.max(1, (int) (r.json.optLong("retry_ms") / 1000)));
            case "cooldown": return ui.t(R.string.key_cooldown, hours(r.json.optLong("retry_ms")));
            default: break;
        }
        if (r.code == 429) return ui.t(R.string.err_too_many);
        return ui.t(R.string.err_server, r.code);
    }

    static int hours(long ms) {
        return (int) Math.max(1, (ms + 3599999) / 3600000);
    }

    /** Окно «введите код из письма» с кнопкой «Отправить ещё раз». */
    static void codeSheet(final MainActivity a, String title, String text, String ok, final Code cb, final Runnable resend) {
        final Ui ui = a.ui;
        final Sheet s = new Sheet(a).title(title).text(text);
        final EditText e = ui.edit("000000");
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        e.setGravity(Gravity.CENTER);
        e.setTextSize(24);
        s.view(e);
        if (resend != null) {
            TextView again = ui.label(ui.t(R.string.mail_resend), 14, ui.p.accent, true);
            again.setGravity(Gravity.CENTER);
            again.setPadding(0, ui.dp(12), 0, ui.dp(4));
            again.setClickable(true);
            again.setOnClickListener(v -> resend.run());
            s.view(again);
        }
        s.buttons(ui.t(R.string.cancel), ok, false, () -> cb.got(e.getText().toString().trim()));
        s.show();
        e.requestFocus();
    }

    // ------------------------------------------------------------------ привязка почты к аккаунту

    static void bind(final MainActivity a) {
        Sheet.input(a, a.ui.t(R.string.mail_bind_title), a.ui.t(R.string.mail_hint), Session.email, 120, false,
                a.ui.t(R.string.mail_send_code), email -> sendBindCode(a, email, true));
    }

    private static void sendBindCode(final MainActivity a, final String email, final boolean open) {
        if (email.isEmpty()) return;
        a.api("POST", "/email/start", Api.obj("email", email), r -> {
            if (r.code != 200) {
                a.toast(err(a, r));
                return;
            }
            if (!open) {
                a.toast(a.ui.t(R.string.mail_sent));
                return;
            }
            askBindCode(a, email);
        });
    }

    private static void askBindCode(final MainActivity a, final String email) {
        codeSheet(a, a.ui.t(R.string.mail_code_title), a.ui.t(R.string.mail_code_text, email), a.ui.t(R.string.mail_confirm),
                code -> a.api("POST", "/email/confirm", Api.obj("code", code), r -> {
                    if (r.code == 200 && r.json != null) {
                        Session.setMail(r.json.optString("email", email), true, Session.keyNext);
                        a.toast(a.ui.t(R.string.mail_bound));
                        a.refreshMe();
                    } else {
                        a.toast(err(a, r));
                        if (r.code == 400) askBindCode(a, email);
                    }
                }), () -> sendBindCode(a, email, false));
    }

    // ------------------------------------------------------------------ ключ доступа

    static void revoke(final MainActivity a) {
        long now = System.currentTimeMillis();
        if (Session.keyNext > now) {
            a.toast(a.ui.t(R.string.key_cooldown, hours(Session.keyNext - now)));
            return;
        }
        Sheet.confirm(a, a.ui.t(R.string.key_revoke_title), a.ui.t(R.string.key_revoke_text), a.ui.t(R.string.key_revoke_go), true, () ->
                a.api("POST", "/key/revoke", null, r -> {
                    if (r.code == 200 && r.json != null && r.json.optString("token").length() > 0) {
                        Session.setToken(r.json.optString("token"));
                        Session.setMail(Session.email, Session.mailEnabled, r.json.optLong("next_ms"));
                        a.tokenChanged();
                        SettingsTab.keySheet(a);
                    } else {
                        if (r.code == 429 && r.json != null) Session.setMail(Session.email, Session.mailEnabled, r.json.optLong("next_ms"));
                        a.toast(err(a, r));
                    }
                }));
    }

    // ------------------------------------------------------------------ забыли ключ (без входа в аккаунт)

    static void recover(final MainActivity a) {
        Sheet.input(a, a.ui.t(R.string.recover_title), a.ui.t(R.string.recover_hint), "", 120, false,
                a.ui.t(R.string.mail_send_code), login -> recoverStart(a, login, true));
    }

    private static void recoverStart(final MainActivity a, final String login, final boolean open) {
        if (login.isEmpty()) return;
        a.io.execute(() -> {
            final Api.Res r = Api.call("POST", "/key/recover/start", null, Api.obj("login", login.startsWith("@") ? login.substring(1) : login), 20000);
            a.runOnUiThread(() -> {
                if (r.code != 200) {
                    a.toast(err(a, r));
                } else if (open) {
                    askRecoverCode(a, login);
                } else {
                    a.toast(a.ui.t(R.string.mail_sent));
                }
            });
        });
    }

    private static void askRecoverCode(final MainActivity a, final String login) {
        codeSheet(a, a.ui.t(R.string.recover_code_title), a.ui.t(R.string.recover_code_text), a.ui.t(R.string.login_go),
                code -> a.io.execute(() -> {
                    final Api.Res r = Api.call("POST", "/key/recover/confirm", null,
                            Api.obj("login", login.startsWith("@") ? login.substring(1) : login, "code", code), 20000);
                    a.runOnUiThread(() -> {
                        JSONObject j = r.json;
                        if (r.code == 200 && j != null && j.optString("token").length() > 0) {
                            Session.login(j.optString("token"), j.optString("username"), j.optString("display_name"),
                                    j.optString("bio"), j.optLong("avatar"));
                            Images.forget();
                            a.startSession();
                            a.toast(a.ui.t(R.string.recover_done));
                        } else {
                            a.toast(err(a, r));
                            if (r.code == 400) askRecoverCode(a, login);
                        }
                    });
                }), () -> recoverStart(a, login, false));
    }
}
