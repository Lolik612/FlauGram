package app.flaugram;

import android.text.TextUtils;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Имя и значок подтверждения в одной строке. */
final class NameLine extends LinearLayout {
    final TextView text;
    final BadgeView badge;
    private final MainActivity a;

    NameLine(MainActivity a, int sp, int color, boolean bold, int badgeDp) {
        super(a);
        this.a = a;
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        text = a.ui.label("", sp, color, bold);
        text.setSingleLine(true);
        text.setEllipsize(TextUtils.TruncateAt.END);
        addView(text, new LayoutParams(Ui.WRAP, Ui.WRAP));
        badge = new BadgeView(a, badgeDp);
        LayoutParams bp = new LayoutParams(a.ui.dp(badgeDp), a.ui.dp(badgeDp));
        bp.leftMargin = a.ui.dp(4);
        addView(badge, bp);
    }

    NameLine center() {
        setGravity(Gravity.CENTER);
        return this;
    }

    void set(String name, String user, Model.Badge b) {
        text.setText(name);
        badge.bind(user, b);
    }
}
