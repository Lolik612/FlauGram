package app.flaugram;

import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Базовый класс экрана. Экраны лежат в стеке MainActivity. */
abstract class Screen {
    final MainActivity a;
    final Ui ui;
    final Palette p;
    View root;

    Screen(MainActivity a) {
        this.a = a;
        this.ui = a.ui;
        this.p = a.ui.p;
    }

    private long loadedAt;

    abstract View build();

    /** true, если с прошлой загрузки данных прошло достаточно времени (защита от двойных запросов). */
    boolean stale() {
        long n = System.currentTimeMillis();
        if (n - loadedAt < 1500) return false;
        loadedAt = n;
        return true;
    }

    /** Экран стал виден (впервые или после возврата назад). */
    void onShow() { }

    void onHide() { }

    void onDestroy() { }

    /** Пришли новые или изменённые сообщения. */
    void onUpdates(List<Model.Msg> list) { }

    /** Собеседник прочитал мои сообщения до номера upto. */
    void onReads(String with, long upto) { }

    /** Человек печатает (chat == 0: в личке). */
    void onTyping(String user, long chat) { }

    /** Мой профиль на сервере обновился. */
    void onMeChanged() { }

    /** Открыта ли у меня сейчас переписка, к которой относится сообщение. */
    boolean showsChat(Model.Msg m) {
        return false;
    }

    boolean onBack() {
        return false;
    }

    void onResult(int req, Uri uri) { }

    /** Верхняя панель: стрелка назад, заголовок, справа любой вид. */
    LinearLayout topBar(String title, View right) {
        LinearLayout bar = ui.horizontal();
        bar.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6));
        android.widget.ImageView back = ui.iconButton(R.drawable.ic_back, p.text);
        back.setOnClickListener(v -> a.pop());
        bar.addView(back);
        TextView t = ui.label(title, 20, p.text, true);
        t.setSingleLine(true);
        bar.addView(t, ui.lpw(0, Ui.WRAP, 1f));
        if (right != null) bar.addView(right);
        return bar;
    }

    TextView sectionLabel(String s) {
        TextView t = ui.label(s, 13, p.sub, true);
        t.setPadding(ui.dp(22), ui.dp(18), ui.dp(22), ui.dp(8));
        t.setAllCaps(false);
        return t;
    }

    View empty(int icon, String title, String text) {
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER);
        col.setPadding(ui.dp(36), ui.dp(36), ui.dp(36), ui.dp(36));
        android.widget.ImageView ic = ui.icon(icon, 56, ui.dim(p.sub, 120));
        col.addView(ic, ui.lpm(ui.dp(56), ui.dp(56), 0, 0, 0, 14));
        TextView t = ui.label(title, 18, p.text, true);
        t.setGravity(Gravity.CENTER);
        col.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        if (text != null && !text.isEmpty()) {
            TextView s = ui.label(text, 14, p.sub, false);
            s.setGravity(Gravity.CENTER);
            s.setPadding(0, ui.dp(6), 0, 0);
            col.addView(s, ui.lp(Ui.MATCH, Ui.WRAP));
        }
        return col;
    }
}
