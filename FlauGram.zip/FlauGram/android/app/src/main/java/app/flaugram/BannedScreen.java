package app.flaugram;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Аккаунт заблокирован владельцем. */
final class BannedScreen extends Screen {
    private final String reason;

    BannedScreen(MainActivity a, String reason) {
        super(a);
        this.reason = reason == null ? "" : reason;
    }

    @Override
    View build() {
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER);
        col.setBackgroundColor(p.bg);
        col.setPadding(ui.dp(32), ui.dp(32), ui.dp(32), ui.dp(32));
        col.addView(ui.icon(R.drawable.ic_block, 72, p.danger), ui.lpm(ui.dp(72), ui.dp(72), 0, 0, 0, 18));
        TextView t = ui.label(ui.t(R.string.banned_title), 24, p.text, true);
        t.setGravity(Gravity.CENTER);
        col.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        String body = reason.isEmpty() ? ui.t(R.string.banned_text) : ui.t(R.string.banned_reason, reason);
        TextView s = ui.label(body, 15, p.sub, false);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, ui.dp(10), 0, ui.dp(28));
        col.addView(s, ui.lp(Ui.MATCH, Ui.WRAP));
        TextView out = ui.softButton(ui.t(R.string.logout), p.text);
        out.setOnClickListener(v -> a.logout(null));
        col.addView(out, ui.lp(Ui.MATCH, Ui.WRAP));
        return col;
    }
}
