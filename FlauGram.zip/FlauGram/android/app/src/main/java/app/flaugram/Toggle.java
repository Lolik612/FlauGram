package app.flaugram;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Переключатель в стиле iOS. */
final class Toggle extends View {
    interface Listener {
        void changed(boolean on);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final int onColor, offColor;
    private final float d;
    private boolean on;
    private float pos;
    private Listener listener;

    Toggle(Context c, int onColor, int offColor, boolean on) {
        super(c);
        this.onColor = onColor;
        this.offColor = offColor;
        this.on = on;
        this.pos = on ? 1f : 0f;
        this.d = c.getResources().getDisplayMetrics().density;
        setClickable(true);
        setOnClickListener(v -> set(!this.on, true));
    }

    void setListener(Listener l) {
        listener = l;
    }

    boolean isOn() {
        return on;
    }

    void set(boolean value, boolean notify) {
        if (value == on) return;
        on = value;
        ValueAnimator va = ValueAnimator.ofFloat(pos, on ? 1f : 0f);
        va.setDuration(160);
        va.addUpdateListener(a -> {
            pos = (Float) a.getAnimatedValue();
            invalidate();
        });
        va.start();
        if (notify && listener != null) listener.changed(on);
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(Math.round(50 * d), Math.round(30 * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        int col = blend(offColor, onColor, pos);
        paint.setColor(col);
        rect.set(0, 0, w, h);
        c.drawRoundRect(rect, h / 2, h / 2, paint);
        paint.setColor(0xFFFFFFFF);
        float r = h / 2 - 3 * d;
        float cx = h / 2 + pos * (w - h);
        c.drawCircle(cx, h / 2, r, paint);
    }

    private static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
