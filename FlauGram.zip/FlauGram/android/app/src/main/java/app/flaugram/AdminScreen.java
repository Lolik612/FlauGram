package app.flaugram;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Админ-панель владельца: статистика и переходы к пользователям, рассылке и значкам. */
final class AdminScreen extends Screen {
    private LinearLayout stats;

    AdminScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout root = ui.vertical();
        root.setBackgroundColor(p.bg);
        root.addView(topBar(ui.t(R.string.admin_title), null), ui.lp(Ui.MATCH, Ui.WRAP));
        ScrollView sv = new ScrollView(a);
        LinearLayout col = ui.vertical();
        col.setPadding(ui.dp(16), ui.dp(6), ui.dp(16), ui.dp(30));

        stats = ui.vertical();
        col.addView(stats, ui.lp(Ui.MATCH, Ui.WRAP));

        LinearLayout g = ui.card();
        LinearLayout r1 = ui.settingRow(R.drawable.ic_users, 0xFF0A84FF, ui.t(R.string.admin_users), ui.t(R.string.admin_users_sub), null);
        r1.setOnClickListener(v -> a.push(new AdminUsersScreen(a)));
        g.addView(r1);
        g.addView(ui.divider());
        LinearLayout r2 = ui.settingRow(R.drawable.ic_send, 0xFFFF9F0A, ui.t(R.string.admin_broadcast), ui.t(R.string.admin_broadcast_sub), null);
        r2.setOnClickListener(v -> a.push(new BroadcastScreen(a)));
        g.addView(r2);
        g.addView(ui.divider());
        LinearLayout r3 = ui.settingRow(R.drawable.ic_verified, 0xFF30D158, ui.t(R.string.admin_my_badge), ui.t(R.string.admin_my_badge_sub), null);
        r3.setOnClickListener(v -> {
            Model.Row me = new Model.Row();
            me.user = Session.me;
            me.name = Session.meName;
            me.isOwnerAccount = true;
            a.push(new BadgeScreen(a, me));
        });
        g.addView(r3);
        g.addView(ui.divider());
        LinearLayout r4 = ui.settingRow(R.drawable.ic_send, 0xFF0A84FF, ui.t(R.string.admin_mail), ui.t(R.string.admin_mail_sub), null);
        r4.setOnClickListener(v -> a.push(new AdminMailScreen(a)));
        g.addView(r4);
        g.addView(ui.divider());
        LinearLayout r5 = ui.settingRow(R.drawable.ic_download, 0xFF5E5CE6, ui.t(R.string.admin_upd), ui.t(R.string.admin_upd_sub), null);
        r5.setOnClickListener(v -> {
            a.toast(ui.t(R.string.update_checking));
            a.api("POST", "/admin/update_check", null, r -> {
                if (r.code == 200 && r.json != null) a.toast(r.json.optString("result") + " · v" + r.json.optInt("code"));
                else a.toast(a.errText(r));
            });
        });
        g.addView(r5);
        col.addView(g, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));

        TextView hint = ui.label(ui.t(R.string.admin_hint), 13, p.sub, false);
        hint.setPadding(ui.dp(8), ui.dp(14), ui.dp(8), 0);
        col.addView(hint);

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, ui.lpw(Ui.MATCH, 0, 1f));
        return root;
    }

    @Override
    void onShow() {
        a.api("GET", "/admin/stats", null, r -> {
            if (r.code != 200 || r.json == null) return;
            fillStats(r.json);
        });
    }

    private void fillStats(JSONObject o) {
        stats.removeAllViews();
        String[][] items = {
                {String.valueOf(o.optInt("users")), ui.t(R.string.st_users)},
                {String.valueOf(o.optInt("online")), ui.t(R.string.st_online)},
                {String.valueOf(o.optInt("new_today")), ui.t(R.string.st_new_today)},
                {String.valueOf(o.optInt("active_today")), ui.t(R.string.st_active_today)},
                {String.valueOf(o.optInt("messages")), ui.t(R.string.st_messages)},
                {String.valueOf(o.optInt("messages_today")), ui.t(R.string.st_messages_today)},
                {String.valueOf(o.optInt("photos")), ui.t(R.string.st_photos)},
                {String.valueOf(o.optInt("groups") + o.optInt("channels")), ui.t(R.string.st_chats)},
                {String.valueOf(o.optInt("banned")), ui.t(R.string.st_banned)},
                {size(o.optLong("bytes")), ui.t(R.string.st_size)},
        };
        for (int i = 0; i < items.length; i += 2) {
            LinearLayout row = ui.horizontal();
            row.addView(tile(items[i][0], items[i][1]), ui.lpm(0, Ui.WRAP, 0, 0, 5, 10));
            ((LinearLayout.LayoutParams) row.getChildAt(0).getLayoutParams()).weight = 1f;
            row.addView(tile(items[i + 1][0], items[i + 1][1]), ui.lpm(0, Ui.WRAP, 5, 0, 0, 10));
            ((LinearLayout.LayoutParams) row.getChildAt(1).getLayoutParams()).weight = 1f;
            stats.addView(row, ui.lp(Ui.MATCH, Ui.WRAP));
        }
    }

    private String size(long b) {
        if (b < 1024 * 1024) return (b / 1024) + " KB";
        return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
    }

    private View tile(String value, String label) {
        LinearLayout t = ui.vertical();
        t.setBackground(ui.rounded(p.surface, 20));
        t.setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14));
        t.setGravity(Gravity.START);
        t.addView(ui.label(value, 26, p.text, true));
        t.addView(ui.label(label, 13, p.sub, false));
        return t;
    }
}
