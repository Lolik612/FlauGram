package app.flaugram;

import android.graphics.Color;
import android.view.View;
import android.widget.ImageView;

/** Значок подтверждения рядом с именем. Нажатие показывает текст, который задал владелец. */
final class BadgeView extends ImageView {
    private final MainActivity a;
    private final int sizePx;

    BadgeView(MainActivity a, int sizeDp) {
        super(a);
        this.a = a;
        this.sizePx = a.ui.dp(sizeDp);
        setScaleType(ScaleType.FIT_CENTER);
        setVisibility(GONE);
    }

    static int iconRes(String kind) {
        if ("star".equals(kind)) return R.drawable.ic_star;
        if ("crown".equals(kind)) return R.drawable.ic_crown;
        if ("fire".equals(kind)) return R.drawable.ic_fire;
        if ("bolt".equals(kind)) return R.drawable.ic_bolt;
        if ("heart".equals(kind)) return R.drawable.ic_heart_solid;
        if ("shield".equals(kind)) return R.drawable.ic_shield;
        if ("diamond".equals(kind)) return R.drawable.ic_diamond;
        return R.drawable.ic_verified;
    }

    static int iconColor(Palette p, String kind) {
        if ("star".equals(kind) || "crown".equals(kind)) return 0xFFFFC107;
        if ("fire".equals(kind)) return 0xFFFF7A1A;
        if ("bolt".equals(kind)) return 0xFFFFD60A;
        if ("heart".equals(kind)) return 0xFFFF4D6A;
        if ("shield".equals(kind)) return 0xFF34C759;
        if ("diamond".equals(kind)) return 0xFF3DD6F5;
        return p.accent;
    }

    static final String[] KINDS = {"check", "star", "crown", "fire", "bolt", "heart", "shield", "diamond"};

    /** Текст по нажатию: свой, а если пустой, то стандартный. */
    static String message(MainActivity a, String user, Model.Badge b) {
        if (b != null && !b.text.isEmpty()) return b.text;
        return b != null && b.owner ? a.getString(R.string.verified_owner, user) : a.getString(R.string.verified_user, user);
    }

    void bind(final String user, final Model.Badge b) {
        if (b == null) {
            setVisibility(GONE);
            setOnClickListener(null);
            setClickable(false);
            return;
        }
        setVisibility(VISIBLE);
        if ("custom".equals(b.kind) && b.ver > 0) {
            setColorFilter(null);
            setImageDrawable(null);
            Images.badge(this, user, b.ver, sizePx, Session.token);
        } else {
            setTag(null);
            setImageDrawable(a.ui.drawable(iconRes(b.kind), iconColor(a.ui.p, b.kind)));
        }
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                new Sheet(a).badgeInfo(user, b).show();
            }
        });
    }

    static int white() {
        return Color.WHITE;
    }
}
