package app.flaugram;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Вкладка «Профиль»: большая обложка-фото на всю ширину, имя поверх неё, три кнопки и карточка с данными. */
final class ProfileTab extends Tab {
    private ImageView cover;
    private NameLine name;
    private TextView status, username, bioText, likeText;
    private LinearLayout bioRow;
    private int likes;

    ProfileTab(ShellScreen shell) {
        super(shell);
    }

    @Override
    View build() {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(p.bg);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = ui.vertical();
        col.setPadding(0, 0, 0, navPad());

        int coverH = Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.5f);
        FrameLayout top = new FrameLayout(a);
        cover = new ImageView(a);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(cover, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        View shade = new View(a);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x55000000, 0x00000000, 0x00000000, 0xB0000000}));
        top.addView(shade, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        top.setOnClickListener(v -> a.push(new EditProfileScreen(a)));

        ImageView qr = ui.iconButton(R.drawable.ic_qr, 0xFFFFFFFF);
        qr.setOnClickListener(v -> a.copy("@" + Session.me));
        top.addView(qr, new FrameLayout.LayoutParams(ui.dp(48), ui.dp(48), Gravity.TOP | Gravity.START));
        ImageView more = ui.iconButton(R.drawable.ic_more, 0xFFFFFFFF);
        more.setOnClickListener(v -> menu());
        top.addView(more, new FrameLayout.LayoutParams(ui.dp(48), ui.dp(48), Gravity.TOP | Gravity.END));

        LinearLayout bottom = ui.vertical();
        bottom.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(14));
        name = new NameLine(a, 30, 0xFFFFFFFF, true, 26);
        bottom.addView(name, ui.lp(Ui.MATCH, Ui.WRAP));
        status = ui.label(ui.t(R.string.status_online), 16, 0xDDFFFFFF, false);
        bottom.addView(status, ui.lpm(Ui.WRAP, Ui.WRAP, 2, 2, 0, 14));
        LinearLayout actions = ui.horizontal();
        LinearLayout tPhoto = tile(R.drawable.ic_image, ui.t(R.string.act_photo));
        LinearLayout tEdit = tile(R.drawable.ic_edit, ui.t(R.string.act_edit));
        LinearLayout tSet = tile(R.drawable.ic_gear, ui.t(R.string.tab_settings));
        LinearLayout[] ts = {tPhoto, tEdit, tSet};
        for (int i = 0; i < ts.length; i++) {
            actions.addView(ts[i], ui.lpm(0, ui.dp(66), i == 0 ? 0 : 5, 0, i == 2 ? 0 : 5, 0));
            ((LinearLayout.LayoutParams) ts[i].getLayoutParams()).weight = 1f;
        }
        bottom.addView(actions, ui.lp(Ui.MATCH, Ui.WRAP));
        tPhoto.setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        tEdit.setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        tSet.setOnClickListener(v -> shell.select(2));
        top.addView(bottom, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM));
        col.addView(top, ui.lp(Ui.MATCH, coverH));

        LinearLayout card = ui.card();
        card.setPadding(ui.dp(22), ui.dp(10), ui.dp(22), ui.dp(10));
        bioRow = ui.vertical();
        bioText = ui.label("", 17, p.text, false);
        bioRow.addView(bioText);
        bioRow.addView(ui.label(ui.t(R.string.profile_bio), 14, p.sub, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 3, 0, 0));
        bioRow.setPadding(0, ui.dp(10), 0, ui.dp(10));
        card.addView(bioRow, ui.lp(Ui.MATCH, Ui.WRAP));

        LinearLayout un = ui.horizontal();
        un.setPadding(0, ui.dp(10), 0, ui.dp(10));
        LinearLayout unText = ui.vertical();
        username = ui.label("", 17, p.text, false);
        username.setSingleLine(true);
        unText.addView(username);
        unText.addView(ui.label(ui.t(R.string.username_label), 14, p.sub, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 3, 0, 0));
        un.addView(unText, ui.lpw(0, Ui.WRAP, 1f));
        ImageView copy = ui.icon(R.drawable.ic_copy, 24, p.sub);
        un.addView(copy);
        un.setClickable(true);
        un.setOnClickListener(v -> a.copy("@" + Session.me));
        card.addView(un, ui.lp(Ui.MATCH, Ui.WRAP));

        LinearLayout lk = ui.horizontal();
        lk.setPadding(0, ui.dp(10), 0, ui.dp(10));
        lk.addView(ui.icon(R.drawable.ic_heart_solid, 22, 0xFFFF5A7A), ui.lpm(ui.dp(22), ui.dp(22), 0, 0, 14, 0));
        likeText = ui.label("", 17, p.text, false);
        lk.addView(likeText);
        card.addView(lk, ui.lp(Ui.MATCH, Ui.WRAP));
        col.addView(card, ui.lpm(Ui.MATCH, Ui.WRAP, 12, 12, 12, 0));

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        bind(null);
        return sv;
    }

    private void menu() {
        new Sheet(a).title("@" + Session.me)
                .item(R.drawable.ic_copy, ui.t(R.string.copy_username), 0, () -> a.copy("@" + Session.me))
                .item(R.drawable.ic_edit, ui.t(R.string.edit_profile), 0, () -> a.push(new EditProfileScreen(a)))
                .item(R.drawable.ic_key, ui.t(R.string.act_key), 0, () -> SettingsTab.keySheet(a))
                .show();
    }

    private LinearLayout tile(int icon, String label) {
        LinearLayout t = ui.vertical();
        t.setGravity(Gravity.CENTER);
        t.setBackground(ui.ripple(0x66000000, 18));
        t.setClickable(true);
        t.addView(ui.icon(icon, 24, 0xFFFFFFFF), ui.lpm(ui.dp(24), ui.dp(24), 0, 0, 0, 5));
        TextView tv = ui.label(label, 13, 0xFFFFFFFF, true);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        t.addView(tv);
        return t;
    }

    private void bind(Model.Row r) {
        Images.cover(cover, Session.me, Session.meName, Session.meAvatar, Session.token);
        Model.Badge b = r == null ? null : r.badge;
        name.set(Session.meName, Session.me, b);
        username.setText("@" + Session.me);
        bioRow.setVisibility(Session.meBio.isEmpty() ? View.GONE : View.VISIBLE);
        bioText.setText(Session.meBio);
        if (r != null) likes = r.likes;
        likeText.setText(ui.t(R.string.likes_mine, likes));
    }

    @Override
    void onSelected() {
        bind(null);
        a.api("GET", "/user?name=" + Api.enc(Session.me), null, r -> {
            if (r.code != 200 || r.json == null) return;
            Model.Row row = Model.user(r.json);
            if (row != null) bind(row);
        });
    }

    @Override
    void onMeChanged() {
        if (name != null) bind(null);
    }
}
