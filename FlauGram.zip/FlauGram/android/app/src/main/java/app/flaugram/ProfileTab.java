package app.flaugram;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Вкладка «Профиль»: мой профиль в том же стиле, что и профиль другого человека. */
final class ProfileTab extends Tab {
    private AvatarView avatar;
    private NameLine name;
    private TextView status, likeCount, username, bioText;
    private LinearLayout bioCard;
    private int likes;

    ProfileTab(ShellScreen shell) {
        super(shell);
    }

    @Override
    View build() {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(p.bg);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, ui.dp(24), 0, navPad());

        avatar = new AvatarView(a, ui.dp(132), ui.dp(250));
        avatar.setGlow(p.accent);
        avatar.image().setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        col.addView(avatar, ui.lp(ui.dp(250), ui.dp(250)));
        name = new NameLine(a, 23, p.text, true, 22).center();
        col.addView(name, ui.lpm(Ui.WRAP, Ui.WRAP, 24, 2, 24, 0));
        status = ui.label(ui.t(R.string.status_online), 16, p.accent, false);
        status.setGravity(Gravity.CENTER);
        col.addView(status, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 2, 0, 22));

        LinearLayout actions = ui.horizontal();
        actions.setPadding(ui.dp(8), 0, ui.dp(8), 0);
        LinearLayout tPhoto = tile(R.drawable.ic_image, ui.t(R.string.act_photo));
        LinearLayout tEdit = tile(R.drawable.ic_edit, ui.t(R.string.act_edit));
        LinearLayout tKey = tile(R.drawable.ic_key, ui.t(R.string.act_key));
        LinearLayout tCopy = tile(R.drawable.ic_copy, ui.t(R.string.act_copy));
        LinearLayout tLike = tile(R.drawable.ic_heart, "0");
        likeCount = (TextView) tLike.getChildAt(1);
        for (LinearLayout t : new LinearLayout[]{tPhoto, tEdit, tKey, tCopy, tLike}) {
            actions.addView(t, ui.lpm(0, ui.dp(88), 4, 0, 4, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        col.addView(actions, ui.lp(Ui.MATCH, Ui.WRAP));
        tPhoto.setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        tEdit.setOnClickListener(v -> a.push(new EditProfileScreen(a)));
        tKey.setOnClickListener(v -> SettingsTab.keySheet(a));
        tCopy.setOnClickListener(v -> a.copy("@" + Session.me));
        tLike.setOnClickListener(v -> a.toast(ui.t(R.string.likes_mine, likes)));

        LinearLayout uname = ui.horizontal();
        uname.setPadding(ui.dp(28), ui.dp(30), ui.dp(28), ui.dp(6));
        LinearLayout un = ui.vertical();
        username = ui.label("", 23, p.text, false);
        username.setSingleLine(true);
        un.addView(username);
        un.addView(ui.label(ui.t(R.string.username_label), 15, p.text, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 6, 0, 0));
        uname.addView(un, ui.lpw(0, Ui.WRAP, 1f));
        ImageView qr = ui.icon(R.drawable.ic_qr, 36, p.sub);
        qr.setOnClickListener(v -> a.copy("@" + Session.me));
        uname.addView(qr);
        col.addView(uname, ui.lp(Ui.MATCH, Ui.WRAP));

        bioCard = ui.card();
        bioCard.setPadding(ui.dp(18), ui.dp(14), ui.dp(18), ui.dp(14));
        bioText = ui.label("", 16, p.text, false);
        bioCard.addView(bioText);
        bioCard.addView(ui.label(ui.t(R.string.profile_bio), 13, p.sub, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 4, 0, 0));
        col.addView(bioCard, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 16, 16, 0));

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        bind(null);
        return sv;
    }

    private LinearLayout tile(int icon, String label) {
        LinearLayout t = ui.vertical();
        t.setGravity(Gravity.CENTER);
        t.setBackground(ui.ripple(p.card, 22));
        t.setClickable(true);
        t.addView(ui.icon(icon, 28, p.text), ui.lpm(ui.dp(28), ui.dp(28), 0, 0, 0, 8));
        TextView tv = ui.label(label, 13, p.text, true);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        t.addView(tv);
        return t;
    }

    private void bind(Model.Row r) {
        avatar.bindMe();
        Model.Badge b = r == null ? null : r.badge;
        name.set(Session.meName, Session.me, b);
        username.setText("@" + Session.me);
        bioCard.setVisibility(Session.meBio.isEmpty() ? View.GONE : View.VISIBLE);
        bioText.setText(Session.meBio);
        if (r != null) likes = r.likes;
        likeCount.setText(String.valueOf(likes));
    }

    @Override
    void onSelected() {
        bind(null);
        a.api("GET", "/user?name=" + Api.enc(Session.me), null, r -> {
            if (r.code != 200 || r.json == null) return;
            Model.Row row = Model.user(r.json);
            if (row != null) bind(row);
        });
    }

    @Override
    void onMeChanged() {
        if (name != null) bind(null);
    }
}
