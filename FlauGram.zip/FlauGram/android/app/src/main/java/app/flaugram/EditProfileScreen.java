package app.flaugram;

import android.net.Uri;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Изменение имени, описания и фото. Юзернейм менять нельзя. */
final class EditProfileScreen extends Screen {
    private static final int REQ_AVATAR = 3;
    private AvatarView avatar;
    private EditText nameEd, bioEd;

    EditProfileScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout root = ui.vertical();
        root.setBackgroundColor(p.bg);
        TextView save = ui.label(ui.t(R.string.save), 17, p.accent, true);
        save.setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10));
        save.setClickable(true);
        root.addView(topBar(ui.t(R.string.edit_profile), save), ui.lp(Ui.MATCH, Ui.WRAP));

        ScrollView sv = new ScrollView(a);
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(ui.dp(18), ui.dp(8), ui.dp(18), ui.dp(30));

        avatar = new AvatarView(a, ui.dp(112), ui.dp(210));
        avatar.setGlow(p.accent);
        avatar.bindMe();
        avatar.image().setOnClickListener(v -> a.pickImage(this, REQ_AVATAR));
        col.addView(avatar, ui.lp(ui.dp(210), ui.dp(210)));

        LinearLayout links = ui.horizontal();
        links.setGravity(Gravity.CENTER);
        TextView change = ui.label(ui.t(R.string.profile_change_photo), 15, p.accent, true);
        change.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6));
        change.setOnClickListener(v -> a.pickImage(this, REQ_AVATAR));
        links.addView(change);
        TextView remove = ui.label(ui.t(R.string.profile_remove_photo), 15, p.danger, true);
        remove.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6));
        remove.setOnClickListener(v -> a.api("POST", "/avatar/remove", new org.json.JSONObject(), r -> {
            if (r.code == 200) {
                Session.saveMe(Session.meName, Session.meBio, 0, Session.admin, Session.verified);
                Images.forget();
                avatar.bindMe();
                a.refreshMe();
            } else {
                a.toast(a.errText(r));
            }
        }));
        links.addView(remove);
        col.addView(links, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 0, 0, 14));

        TextView l1 = ui.label(ui.t(R.string.profile_display_name), 13, p.sub, true);
        l1.setPadding(ui.dp(6), 0, 0, ui.dp(6));
        col.addView(l1, ui.lp(Ui.MATCH, Ui.WRAP));
        nameEd = ui.edit(ui.t(R.string.reg_display_hint));
        nameEd.setSingleLine(true);
        nameEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        nameEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        nameEd.setText(Session.meName);
        col.addView(nameEd, ui.lp(Ui.MATCH, Ui.WRAP));

        TextView l2 = ui.label(ui.t(R.string.profile_bio), 13, p.sub, true);
        l2.setPadding(ui.dp(6), ui.dp(16), 0, ui.dp(6));
        col.addView(l2, ui.lp(Ui.MATCH, Ui.WRAP));
        bioEd = ui.edit(ui.t(R.string.profile_bio_hint));
        bioEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        bioEd.setMinLines(3);
        bioEd.setGravity(Gravity.TOP);
        bioEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        bioEd.setText(Session.meBio);
        col.addView(bioEd, ui.lp(Ui.MATCH, Ui.WRAP));

        TextView un = ui.label("@" + Session.me + "  ·  " + ui.t(R.string.username_fixed), 13, p.sub, false);
        un.setPadding(ui.dp(6), ui.dp(14), 0, 0);
        col.addView(un, ui.lp(Ui.MATCH, Ui.WRAP));

        save.setOnClickListener(v -> save());
        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, ui.lpw(Ui.MATCH, 0, 1f));
        return root;
    }

    private void save() {
        final String name = nameEd.getText().toString().trim();
        final String bio = bioEd.getText().toString().trim();
        if (name.isEmpty()) {
            a.toast(ui.t(R.string.err_chat_title));
            return;
        }
        a.api("POST", "/profile", Api.obj("display_name", name, "bio", bio), r -> {
            if (r.code == 200 && r.json != null) {
                Session.saveMe(r.json.optString("display_name", name), r.json.optString("bio", bio), Session.meAvatar,
                        Session.admin, Session.verified);
                a.toast(ui.t(R.string.profile_saved));
                a.refreshMe();
                a.pop();
            } else {
                a.toast(a.errText(r));
            }
        });
    }

    @Override
    void onResult(int req, final Uri uri) {
        if (req != REQ_AVATAR) return;
        a.toast(ui.t(R.string.preparing));
        a.io.execute(() -> {
            final Images.Encoded e = Images.encode(a, uri, 512, true, 800 * 1024);
            a.runOnUiThread(() -> {
                if (e == null) {
                    a.toast(ui.t(R.string.err_bad_image));
                    return;
                }
                a.apiBytes("/avatar", e.data, r -> {
                    if (r.code == 200 && r.json != null) {
                        Session.saveMe(Session.meName, Session.meBio, r.json.optLong("avatar"), Session.admin, Session.verified);
                        Images.forget();
                        avatar.bindMe();
                        a.refreshMe();
                    } else {
                        a.toast(a.errText(r));
                    }
                });
            });
        });
    }
}
