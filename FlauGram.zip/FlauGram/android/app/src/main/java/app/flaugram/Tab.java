package app.flaugram;

import android.view.View;

import java.util.List;

/** Вкладка нижней панели. */
abstract class Tab {
    final MainActivity a;
    final Ui ui;
    final Palette p;
    final ShellScreen shell;
    private View view;

    Tab(ShellScreen shell) {
        this.shell = shell;
        this.a = shell.a;
        this.ui = a.ui;
        this.p = a.ui.p;
    }

    View view() {
        if (view == null) view = build();
        return view;
    }

    abstract View build();

    /** Вкладку открыли или вернулись на неё. */
    void onSelected() { }

    void onUpdates(List<Model.Msg> list) { }

    void onMeChanged() { }

    /** Нижний отступ, чтобы последний элемент списка не прятался под плавающей панелью. */
    int navPad() {
        return ui.dp(104);
    }
}
