package app.flaugram;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** Вкладка «Контакты»: сохранённые люди и поиск по юзернейму. */
final class ContactsTab extends Tab {
    private RowAdapter adapter;
    private FrameLayout emptyHolder;
    private final List<Model.Row> contacts = new ArrayList<>();
    private boolean loaded, searching;
    private String lastQuery = "";
    private Runnable pending;

    ContactsTab(ShellScreen shell) {
        super(shell);
    }

    @Override
    View build() {
        LinearLayout col = ui.vertical();
        col.setBackgroundColor(p.bg);
        TextView title = ui.label(ui.t(R.string.tab_contacts), 30, p.text, true);
        title.setPadding(ui.dp(22), ui.dp(14), ui.dp(22), ui.dp(4));
        col.addView(title, ui.lp(Ui.MATCH, Ui.WRAP));
        SearchPill pill = new SearchPill(a, ui.t(R.string.contacts_search_hint), this::onQuery);
        col.addView(pill, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 8, 16, 6));

        FrameLayout frame = new FrameLayout(a);
        ListView list = new ListView(a);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0));
        list.setClipToPadding(false);
        list.setPadding(0, ui.dp(4), 0, navPad());
        adapter = new RowAdapter(a, RowAdapter.PEOPLE);
        list.setAdapter(adapter);
        frame.addView(list, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        emptyHolder = new FrameLayout(a);
        frame.addView(emptyHolder, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH, Gravity.CENTER));
        col.addView(frame, ui.lpw(Ui.MATCH, 0, 1f));
        list.setOnItemClickListener((parent, v, pos, id) -> a.push(new UserScreen(a, (Model.Row) adapter.getItem(pos))));
        showEmpty(false);
        return col;
    }

    private void showEmpty(boolean visible) {
        emptyHolder.removeAllViews();
        if (!visible || !loaded) return;
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER);
        col.setPadding(ui.dp(36), ui.dp(36), ui.dp(36), ui.dp(80));
        ImageView ic = ui.icon(searching ? R.drawable.ic_search : R.drawable.ic_person, 56, ui.dim(p.sub, 120));
        col.addView(ic, ui.lpm(ui.dp(56), ui.dp(56), 0, 0, 0, 14));
        TextView t = ui.label(searching ? ui.t(R.string.search_none) : ui.t(R.string.contacts_empty_title), 18, p.text, true);
        t.setGravity(Gravity.CENTER);
        col.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        if (!searching) {
            TextView s = ui.label(ui.t(R.string.contacts_empty), 14, p.sub, false);
            s.setGravity(Gravity.CENTER);
            s.setPadding(0, ui.dp(6), 0, 0);
            col.addView(s, ui.lp(Ui.MATCH, Ui.WRAP));
        }
        emptyHolder.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.CENTER));
    }

    private void onQuery(final String q) {
        lastQuery = q;
        if (pending != null) a.h.removeCallbacks(pending);
        if (q.isEmpty()) {
            searching = false;
            adapter.set(contacts);
            showEmpty(contacts.isEmpty());
            return;
        }
        searching = true;
        pending = () -> a.api("GET", "/search?q=" + Api.enc(q), null, r -> {
            if (!searching || !q.equals(lastQuery)) return;
            if (r.netFail || r.code != 200 || r.json == null) {
                a.toast(a.netMsg());
                return;
            }
            adapter.set(parse(r.json.optJSONArray("users")));
            showEmpty(adapter.getCount() == 0);
        });
        a.h.postDelayed(pending, 250);
    }

    private List<Model.Row> parse(JSONArray arr) {
        List<Model.Row> rows = new ArrayList<>();
        if (arr == null) return rows;
        for (int i = 0; i < arr.length(); i++) {
            Model.Row row = Model.user(arr.optJSONObject(i));
            if (row == null) continue;
            String st = Model.statusText(a, row.status);
            row.sub = st.isEmpty() ? "@" + row.user : st;
            rows.add(row);
        }
        return rows;
    }

    @Override
    void onSelected() {
        a.api("GET", "/contacts", null, r -> {
            if (r.netFail || r.code != 200 || r.json == null) return;
            contacts.clear();
            contacts.addAll(parse(r.json.optJSONArray("users")));
            loaded = true;
            if (!searching) {
                adapter.set(contacts);
                showEmpty(contacts.isEmpty());
            }
        });
    }
}
