package app.flaugram;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Модели данных и разбор ответов сервера. */
final class Model {
    private Model() { }

    /** Значок подтверждения: kind (galochka и т.п. или custom), текст по нажатию, версия своей картинки. */
    static class Badge {
        String kind = "check", text = "";
        long ver;
        boolean owner;
    }

    static Badge badge(JSONObject o) {
        if (o == null) return null;
        Badge b = new Badge();
        b.kind = o.optString("kind", "check");
        b.text = o.optString("text");
        b.ver = o.optLong("ver");
        b.owner = o.optBoolean("owner");
        return b;
    }

    static class Msg {
        long id, rev;
        String from = "", fromName = "", to = "", text = "", photo = "", chatTitle = "";
        long ts, fromAvatar, chat;
        boolean fromVerified, edited, deleted;
        Badge fromBadge;
        int w, h;
        long replyId;
        String replyFrom = "", replyName = "", replyText = "";
        boolean replyPhoto, replyDeleted;
        String fwd = "";
        boolean pinned, quiet;
        final List<Reaction> reactions = new ArrayList<>();

        /** Моя реакция на это сообщение или "". */
        String myReaction() {
            for (Reaction r : reactions) if (r.mine) return r.emoji;
            return "";
        }
    }

    static class Reaction {
        String emoji = "";
        int count;
        boolean mine;
    }

    /** Человек или группа: строка списка, шапка чата, экран профиля. */
    static class Row {
        String user = "", name = "", bio = "", sub = "", kind = "user", status = "";
        long avatar, ts, chatId;
        int unread, members, likes;
        boolean mine, verified, member = true, owner, liked, contact, isOwnerAccount, banned, seen, blocked, blockedMe;
        Badge badge;
        long id;

        boolean isChat() {
            return chatId > 0;
        }

        String title() {
            return name.isEmpty() ? user : name;
        }

        /** Ключ для «без звука». */
        String key() {
            return chatId > 0 ? "c:" + chatId : "u:" + user.toLowerCase();
        }
    }

    static Row user(JSONObject o) {
        if (o == null || o.optString("username").isEmpty()) return null;
        Row r = new Row();
        r.user = o.optString("username");
        r.name = o.optString("display_name");
        r.bio = o.optString("bio");
        r.avatar = o.optLong("avatar");
        r.verified = o.optBoolean("verified");
        r.badge = badge(o.optJSONObject("badge"));
        r.banned = o.optBoolean("banned");
        r.id = o.optLong("id");
        r.status = o.optString("status");
        r.likes = o.optInt("likes");
        r.liked = o.optBoolean("liked");
        r.contact = o.optBoolean("contact");
        r.isOwnerAccount = o.optBoolean("owner");
        r.blocked = o.optBoolean("blocked");
        r.blockedMe = o.optBoolean("blocked_me");
        return r;
    }

    static Row chat(JSONObject o) {
        if (o == null || o.optLong("id") <= 0) return null;
        Row r = new Row();
        r.chatId = o.optLong("id");
        r.kind = o.optString("kind", "group");
        r.name = o.optString("title");
        r.bio = o.optString("bio");
        r.avatar = o.optLong("avatar");
        r.members = o.optInt("members");
        r.member = o.optBoolean("member");
        r.owner = o.optBoolean("owner");
        return r;
    }

    static Msg msg(JSONObject o) {
        if (o == null) return null;
        Msg m = new Msg();
        m.id = o.optLong("id");
        m.rev = o.optLong("rev");
        m.from = o.optString("from");
        m.fromName = o.optString("from_name");
        m.fromAvatar = o.optLong("from_avatar");
        m.fromVerified = o.optBoolean("from_verified");
        m.fromBadge = badge(o.optJSONObject("from_badge"));
        m.chat = o.optLong("chat");
        m.chatTitle = o.optString("chat_title");
        m.to = o.optString("to");
        m.text = o.optString("text");
        m.ts = o.optLong("ts");
        m.edited = o.optBoolean("edited");
        m.deleted = o.optBoolean("deleted");
        if (!o.isNull("photo")) m.photo = o.optString("photo");
        m.w = o.optInt("w");
        m.h = o.optInt("h");
        m.fwd = o.optString("fwd");
        m.pinned = o.optBoolean("pinned");
        m.quiet = o.optBoolean("quiet");
        JSONArray rs = o.optJSONArray("reactions");
        if (rs != null) {
            for (int i = 0; i < rs.length(); i++) {
                JSONObject ro = rs.optJSONObject(i);
                if (ro == null) continue;
                Reaction x = new Reaction();
                x.emoji = ro.optString("e");
                x.count = ro.optInt("n");
                JSONArray us = ro.optJSONArray("u");
                if (us != null) {
                    for (int k = 0; k < us.length(); k++) if (Session.me != null && Session.me.equalsIgnoreCase(us.optString(k))) x.mine = true;
                }
                m.reactions.add(x);
            }
        }
        JSONObject r = o.optJSONObject("reply");
        if (r != null) {
            m.replyId = r.optLong("id");
            m.replyFrom = r.optString("from");
            m.replyName = r.optString("from_name");
            m.replyText = r.optString("text");
            m.replyPhoto = r.optBoolean("photo");
            m.replyDeleted = r.optBoolean("deleted");
        }
        return m.id > 0 ? m : null;
    }

    static List<Msg> msgs(JSONArray a) {
        List<Msg> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            Msg m = msg(a.optJSONObject(i));
            if (m != null) out.add(m);
        }
        return out;
    }

    /** Строка статуса: «в сети», «был(а) недавно» и так далее. */
    static String statusText(Context c, String code) {
        if ("online".equals(code)) return c.getString(R.string.status_online);
        if ("recently".equals(code)) return c.getString(R.string.status_recently);
        if ("week".equals(code)) return c.getString(R.string.status_week);
        if ("month".equals(code)) return c.getString(R.string.status_month);
        if ("long".equals(code)) return c.getString(R.string.status_long);
        return "";
    }
}
