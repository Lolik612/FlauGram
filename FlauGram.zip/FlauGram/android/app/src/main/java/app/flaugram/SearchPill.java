package app.flaugram;

import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;

/** Поле поиска в виде таблетки со значком лупы. */
final class SearchPill extends LinearLayout {
    interface Listener {
        void changed(String q);
    }

    final EditText field;

    SearchPill(MainActivity a, String hint, final Listener l) {
        super(a);
        Ui ui = a.ui;
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setBackground(ui.rounded(ui.p.input, 22));
        setPadding(ui.dp(14), 0, ui.dp(14), 0);
        addView(ui.icon(R.drawable.ic_search, 20, ui.p.sub), ui.lpm(ui.dp(20), ui.dp(20), 0, 0, 10, 0));
        field = new EditText(a);
        field.setHint(hint);
        field.setHintTextColor(ui.p.sub);
        field.setTextColor(ui.p.text);
        field.setTextSize(16);
        field.setBackground(null);
        field.setSingleLine(true);
        field.setPadding(0, ui.dp(12), 0, ui.dp(12));
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        field.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void afterTextChanged(Editable e) { l.changed(e.toString().trim()); }
        });
        addView(field, new LayoutParams(0, Ui.WRAP, 1f));
    }
}
