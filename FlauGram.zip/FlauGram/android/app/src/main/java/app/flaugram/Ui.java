package app.flaugram;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Мелкие помощники для построения экранов кодом. */
final class Ui {
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    final MainActivity a;
    final Palette p;
    private final float density;

    Ui(MainActivity a, Palette p) {
        this.a = a;
        this.p = p;
        this.density = a.getResources().getDisplayMetrics().density;
    }

    Context ctx() {
        return a;
    }

    int dp(float v) {
        return Math.round(v * density);
    }

    String t(int id, Object... args) {
        return a.getString(id, args);
    }

    LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    LinearLayout.LayoutParams lpw(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    LinearLayout.LayoutParams lpm(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.setMargins(dp(l), dp(t), dp(r), dp(b));
        return lp;
    }

    GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    /** Фон с закруглением и волной при нажатии. */
    Drawable ripple(int color, float radiusDp) {
        GradientDrawable content = rounded(color, radiusDp);
        GradientDrawable mask = rounded(0xFF000000, radiusDp);
        return new RippleDrawable(ColorStateList.valueOf(p.dark ? 0x33FFFFFF : 0x22000000), content, mask);
    }

    TextView label(String text, int sp, int color, boolean bold) {
        TextView tv = new TextView(a);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    TextView title(String text) {
        TextView tv = label(text, 30, p.text, true);
        tv.setSingleLine(true);
        return tv;
    }

    Drawable drawable(int res, int color) {
        Drawable d = a.getResources().getDrawable(res, a.getTheme()).mutate();
        d.setTint(color);
        return d;
    }

    ImageView icon(int res, float sizeDp, int color) {
        ImageView iv = new ImageView(a);
        iv.setImageDrawable(drawable(res, color));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setLayoutParams(lp(dp(sizeDp), dp(sizeDp)));
        return iv;
    }

    /** Круглая кнопка-иконка (стрелка назад, три точки и так далее). */
    ImageView iconButton(int res, int color) {
        ImageView iv = new ImageView(a);
        iv.setImageDrawable(drawable(res, color));
        iv.setScaleType(ImageView.ScaleType.CENTER);
        iv.setBackground(ripple(0x00000000, 24));
        iv.setClickable(true);
        iv.setLayoutParams(lp(dp(48), dp(48)));
        return iv;
    }

    TextView button(String text) {
        TextView tv = label(text, 16, Color.WHITE, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(16), dp(14), dp(16), dp(14));
        tv.setBackground(ripple(p.accent, 16));
        tv.setClickable(true);
        return tv;
    }

    TextView softButton(String text, int textColor) {
        TextView tv = label(text, 16, textColor, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(16), dp(14), dp(16), dp(14));
        tv.setBackground(ripple(p.card, 16));
        tv.setClickable(true);
        return tv;
    }

    EditText edit(String hint) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(p.sub);
        e.setTextColor(p.text);
        e.setTextSize(16);
        e.setBackground(rounded(p.input, 16));
        e.setPadding(dp(16), dp(12), dp(16), dp(12));
        return e;
    }

    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** Блок-карточка со скруглением. */
    LinearLayout card() {
        LinearLayout l = vertical();
        l.setBackground(rounded(p.surface, 22));
        return l;
    }

    View divider() {
        View v = new View(a);
        v.setBackgroundColor(p.divider);
        LinearLayout.LayoutParams lp = lp(MATCH, Math.max(1, dp(0.5f)));
        lp.leftMargin = dp(60);
        v.setLayoutParams(lp);
        return v;
    }

    View space(int hDp) {
        View v = new View(a);
        v.setLayoutParams(lp(1, dp(hDp)));
        return v;
    }

    /** Строка настроек: цветной значок в квадрате, заголовок, подпись, справа любой вид. */
    LinearLayout settingRow(int iconRes, int iconBg, String title, String sub, View right) {
        LinearLayout row = horizontal();
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.setBackground(ripple(0x00000000, 22));
        row.setClickable(true);
        LinearLayout box = new LinearLayout(a);
        box.setGravity(Gravity.CENTER);
        box.setBackground(rounded(iconBg, 10));
        box.addView(icon(iconRes, 18, Color.WHITE));
        row.addView(box, lpm(dp(34), dp(34), 0, 0, 14, 0));
        LinearLayout col = vertical();
        col.addView(label(title, 16, p.text, false));
        if (sub != null && !sub.isEmpty()) {
            TextView s = label(sub, 13, p.sub, false);
            col.addView(s);
        }
        row.addView(col, lpw(0, WRAP, 1f));
        if (right != null) row.addView(right);
        return row;
    }

    int dim(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}
