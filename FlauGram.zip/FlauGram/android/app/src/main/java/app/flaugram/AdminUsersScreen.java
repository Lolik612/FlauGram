package app.flaugram;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Список пользователей для владельца: поиск, бан, значок. */
final class AdminUsersScreen extends Screen {
    private RowAdapter adapter;
    private String query = "";
    private Runnable pending;

    AdminUsersScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout root = ui.vertical();
        root.setBackgroundColor(p.bg);
        root.addView(topBar(ui.t(R.string.admin_users), null), ui.lp(Ui.MATCH, Ui.WRAP));
        SearchPill pill = new SearchPill(a, ui.t(R.string.contacts_search_hint), q -> {
            query = q;
            if (pending != null) a.h.removeCallbacks(pending);
            pending = this::load;
            a.h.postDelayed(pending, 250);
        });
        root.addView(pill, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 4, 16, 8));
        ListView list = new ListView(a);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0));
        adapter = new RowAdapter(a, RowAdapter.PEOPLE);
        list.setAdapter(adapter);
        FrameLayout frame = new FrameLayout(a);
        frame.addView(list, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        root.addView(frame, ui.lpw(Ui.MATCH, 0, 1f));
        list.setOnItemClickListener((parent, v, pos, id) -> userMenu((Model.Row) adapter.getItem(pos)));
        return root;
    }

    @Override
    void onShow() {
        load();
    }

    private void load() {
        a.api("GET", "/admin/users?q=" + Api.enc(query), null, r -> {
            if (r.code != 200 || r.json == null) {
                if (r.code != 200) a.toast(a.errText(r));
                return;
            }
            List<Model.Row> rows = new ArrayList<>();
            JSONArray arr = r.json.optJSONArray("users");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    Model.Row row = Model.user(o);
                    if (row == null) continue;
                    String st = Model.statusText(a, row.status);
                    row.sub = (row.banned ? ui.t(R.string.banned_mark) + "  ·  " : "") + "@" + row.user + "  ·  "
                            + ui.t(R.string.st_msgs_count, o.optInt("msgs")) + (st.isEmpty() ? "" : "  ·  " + st);
                    rows.add(row);
                }
            }
            adapter.set(rows);
        });
    }

    private void userMenu(final Model.Row u) {
        Sheet s = new Sheet(a).title(u.title() + "  @" + u.user);
        s.item(R.drawable.ic_person, ui.t(R.string.menu_profile), 0, () -> a.push(new UserScreen(a, u)));
        s.item(R.drawable.ic_verified, ui.t(R.string.admin_badge), p.accent, () -> a.push(new BadgeScreen(a, u)));
        if (!u.isOwnerAccount && !u.user.equalsIgnoreCase(Session.me)) {
            if (u.banned) {
                s.item(R.drawable.ic_check, ui.t(R.string.admin_unban), p.ok, () -> setBan(a, u.user, false, "", this::load));
            } else {
                s.item(R.drawable.ic_block, ui.t(R.string.admin_ban), p.danger, () -> banDialog(a, u.user, this::load));
            }
        }
        s.show();
    }

    static void banDialog(final MainActivity a, final String user, final Runnable done) {
        Sheet.input(a, a.getString(R.string.admin_ban_title, user), a.getString(R.string.admin_ban_reason), "", 60, false,
                a.getString(R.string.admin_ban), reason -> setBan(a, user, true, reason, done));
    }

    static void setBan(final MainActivity a, String user, final boolean ban, String reason, final Runnable done) {
        a.api("POST", "/admin/ban", Api.obj("username", user, "banned", Boolean.valueOf(ban), "reason", reason), r -> {
            if (r.code == 200) {
                a.toast(a.getString(ban ? R.string.admin_banned_done : R.string.admin_unbanned_done));
                if (done != null) done.run();
            } else {
                a.toast(a.errText(r));
            }
        });
    }
}
