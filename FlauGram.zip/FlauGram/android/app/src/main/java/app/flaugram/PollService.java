package app.flaugram;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Фоновое соединение с сервером: держит long-poll и показывает уведомления о новых сообщениях,
 * пока приложение закрыто. Без Google Play Services Android требует держать постоянное уведомление —
 * оно минимальное и тихое, текста в нём нет.
 */
public class PollService extends Service {
    static final String CH_MSG = "messages";
    static final String CH_BG = "background";
    static final int FG_ID = 1;
    static final int MSG_ID = 2;

    private volatile boolean running = false;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, PollService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) {
            // система не разрешила запуск из фона, повторим при следующем открытии приложения
        }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, PollService.class));
        } catch (Exception ignored) {
            // сервис уже остановлен
        }
    }

    static String tag(String user) {
        return user.toLowerCase(Locale.ROOT);
    }

    static String chatTag(long id) {
        return "chat" + id;
    }

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel msg = new NotificationChannel(CH_MSG, c.getString(R.string.ch_messages), NotificationManager.IMPORTANCE_HIGH);
        msg.enableVibration(true);
        nm.createNotificationChannel(msg);
        NotificationChannel bg = new NotificationChannel(CH_BG, c.getString(R.string.ch_background), NotificationManager.IMPORTANCE_MIN);
        bg.setDescription(c.getString(R.string.ch_background_desc));
        bg.setShowBadge(false);
        nm.createNotificationChannel(bg);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ensureChannels(this);
        try {
            Notification.Builder nb = builder(CH_BG)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle(getString(R.string.app_name))
                    .setPriority(Notification.PRIORITY_MIN)
                    .setOngoing(true)
                    .setShowWhen(false)
                    .setContentIntent(openApp(null, 0));
            if (Build.VERSION.SDK_INT >= 21) nb.setVisibility(Notification.VISIBILITY_SECRET);
            Notification n = nb.build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(FG_ID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            new Thread(this::loop).start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    private void loop() {
        SharedPreferences prefs = getSharedPreferences("flaugram", MODE_PRIVATE);
        while (running) {
            String token = prefs.getString("token", null);
            String me = prefs.getString("me", null);
            if (token == null || me == null || !prefs.getBoolean("notify", true)) {
                stopSelf();
                return;
            }
            long after = prefs.getLong("notif_after", -1);
            Api.Res r = Api.call("GET", "/updates" + (after >= 0 ? "?after=" + after : ""), token, null, 35000);
            if (!running) return;
            if (r.code == 401) {
                stopSelf();
                return;
            }
            if (r.netFail || r.code != 200 || r.json == null) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    return;
                }
                continue;
            }
            JSONArray a = r.json.optJSONArray("messages");
            boolean reset = r.json.optBoolean("reset", false);
            // пока приложение открыто, его показывает само приложение: только двигаем счётчик
            if (!reset && a != null && a.length() > 0 && !MainActivity.visible) notifyMessages(me, token, a);
            prefs.edit().putLong("notif_after", r.json.optLong("last", after)).apply();
        }
    }

    private static String clip(String s, int max) {
        s = s.replace('\n', ' ').trim();
        return s.length() > max ? s.substring(0, max).trim() + "…" : s;
    }

    private void notifyMessages(String me, String token, JSONArray a) {
        Map<String, JSONObject> last = new LinkedHashMap<String, JSONObject>();
        Map<String, Integer> counts = new LinkedHashMap<String, Integer>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String from = o.optString("from");
            if (from.isEmpty() || from.equalsIgnoreCase(me)) continue;
            long chat = o.optLong("chat");
            String key = chat > 0 ? chatTag(chat) : from;
            Integer c = counts.get(key);
            counts.put(key, c == null ? 1 : c + 1);
            last.put(key, o);
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        int iconPx = Math.round(48 * getResources().getDisplayMetrics().density);
        for (Map.Entry<String, JSONObject> e : last.entrySet()) {
            String key = e.getKey();
            JSONObject o = e.getValue();
            int n = counts.get(key);
            String from = o.optString("from");
            long chat = o.optLong("chat");
            String name = o.optString("from_name", from);
            if (name.isEmpty()) name = from;
            String text = clip(o.optString("text"), 80);
            boolean photo = !o.isNull("photo") && o.optString("photo").length() > 0;
            if (photo) {
                String p = getString(R.string.notif_photo);
                text = text.isEmpty() ? p : p + ": " + text;
            }
            String title = name;
            if (chat > 0) {
                String ct = o.optString("chat_title");
                title = ct.isEmpty() ? name : ct;
                if (!text.isEmpty()) text = name + ": " + text;
            }
            if (n > 1) title = title + " (" + n + ")";
            Notification.Builder nb = builder(CH_MSG)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setColor(0xFF4C8DFF)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(chat > 0 ? openChatApp(chat) : openApp(from, tag(from).hashCode()));
            try {
                nb.setLargeIcon(Images.avatarSync(from, name, o.optLong("from_avatar"), iconPx, token));
            } catch (Throwable ignored) {
                // без аватарки уведомление всё равно покажется
            }
            try {
                nm.notify(key.equals(from) ? tag(from) : key, MSG_ID, nb.build());
            } catch (Exception ignored) {
                // нет разрешения на уведомления
            }
        }
    }

    private PendingIntent openChatApp(long chat) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("chat_id", chat);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, chatTag(chat).hashCode(), i, fl);
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    private PendingIntent openApp(String chat, int requestCode) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (chat != null) i.putExtra("chat", chat);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, requestCode, i, fl);
    }
}
