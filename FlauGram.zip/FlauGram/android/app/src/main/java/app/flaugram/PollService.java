package app.flaugram;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Фоновое соединение с сервером: держит long-poll и показывает уведомления о новых сообщениях,
 * пока приложение закрыто. Без Google Play Services, поэтому в шторке висит тихое постоянное уведомление.
 */
public class PollService extends Service {
    static final String CH_MSG = "messages";
    static final String CH_BG = "background";
    static final int FG_ID = 1;
    static final int MSG_ID = 2;

    private volatile boolean running = false;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, PollService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) {
            // система не разрешила запуск из фона, повторим при следующем открытии приложения
        }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, PollService.class));
        } catch (Exception ignored) {
            // сервис уже остановлен
        }
    }

    static String tag(String user) {
        return user.toLowerCase(Locale.ROOT);
    }

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel msg = new NotificationChannel(CH_MSG, "Сообщения", NotificationManager.IMPORTANCE_HIGH);
        msg.enableVibration(true);
        nm.createNotificationChannel(msg);
        NotificationChannel bg = new NotificationChannel(CH_BG, "Фоновое соединение", NotificationManager.IMPORTANCE_MIN);
        bg.setShowBadge(false);
        nm.createNotificationChannel(bg);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ensureChannels(this);
        try {
            Notification n = builder(CH_BG)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle("FlauGram")
                    .setContentText("Ждём новые сообщения")
                    .setPriority(Notification.PRIORITY_MIN)
                    .setOngoing(true)
                    .setContentIntent(openApp(null, 0))
                    .build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(FG_ID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            new Thread(this::loop).start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    private void loop() {
        SharedPreferences prefs = getSharedPreferences("flaugram", MODE_PRIVATE);
        while (running) {
            String token = prefs.getString("token", null);
            String me = prefs.getString("me", null);
            if (token == null || me == null || !prefs.getBoolean("notify", true)) {
                stopSelf();
                return;
            }
            long after = prefs.getLong("notif_after", -1);
            Api.Res r = Api.call("GET", "/updates" + (after >= 0 ? "?after=" + after : ""), token, null, 35000);
            if (!running) return;
            if (r.code == 401) {
                stopSelf();
                return;
            }
            if (r.netFail || r.code != 200 || r.json == null) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    return;
                }
                continue;
            }
            JSONArray a = r.json.optJSONArray("messages");
            boolean reset = r.json.optBoolean("reset", false);
            // пока приложение открыто, его показывает само приложение: только двигаем счётчик
            if (!reset && a != null && a.length() > 0 && !MainActivity.visible) notifyMessages(me, a);
            prefs.edit().putLong("notif_after", r.json.optLong("last", after)).apply();
        }
    }

    private void notifyMessages(String me, JSONArray a) {
        Map<String, Integer> counts = new LinkedHashMap<String, Integer>();
        Map<String, String> last = new LinkedHashMap<String, String>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String from = o.optString("from");
            if (from.isEmpty() || from.equalsIgnoreCase(me)) continue;
            Integer c = counts.get(from);
            counts.put(from, c == null ? 1 : c + 1);
            last.put(from, o.optString("text"));
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            String from = e.getKey();
            int n = e.getValue();
            String text = last.get(from);
            if (text.length() > 300) text = text.substring(0, 300) + "…";
            String body = n == 1 ? text : "Новых сообщений: " + n + ". Последнее: " + text;
            Notification note = builder(CH_MSG)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle("@" + from)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setColor(0xFF4C8DFF)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(openApp(from, tag(from).hashCode()))
                    .build();
            try {
                nm.notify(tag(from), MSG_ID, note);
            } catch (Exception ignored) {
                // нет разрешения на уведомления
            }
        }
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    private PendingIntent openApp(String chat, int requestCode) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (chat != null) i.putExtra("chat", chat);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, requestCode, i, fl);
    }
}
