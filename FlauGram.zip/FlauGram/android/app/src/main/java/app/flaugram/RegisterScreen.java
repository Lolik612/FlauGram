package app.flaugram;

import android.graphics.Color;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Первый запуск: имя, юзернейм и кнопка «Создать аккаунт». */
final class RegisterScreen extends Screen {
    private final String error;
    private boolean emailRequired;
    private EditText emailField;

    RegisterScreen(MainActivity a) {
        this(a, null);
    }

    RegisterScreen(MainActivity a, String error) {
        super(a);
        this.error = error;
    }

    /** Пропускает только латиницу, цифры и подчёркивание (для юзернейма). */
    static final InputFilter NAME_FILTER = (src, start, end, dest, ds, de) -> {
        StringBuilder sb = null;
        for (int i = start; i < end; i++) {
            char ch = src.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_';
            if (ok) {
                if (sb != null) sb.append(ch);
            } else if (sb == null) {
                sb = new StringBuilder();
                sb.append(src, start, i);
            }
        }
        return sb == null ? null : sb.toString();
    };

    @Override
    View build() {
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(ui.dp(28), ui.dp(48), ui.dp(28), ui.dp(28));

        FrameLayout logoBox = new FrameLayout(a);
        logoBox.setBackground(glow(0xFF4C8DFF, ui.dp(190)));
        ImageView logo = new ImageView(a);
        logo.setImageResource(R.mipmap.ic_launcher);
        logoBox.addView(logo, new FrameLayout.LayoutParams(ui.dp(96), ui.dp(96), Gravity.CENTER));
        col.addView(logoBox, ui.lp(ui.dp(190), ui.dp(190)));

        TextView title = ui.label(ui.t(R.string.app_name), 32, p.text, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, ui.lp(Ui.MATCH, Ui.WRAP));
        TextView sub = ui.label(ui.t(R.string.reg_subtitle), 15, p.sub, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, ui.dp(6), 0, ui.dp(28));
        col.addView(sub, ui.lp(Ui.MATCH, Ui.WRAP));

        final EditText display = ui.edit(ui.t(R.string.reg_display_hint));
        display.setSingleLine(true);
        display.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        display.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        col.addView(display, ui.lp(Ui.MATCH, Ui.WRAP));

        final EditText name = ui.edit(ui.t(R.string.reg_username_hint));
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        name.setFilters(new InputFilter[]{NAME_FILTER, new InputFilter.LengthFilter(20)});
        col.addView(name, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

        emailField = ui.edit(ui.t(R.string.mail_hint));
        emailField.setSingleLine(true);
        emailField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        emailField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        emailField.setVisibility(View.GONE);
        col.addView(emailField, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        // нужна ли почта, решает сервер: только если владелец настроил отправку писем
        a.io.execute(() -> {
            final Api.Res c = Api.call("GET", "/config", null, null, 8000);
            a.runOnUiThread(() -> {
                if (c.code == 200 && c.json != null && c.json.optBoolean("email_required")) {
                    emailRequired = true;
                    emailField.setVisibility(View.VISIBLE);
                }
            });
        });

        TextView hint = ui.label(ui.t(R.string.reg_username_rules), 12, p.sub, false);
        hint.setPadding(ui.dp(6), ui.dp(8), 0, 0);
        col.addView(hint, ui.lp(Ui.MATCH, Ui.WRAP));

        final TextView err = ui.label(error == null ? "" : error, 14, p.danger, false);
        err.setGravity(Gravity.CENTER);
        err.setPadding(0, ui.dp(12), 0, ui.dp(12));
        col.addView(err, ui.lp(Ui.MATCH, Ui.WRAP));

        final TextView go = ui.button(ui.t(R.string.reg_create));
        col.addView(go, ui.lp(Ui.MATCH, Ui.WRAP));

        TextView login = ui.label(ui.t(R.string.reg_login_by_key), 15, p.accent, true);
        login.setGravity(Gravity.CENTER);
        login.setPadding(0, ui.dp(22), 0, ui.dp(8));
        login.setClickable(true);
        col.addView(login, ui.lp(Ui.MATCH, Ui.WRAP));

        TextView forgot = ui.label(ui.t(R.string.recover_link), 14, p.sub, false);
        forgot.setGravity(Gravity.CENTER);
        forgot.setPadding(0, ui.dp(8), 0, ui.dp(8));
        forgot.setClickable(true);
        forgot.setOnClickListener(v -> MailFlow.recover(a));
        col.addView(forgot, ui.lp(Ui.MATCH, Ui.WRAP));

        go.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.length() < 3) {
                err.setText(ui.t(R.string.err_username_short));
                return;
            }
            String d = display.getText().toString().trim();
            if (!emailRequired) {
                register(n, d, null, null, go, err);
                return;
            }
            String em = emailField.getText().toString().trim();
            if (em.indexOf('@') < 1 || em.length() < 5) {
                err.setText(ui.t(R.string.mail_bad_email));
                return;
            }
            sendCode(n, d, em, true, go, err);
        });
        login.setOnClickListener(v -> Sheet.input(a, ui.t(R.string.login_title), ui.t(R.string.login_key_hint), "", 200,
                false, ui.t(R.string.login_go), this::loginWithKey));

        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        sv.setBackgroundColor(p.bg);
        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        return sv;
    }

    static android.graphics.drawable.GradientDrawable glow(int color, int sizePx) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setGradientType(android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(sizePx / 2f);
        g.setColors(new int[]{Color.argb(0x70, Color.red(color), Color.green(color), Color.blue(color)),
                Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))});
        return g;
    }

    /** Шаг 1: сервер проверяет юзернейм и почту и шлёт код. */
    private void sendCode(final String name, final String display, final String email, final boolean open,
                          final TextView btn, final TextView err) {
        btn.setEnabled(false);
        btn.setAlpha(0.5f);
        err.setText("");
        a.io.execute(() -> {
            final Api.Res r = Api.call("POST", "/register/start", null, Api.obj("username", name, "email", email), 30000);
            a.runOnUiThread(() -> {
                btn.setEnabled(true);
                btn.setAlpha(1f);
                if (r.code != 200) {
                    err.setText(MailFlow.err(a, r));
                } else if (open) {
                    askCode(name, display, email, btn, err);
                } else {
                    a.toast(ui.t(R.string.mail_sent));
                }
            });
        });
    }

    private void askCode(final String name, final String display, final String email, final TextView btn, final TextView err) {
        MailFlow.codeSheet(a, ui.t(R.string.mail_code_title), ui.t(R.string.mail_code_text, email), ui.t(R.string.reg_create),
                code -> register(name, display, email, code, btn, err),
                () -> sendCode(name, display, email, false, btn, err));
    }

    private void register(final String name, final String display, final String email, final String code,
                          final TextView btn, final TextView err) {
        btn.setEnabled(false);
        btn.setAlpha(0.5f);
        err.setText("");
        a.io.execute(() -> {
            final Api.Res r = Api.call("POST", "/register", null, email == null
                    ? Api.obj("username", name, "display_name", display)
                    : Api.obj("username", name, "display_name", display, "email", email, "code", code), 15000);
            a.runOnUiThread(() -> {
                btn.setEnabled(true);
                btn.setAlpha(1f);
                if (r.netFail) {
                    err.setText(a.netMsg());
                } else if (r.code == 200 && r.json != null && r.json.optString("token").length() > 0) {
                    Session.login(r.json.optString("token"), r.json.optString("username", name),
                            r.json.optString("display_name", name), "", 0);
                    Images.forget();
                    a.startSession();
                } else {
                    err.setText(MailFlow.err(a, r));
                    if (r.code == 400 && r.json != null && "bad code".equals(r.json.optString("error"))) {
                        askCode(name, display, email, btn, err);
                    }
                }
            });
        });
    }

    private void loginWithKey(final String key) {
        if (key.isEmpty()) return;
        a.io.execute(() -> {
            final Api.Res r = Api.call("GET", "/me", key, null, 12000);
            a.runOnUiThread(() -> {
                if (r.code == 200 && r.json != null && r.json.optString("username").length() > 0) {
                    Session.login(key, r.json.optString("username"), r.json.optString("display_name"),
                            r.json.optString("bio"), r.json.optLong("avatar"));
                    Images.forget();
                    a.startSession();
                } else if (r.netFail) {
                    a.toast(a.netMsg());
                } else if (r.code == 403) {
                    a.toast(ui.t(R.string.banned_title));
                } else {
                    a.toast(ui.t(R.string.err_bad_key));
                }
            });
        });
    }
}
