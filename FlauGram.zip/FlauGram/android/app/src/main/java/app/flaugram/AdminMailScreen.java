package app.flaugram;

import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Админка: с какой почты уходят письма (адрес, пароль, сервер SMTP). По умолчанию Outlook. */
final class AdminMailScreen extends Screen {
    private EditText host, port, user, pass, name;
    private TextView security, status;
    private String sec = "starttls";
    private boolean required = true;
    private Toggle req;

    AdminMailScreen(MainActivity a) {
        super(a);
    }

    private EditText field(LinearLayout col, String label, String hint, int type, int max) {
        TextView l = ui.label(label, 13, p.sub, true);
        l.setPadding(ui.dp(6), ui.dp(12), 0, ui.dp(6));
        col.addView(l);
        EditText e = ui.edit(hint);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});
        col.addView(e, ui.lp(Ui.MATCH, Ui.WRAP));
        return e;
    }

    @Override
    View build() {
        LinearLayout root = ui.vertical();
        root.setBackgroundColor(p.bg);
        root.addView(topBar(ui.t(R.string.admin_mail), null), ui.lp(Ui.MATCH, Ui.WRAP));
        ScrollView sv = new ScrollView(a);
        LinearLayout col = ui.vertical();
        col.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(30));

        TextView info = ui.label(ui.t(R.string.admin_mail_info), 14, p.sub, false);
        info.setPadding(ui.dp(6), 0, ui.dp(6), ui.dp(4));
        col.addView(info);

        user = field(col, ui.t(R.string.mail_f_user), "name@outlook.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, 120);
        pass = field(col, ui.t(R.string.mail_f_pass), ui.t(R.string.mail_f_pass_hint), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, 200);
        name = field(col, ui.t(R.string.mail_f_name), "FlauGram", InputType.TYPE_CLASS_TEXT, 32);
        host = field(col, ui.t(R.string.mail_f_host), "smtp-mail.outlook.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, 120);
        port = field(col, ui.t(R.string.mail_f_port), "587", InputType.TYPE_CLASS_NUMBER, 5);

        TextView sl = ui.label(ui.t(R.string.mail_f_security), 13, p.sub, true);
        sl.setPadding(ui.dp(6), ui.dp(12), 0, ui.dp(6));
        col.addView(sl);
        security = ui.softButton("", p.text);
        security.setOnClickListener(v -> {
            Sheet s = new Sheet(a).title(ui.t(R.string.mail_f_security));
            final String[] ids = {"starttls", "ssl", "none"};
            final String[] names = {"STARTTLS (587)", "SSL (465)", ui.t(R.string.mail_sec_none)};
            for (int i = 0; i < 3; i++) {
                final String id = ids[i];
                s.item(sec.equals(id) ? R.drawable.ic_check : 0, names[i], sec.equals(id) ? p.accent : 0, () -> {
                    sec = id;
                    showSec();
                });
            }
            s.show();
        });
        col.addView(security, ui.lp(Ui.MATCH, Ui.WRAP));

        req = new Toggle(a, p.accent, 0xFF48484A, true);
        req.setListener(on -> required = on);
        LinearLayout rr = ui.settingRow(R.drawable.ic_shield, 0xFF30D158, ui.t(R.string.mail_f_required), ui.t(R.string.mail_f_required_sub), req);
        rr.setOnClickListener(v -> req.set(!req.isOn(), true));
        LinearLayout card = ui.card();
        card.addView(rr);
        col.addView(card, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));

        status = ui.label("", 14, p.sub, false);
        status.setPadding(ui.dp(6), ui.dp(12), ui.dp(6), 0);
        col.addView(status);

        TextView save = ui.button(ui.t(R.string.save));
        save.setOnClickListener(v -> save(null));
        col.addView(save, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        TextView test = ui.softButton(ui.t(R.string.mail_test), p.text);
        test.setOnClickListener(v -> save(() -> Sheet.input(a, ui.t(R.string.mail_test), ui.t(R.string.mail_hint),
                Session.email, 120, false, ui.t(R.string.mail_test_go), this::sendTest)));
        col.addView(test, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, ui.lpw(Ui.MATCH, 0, 1f));
        showSec();
        return root;
    }

    private void showSec() {
        security.setText("starttls".equals(sec) ? "STARTTLS (587)" : "ssl".equals(sec) ? "SSL (465)" : ui.t(R.string.mail_sec_none));
    }

    @Override
    void onShow() {
        a.api("GET", "/admin/mail", null, r -> {
            if (r.code != 200 || r.json == null) return;
            JSONObject j = r.json;
            host.setText(j.optString("host"));
            port.setText(String.valueOf(j.optInt("port", 587)));
            user.setText(j.optString("user"));
            name.setText(j.optString("name"));
            pass.setHint(j.optBoolean("has_password") ? ui.t(R.string.mail_pass_saved) : ui.t(R.string.mail_f_pass_hint));
            sec = j.optString("security", "starttls");
            required = j.optBoolean("required", true);
            req.set(required, false);
            showSec();
            status.setText(j.optBoolean("ready") ? ui.t(R.string.mail_status_on) : ui.t(R.string.mail_status_off));
        });
    }

    private void save(final Runnable then) {
        JSONObject o = Api.obj("host", host.getText().toString().trim(), "port", parse(port.getText().toString()),
                "security", sec, "user", user.getText().toString().trim(), "name", name.getText().toString().trim(),
                "required", required);
        String pw = pass.getText().toString();
        if (!pw.isEmpty()) {
            try {
                o.put("password", pw);
            } catch (Exception ignored) {
                // ключ строка
            }
        }
        a.api("POST", "/admin/mail", o, r -> {
            if (r.code == 200 && r.json != null) {
                pass.setText("");
                pass.setHint(r.json.optBoolean("has_password") ? ui.t(R.string.mail_pass_saved) : ui.t(R.string.mail_f_pass_hint));
                status.setText(r.json.optBoolean("ready") ? ui.t(R.string.mail_status_on) : ui.t(R.string.mail_status_off));
                if (then == null) a.toast(ui.t(R.string.saved));
                else then.run();
            } else {
                a.toast(r.code == 400 ? ui.t(R.string.mail_f_bad) : a.errText(r));
            }
        });
    }

    private int parse(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void sendTest(String to) {
        status.setText(ui.t(R.string.mail_testing));
        a.api("POST", "/admin/mail/test", Api.obj("to", to), r -> {
            if (r.code == 200 && r.json != null && r.json.optBoolean("ok")) {
                status.setText(ui.t(R.string.mail_test_ok, r.json.optString("to")));
            } else if (r.code == 200 && r.json != null) {
                status.setText(ui.t(R.string.mail_test_fail, r.json.optString("error")));
            } else {
                status.setText(MailFlow.err(a, r));
            }
        });
    }
}
