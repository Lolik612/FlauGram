package app.flaugram;

import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Вкладка «Чаты»: диалоги, поиск людей и групп, создание групп и каналов. */
final class ChatsTab extends Tab {
    private RowAdapter adapter;
    private ListView list;
    private FrameLayout emptyHolder;
    private TextView hint;
    private final List<Model.Row> dialogs = new ArrayList<>();
    private boolean loaded, searching;
    private String lastQuery = "";
    private Runnable pending;

    ChatsTab(ShellScreen shell) {
        super(shell);
    }

    @Override
    View build() {
        LinearLayout col = ui.vertical();
        col.setBackgroundColor(p.bg);

        LinearLayout head = ui.horizontal();
        head.setPadding(ui.dp(22), ui.dp(14), ui.dp(14), ui.dp(4));
        TextView title = ui.label(ui.t(R.string.tab_chats), 30, p.text, true);
        head.addView(title, ui.lpw(0, Ui.WRAP, 1f));
        FrameLayout plus = new FrameLayout(a);
        plus.setBackground(ui.ripple(p.card, 24));
        plus.setClickable(true);
        plus.addView(ui.icon(R.drawable.ic_add, 24, p.text), new FrameLayout.LayoutParams(ui.dp(24), ui.dp(24), Gravity.CENTER));
        plus.setOnClickListener(v -> new Sheet(a).title(ui.t(R.string.new_chat))
                .item(R.drawable.ic_group, ui.t(R.string.menu_new_group), 0, () -> createChat("group"))
                .item(R.drawable.ic_channel, ui.t(R.string.menu_new_channel), 0, () -> createChat("channel"))
                .show());
        head.addView(plus, ui.lp(ui.dp(44), ui.dp(44)));
        col.addView(head, ui.lp(Ui.MATCH, Ui.WRAP));

        SearchPill pill = new SearchPill(a, ui.t(R.string.search_hint), this::onQuery);
        col.addView(pill, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 8, 16, 6));

        FrameLayout frame = new FrameLayout(a);
        list = new ListView(a);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0));
        list.setClipToPadding(false);
        list.setPadding(0, ui.dp(4), 0, navPad());
        adapter = new RowAdapter(a, RowAdapter.DIALOGS);
        list.setAdapter(adapter);
        frame.addView(list, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        emptyHolder = new FrameLayout(a);
        frame.addView(emptyHolder, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH, Gravity.CENTER));
        col.addView(frame, ui.lpw(Ui.MATCH, 0, 1f));
        showEmpty(false);

        list.setOnItemClickListener((parent, v, pos, id) -> {
            Model.Row r = (Model.Row) adapter.getItem(pos);
            a.push(new ChatScreen(a, r));
        });
        list.setOnItemLongClickListener((parent, v, pos, id) -> {
            rowMenu((Model.Row) adapter.getItem(pos));
            return true;
        });
        return col;
    }

    private void showEmpty(boolean visible) {
        emptyHolder.removeAllViews();
        if (!visible) return;
        View e;
        if (!loaded) {
            e = new TextView(a);
            ((TextView) e).setText(ui.t(R.string.loading));
            ((TextView) e).setTextColor(p.sub);
            ((TextView) e).setGravity(Gravity.CENTER);
        } else if (searching) {
            e = shell_empty(R.drawable.ic_search, ui.t(R.string.search_none), "");
        } else {
            e = shell_empty(R.drawable.ic_chat, ui.t(R.string.empty_dialogs_title), ui.t(R.string.empty_dialogs));
        }
        emptyHolder.addView(e, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.CENTER));
    }

    private View shell_empty(int icon, String title, String text) {
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER);
        col.setPadding(ui.dp(36), ui.dp(36), ui.dp(36), ui.dp(80));
        ImageView ic = ui.icon(icon, 56, ui.dim(p.sub, 120));
        col.addView(ic, ui.lpm(ui.dp(56), ui.dp(56), 0, 0, 0, 14));
        TextView t = ui.label(title, 18, p.text, true);
        t.setGravity(Gravity.CENTER);
        col.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        if (!text.isEmpty()) {
            TextView s = ui.label(text, 14, p.sub, false);
            s.setGravity(Gravity.CENTER);
            s.setPadding(0, ui.dp(6), 0, 0);
            col.addView(s, ui.lp(Ui.MATCH, Ui.WRAP));
        }
        return col;
    }

    private void rowMenu(final Model.Row r) {
        final boolean muted = Session.isMuted(r.key());
        Sheet s = new Sheet(a).title(r.title());
        if (!r.isChat()) {
            s.item(R.drawable.ic_person, ui.t(R.string.menu_profile), 0, () -> a.push(new UserScreen(a, r)));
        } else {
            s.item(R.drawable.ic_group, ui.t(R.string.menu_about), 0, () -> a.push(new ChatInfoScreen(a, r)));
        }
        final boolean pinned = Session.isPinnedChat(r.key());
        s.item(R.drawable.ic_pin, pinned ? ui.t(R.string.chat_unpin) : ui.t(R.string.chat_pin), 0, () -> {
            Session.setPinnedChat(r.key(), !pinned);
            refresh();
        });
        s.item(muted ? R.drawable.ic_bell : R.drawable.ic_bell_off, muted ? ui.t(R.string.unmute) : ui.t(R.string.mute), 0, () -> {
            Session.setMuted(r.key(), !muted);
            adapter.notifyDataSetChanged();
            recount();
        });
        s.show();
    }

    // ------------------------------------------------------------------ поиск

    private void onQuery(final String q) {
        lastQuery = q;
        if (pending != null) a.h.removeCallbacks(pending);
        if (q.isEmpty()) {
            searching = false;
            adapter.set(dialogs);
            showEmpty(dialogs.isEmpty());
            return;
        }
        searching = true;
        pending = () -> search(q);
        a.h.postDelayed(pending, 250);
    }

    private void search(final String q) {
        a.api("GET", "/search?q=" + Api.enc(q), null, r -> {
            if (!searching || !q.equals(lastQuery)) return;
            if (r.netFail || r.code != 200 || r.json == null) {
                a.toast(a.netMsg());
                return;
            }
            List<Model.Row> rows = new ArrayList<>();
            JSONArray us = r.json.optJSONArray("users");
            if (us != null) {
                for (int i = 0; i < us.length(); i++) {
                    Model.Row row = Model.user(us.optJSONObject(i));
                    if (row == null) continue;
                    row.sub = "@" + row.user + (row.bio.isEmpty() ? "" : "  ·  " + row.bio.replace('\n', ' '));
                    rows.add(row);
                }
            }
            JSONArray cs = r.json.optJSONArray("chats");
            if (cs != null) {
                for (int i = 0; i < cs.length(); i++) {
                    Model.Row row = Model.chat(cs.optJSONObject(i));
                    if (row == null) continue;
                    row.sub = kindLabel(row.kind) + "  ·  " + membersText(row);
                    rows.add(row);
                }
            }
            adapter.set(rows);
            showEmpty(rows.isEmpty());
        });
    }

    String kindLabel(String kind) {
        return "channel".equals(kind) ? ui.t(R.string.kind_channel) : ui.t(R.string.kind_group);
    }

    String membersText(Model.Row r) {
        return "channel".equals(r.kind) ? ui.t(R.string.subscribers_count, r.members) : ui.t(R.string.members_count, r.members);
    }

    // ------------------------------------------------------------------ диалоги

    @Override
    void onSelected() {
        refresh();
    }

    @Override
    void onUpdates(List<Model.Msg> l) {
        refresh();
    }

    @Override
    void onMeChanged() {
        refresh();
    }

    @Override
    void onReads(String with, long upto) {
        refresh();
    }

    void refresh() {
        a.api("GET", "/dialogs", null, r -> {
            if (r.netFail || r.code != 200 || r.json == null) return;
            dialogs.clear();
            JSONArray arr = r.json.optJSONArray("dialogs");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;
                    Model.Row row = new Model.Row();
                    row.user = o.optString("user");
                    row.name = o.optString("display_name");
                    row.bio = o.optString("bio");
                    row.avatar = o.optLong("avatar");
                    row.chatId = o.optLong("chat");
                    row.kind = o.optString("kind", "user");
                    row.verified = o.optBoolean("verified");
                    row.badge = Model.badge(o.optJSONObject("badge"));
                    row.status = o.optString("status");
                    String text = o.optString("text").replace('\n', ' ');
                    if (o.optBoolean("photo")) {
                        text = text.isEmpty() ? ui.t(R.string.msg_photo) : ui.t(R.string.msg_photo) + ": " + text;
                    }
                    String who = o.optString("sender");
                    if (row.isChat() && "group".equals(row.kind) && !who.isEmpty() && !text.isEmpty() && !o.optBoolean("mine")) {
                        text = who + ": " + text;
                    }
                    row.sub = text;
                    row.ts = o.optLong("ts");
                    row.unread = o.optInt("unread");
                    row.mine = o.optBoolean("mine");
                    row.seen = o.optBoolean("seen");
                    dialogs.add(row);
                }
                // закреплённые чаты наверху (порядок остальных не меняется)
                java.util.Collections.sort(dialogs, (x, y) -> Boolean.compare(Session.isPinnedChat(y.key()), Session.isPinnedChat(x.key())));
            }
            loaded = true;
            recount();
            if (!searching) {
                adapter.set(dialogs);
                showEmpty(dialogs.isEmpty());
            }
        });
    }

    private void recount() {
        int n = 0;
        for (Model.Row r : dialogs) if (!Session.isMuted(r.key())) n += r.unread;
        shell.setUnread(n);
    }

    // ------------------------------------------------------------------ создание группы или канала

    private void createChat(final String kind) {
        final EditText title = ui.edit(ui.t(R.string.chat_title_hint));
        title.setSingleLine(true);
        title.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(32)});
        final EditText bio = ui.edit(ui.t(R.string.chat_bio_hint));
        bio.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(200)});
        Sheet s = new Sheet(a).title("channel".equals(kind) ? ui.t(R.string.menu_new_channel) : ui.t(R.string.menu_new_group));
        s.view(title);
        LinearLayout.LayoutParams bp = ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0);
        bio.setLayoutParams(bp);
        s.view(bio);
        s.buttons(ui.t(R.string.cancel), ui.t(R.string.create), false, () -> {
            String tt = title.getText().toString().trim();
            if (tt.isEmpty()) {
                a.toast(ui.t(R.string.err_chat_title));
                return;
            }
            JSONObject body = Api.obj("kind", kind, "title", tt, "bio", bio.getText().toString().trim());
            a.api("POST", "/chat/create", body, r -> {
                Model.Row row = r.code == 200 && r.json != null ? Model.chat(r.json) : null;
                if (row == null) {
                    a.toast(r.netFail ? a.netMsg() : r.code == 429 ? ui.t(R.string.err_too_many) : ui.t(R.string.err_server, r.code));
                    return;
                }
                a.push(new ChatScreen(a, row));
            });
        });
        s.show();
        title.requestFocus();
    }
}
