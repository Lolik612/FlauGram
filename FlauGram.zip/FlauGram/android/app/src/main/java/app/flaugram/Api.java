package app.flaugram;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Тонкая обёртка над HTTP. Все методы блокирующие, вызывать только из фонового потока. */
final class Api {
    private Api() { }

    static final class Res {
        int code;
        JSONObject json;
        boolean netFail;
    }

    static Res call(String method, String path, String token, JSONObject body, int readTimeoutMs) {
        Res r = new Res();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BuildConfig.SERVER_URL + path).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(8000);
            c.setReadTimeout(readTimeoutMs);
            c.setUseCaches(false);
            if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
            if (body != null) {
                byte[] b = body.toString().getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                c.setFixedLengthStreamingMode(b.length);
                OutputStream os = c.getOutputStream();
                os.write(b);
                os.close();
            }
            r.code = c.getResponseCode();
            InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = in == null ? "" : readAll(in);
            try {
                r.json = new JSONObject(s);
            } catch (Exception ignored) {
                // тело не JSON, оставляем json == null
            }
        } catch (Exception e) {
            r.netFail = true;
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    /** JSON из пар ключ-значение: obj("a", 1, "b", "x"). */
    static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) {
            // ключи всегда строки
        }
        return o;
    }

    static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }
}
