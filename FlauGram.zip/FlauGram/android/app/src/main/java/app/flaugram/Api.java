package app.flaugram;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Тонкая обёртка над HTTP. Все методы блокирующие, вызывать только из фонового потока. */
final class Api {
    private Api() { }

    private static final int MAX_DOWNLOAD = 12 * 1024 * 1024;

    static final class Res {
        int code;
        JSONObject json;
        boolean netFail;
    }

    /** Запрос к нашему серверу с JSON-телом. */
    static Res call(String method, String path, String token, JSONObject body, int readTimeoutMs) {
        byte[] b = null;
        if (body != null) {
            try {
                b = body.toString().getBytes("UTF-8");
            } catch (Exception ignored) {
                // UTF-8 есть всегда
            }
        }
        return request(method, BuildConfig.SERVER_URL + path, token, b, "application/json; charset=utf-8", readTimeoutMs, false);
    }

    /** Загрузка бинарных данных (фото, аватарка) на наш сервер. */
    static Res postBytes(String path, String token, byte[] data, int readTimeoutMs) {
        return request("POST", BuildConfig.SERVER_URL + path, token, data, "application/octet-stream", readTimeoutMs, false);
    }

    /** Публичный JSON с GitHub (проверка обновлений). */
    static Res getJsonUrl(String url, int readTimeoutMs) {
        return request("GET", url, null, null, null, readTimeoutMs, true);
    }

    /** Скачивание файла с нашего сервера. null, если не получилось. */
    static byte[] getBytes(String path, String token) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BuildConfig.SERVER_URL + path).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(20000);
            c.setUseCaches(false);
            if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > MAX_DOWNLOAD) return null;
            }
            in.close();
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static Res request(String method, String url, String token, byte[] body, String ctype,
                               int readTimeoutMs, boolean github) {
        Res r = new Res();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(8000);
            c.setReadTimeout(readTimeoutMs);
            c.setUseCaches(false);
            if (github) {
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setRequestProperty("User-Agent", "FlauGram");
            }
            if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
            if (body != null) {
                c.setDoOutput(true);
                if (ctype != null) c.setRequestProperty("Content-Type", ctype);
                c.setFixedLengthStreamingMode(body.length);
                OutputStream os = c.getOutputStream();
                os.write(body);
                os.close();
            }
            r.code = c.getResponseCode();
            InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = in == null ? "" : readAll(in);
            try {
                r.json = new JSONObject(s);
            } catch (Exception ignored) {
                // тело не JSON, оставляем json == null
            }
        } catch (Exception e) {
            r.netFail = true;
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    /** JSON из пар ключ-значение: obj("a", 1, "b", "x"). */
    static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (Exception ignored) {
            // ключи всегда строки
        }
        return o;
    }

    static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }
}
