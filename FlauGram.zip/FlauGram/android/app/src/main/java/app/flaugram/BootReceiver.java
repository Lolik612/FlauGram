package app.flaugram;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Запускает фоновое соединение после перезагрузки телефона и после обновления приложения. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences("flaugram", Context.MODE_PRIVATE);
        if (p.getString("token", null) != null && p.getBoolean("notify", true)) PollService.start(context);
    }
}
