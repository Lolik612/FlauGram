package app.flaugram;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

/** Аватарка с необязательным мягким свечением вокруг и зелёной точкой «в сети». */
final class AvatarView extends FrameLayout {
    private final ImageView img;
    private final View dot;
    private final int sizePx, glowPx;
    private final int ring;

    AvatarView(MainActivity a, int sizePx, int glowPx) {
        super(a);
        this.sizePx = sizePx;
        this.glowPx = glowPx;
        this.ring = a.ui.p.bg;
        setClipChildren(false);
        int total = glowPx > 0 ? glowPx : sizePx;
        setLayoutParams(new android.widget.LinearLayout.LayoutParams(total, total));
        img = new ImageView(a);
        addView(img, new LayoutParams(sizePx, sizePx, Gravity.CENTER));
        int dotPx = Math.max(a.ui.dp(10), Math.round(sizePx * 0.27f));
        dot = new View(a);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(a.ui.p.ok);
        g.setStroke(Math.max(2, Math.round(dotPx * 0.18f)), ring);
        dot.setBackground(g);
        LayoutParams dp = new LayoutParams(dotPx, dotPx, Gravity.CENTER);
        int off = Math.round(sizePx * 0.35f);
        dp.setMargins(off * 2, off * 2, 0, 0);
        dot.setLayoutParams(dp);
        dot.setVisibility(GONE);
        addView(dot);
    }

    void setGlow(int color) {
        if (glowPx <= 0) return;
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(glowPx / 2f);
        g.setColors(new int[]{Color.argb(0xF0, Color.red(color), Color.green(color), Color.blue(color)),
                Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))});
        setBackground(g);
    }

    void setOnline(boolean online) {
        dot.setVisibility(online ? VISIBLE : GONE);
    }

    ImageView image() {
        return img;
    }

    void bind(Model.Row r) {
        if (r.isChat()) Images.chatAvatar(img, r.chatId, r.title(), r.avatar, sizePx, Session.token);
        else Images.avatar(img, r.user, r.title(), r.avatar, sizePx, Session.token);
    }

    void bindMe() {
        Images.avatar(img, Session.me, Session.meName, Session.meAvatar, sizePx, Session.token);
    }
}
