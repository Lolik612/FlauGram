package app.flaugram;

import android.net.Uri;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Карточка группы или канала: свечение, кнопки, описание, участники и управление. */
final class ChatInfoScreen extends Screen {
    private static final int REQ_AVATAR = 2;

    private final Model.Row c;
    private AvatarView avatar;
    private TextView titleView, subView, bioText, soundLabel, actLabel, membersLabel;
    private ImageView soundIcon, actIcon;
    private LinearLayout bioCard, manageCard, membersCard, membersBody;

    ChatInfoScreen(MainActivity a, Model.Row seed) {
        super(a);
        this.c = seed;
    }

    @Override
    View build() {
        FrameLayout frame = new FrameLayout(a);
        frame.setBackgroundColor(p.bg);
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, ui.dp(52), 0, ui.dp(32));

        avatar = new AvatarView(a, ui.dp(132), ui.dp(250));
        col.addView(avatar, ui.lp(ui.dp(250), ui.dp(250)));
        titleView = ui.label("", 23, p.text, true);
        titleView.setGravity(Gravity.CENTER);
        col.addView(titleView, ui.lpm(Ui.WRAP, Ui.WRAP, 24, 2, 24, 0));
        subView = ui.label("", 16, p.sub, false);
        subView.setGravity(Gravity.CENTER);
        col.addView(subView, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 2, 0, 22));

        LinearLayout actions = ui.horizontal();
        actions.setPadding(ui.dp(8), 0, ui.dp(8), 0);
        LinearLayout tChat = tile(R.drawable.ic_chat_solid, ui.t(R.string.act_chat));
        LinearLayout tSound = tile(R.drawable.ic_bell, ui.t(R.string.act_sound));
        LinearLayout tMembers = tile(R.drawable.ic_group, ui.t(R.string.chat_members));
        LinearLayout tAct = tile(R.drawable.ic_logout, ui.t(R.string.chat_leave));
        soundIcon = (ImageView) tSound.getChildAt(0);
        soundLabel = (TextView) tSound.getChildAt(1);
        actIcon = (ImageView) tAct.getChildAt(0);
        actLabel = (TextView) tAct.getChildAt(1);
        membersLabel = (TextView) tMembers.getChildAt(1);
        for (LinearLayout t : new LinearLayout[]{tChat, tSound, tMembers, tAct}) {
            actions.addView(t, ui.lpm(0, ui.dp(88), 4, 0, 4, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        col.addView(actions, ui.lp(Ui.MATCH, Ui.WRAP));
        tChat.setOnClickListener(v -> {
            Screen below = a.below(this);
            if (below instanceof ChatScreen && ((ChatScreen) below).isWith(c)) a.pop(); else a.push(new ChatScreen(a, c));
        });
        tSound.setOnClickListener(v -> {
            boolean on = !Session.isMuted(c.key());
            Session.setMuted(c.key(), on);
            bind();
            a.toast(on ? ui.t(R.string.muted_on) : ui.t(R.string.muted_off));
        });
        tMembers.setOnClickListener(v -> loadMembers());
        tAct.setOnClickListener(v -> mainAction());

        bioCard = ui.card();
        bioCard.setPadding(ui.dp(18), ui.dp(14), ui.dp(18), ui.dp(14));
        bioText = ui.label("", 16, p.text, false);
        bioCard.addView(bioText);
        bioCard.addView(ui.label(ui.t(R.string.profile_bio), 13, p.sub, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 4, 0, 0));
        col.addView(bioCard, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 4, 16, 0));

        manageCard = ui.card();
        col.addView(manageCard, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 14, 16, 0));

        membersCard = ui.card();
        membersCard.setVisibility(View.GONE);
        membersBody = ui.vertical();
        membersCard.addView(membersBody);
        col.addView(membersCard, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 14, 16, 0));

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        frame.addView(sv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        ImageView back = ui.iconButton(R.drawable.ic_back, p.text);
        back.setOnClickListener(v -> a.pop());
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(ui.dp(48), ui.dp(48), Gravity.TOP | Gravity.START);
        bp.setMargins(ui.dp(8), ui.dp(8), 0, 0);
        frame.addView(back, bp);
        bind();
        return frame;
    }

    private LinearLayout tile(int icon, String label) {
        LinearLayout t = ui.vertical();
        t.setGravity(Gravity.CENTER);
        t.setBackground(ui.ripple(p.card, 22));
        t.setClickable(true);
        t.addView(ui.icon(icon, 28, p.text), ui.lpm(ui.dp(28), ui.dp(28), 0, 0, 0, 8));
        TextView tv = ui.label(label, 13, p.text, true);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        t.addView(tv);
        return t;
    }

    private void bind() {
        avatar.bind(c);
        avatar.setGlow(c.avatar > 0 ? 0xFFFFFFFF : Images.nameColor("c" + c.chatId));
        titleView.setText(c.title());
        boolean channel = "channel".equals(c.kind);
        subView.setText((channel ? ui.t(R.string.kind_channel) : ui.t(R.string.kind_group)) + "  ·  "
                + (channel ? ui.t(R.string.subscribers_count, c.members) : ui.t(R.string.members_count, c.members)));
        bioCard.setVisibility(c.bio.isEmpty() ? View.GONE : View.VISIBLE);
        bioText.setText(c.bio);
        boolean muted = Session.isMuted(c.key());
        soundIcon.setImageDrawable(ui.drawable(muted ? R.drawable.ic_bell_off : R.drawable.ic_bell, p.text));
        soundLabel.setText(muted ? ui.t(R.string.act_muted) : ui.t(R.string.act_sound));
        if (c.owner) {
            actIcon.setImageDrawable(ui.drawable(R.drawable.ic_edit, p.text));
            actLabel.setText(ui.t(R.string.chat_manage));
        } else if (c.member) {
            actIcon.setImageDrawable(ui.drawable(R.drawable.ic_logout, p.text));
            actLabel.setText(ui.t(R.string.chat_leave));
        } else {
            actIcon.setImageDrawable(ui.drawable(R.drawable.ic_add, p.text));
            actLabel.setText(ui.t(R.string.chat_join));
        }
        manageCard.removeAllViews();
        boolean manage = c.owner || Session.admin;
        manageCard.setVisibility(manage ? View.VISIBLE : View.GONE);
        if (c.owner) {
            manageCard.addView(ui.settingRow(R.drawable.ic_edit, 0xFF4C8DFF, ui.t(R.string.chat_edit), null, null));
            manageCard.getChildAt(0).setOnClickListener(v -> editSheet());
            addManage(R.drawable.ic_image, 0xFF34C759, ui.t(R.string.profile_change_photo), () -> a.pickImage(this, REQ_AVATAR));
            addManage(R.drawable.ic_close, 0xFF8E8E93, ui.t(R.string.profile_remove_photo), () ->
                    post("/chat/avatar/remove", Api.obj("id", Long.valueOf(c.chatId))));
        }
        if (manage) {
            addManage(R.drawable.ic_delete, 0xFFFF453A, ui.t(R.string.chat_delete), () ->
                    Sheet.confirm(a, ui.t(R.string.chat_delete), ui.t(R.string.chat_delete_confirm, c.title()), ui.t(R.string.chat_delete), true, () ->
                            a.api("POST", "/chat/delete", Api.obj("id", Long.valueOf(c.chatId)), r -> {
                                if (r.code == 200) {
                                    a.toast(ui.t(R.string.chat_deleted));
                                    a.pop();
                                    a.pop();
                                } else {
                                    a.toast(a.errText(r));
                                }
                            })));
        }
    }

    private void addManage(int icon, int color, String label, Runnable r) {
        if (manageCard.getChildCount() > 0) manageCard.addView(ui.divider());
        View row = ui.settingRow(icon, color, label, null, null);
        row.setOnClickListener(v -> r.run());
        manageCard.addView(row);
    }

    @Override
    void onShow() {
        if (!stale()) return;
        a.api("GET", "/chat?id=" + c.chatId, null, r -> {
            if (r.code == 404) {
                a.toast(ui.t(R.string.chat_gone));
                a.pop();
                return;
            }
            Model.Row n = r.json == null ? null : Model.chat(r.json);
            if (n == null) return;
            apply(n);
            if (n.member) loadMembers();
        });
    }

    private void apply(Model.Row n) {
        c.name = n.name;
        c.bio = n.bio;
        c.avatar = n.avatar;
        c.members = n.members;
        c.member = n.member;
        c.owner = n.owner;
        c.kind = n.kind;
        bind();
    }

    private void post(String path, JSONObject body) {
        a.api("POST", path, body, r -> {
            Model.Row n = r.code == 200 && r.json != null ? Model.chat(r.json) : null;
            if (n == null) {
                a.toast(a.errText(r));
                return;
            }
            Images.forget();
            apply(n);
        });
    }

    private void mainAction() {
        if (c.owner) {
            editSheet();
        } else if (c.member) {
            Sheet.confirm(a, ui.t(R.string.chat_leave), ui.t(R.string.chat_leave_confirm, c.title()), ui.t(R.string.chat_leave), true, () ->
                    a.api("POST", "/chat/leave", Api.obj("id", Long.valueOf(c.chatId)), r -> {
                        if (r.code == 200) {
                            a.pop();
                            a.pop();
                        } else {
                            a.toast(a.errText(r));
                        }
                    }));
        } else {
            post("/chat/join", Api.obj("id", Long.valueOf(c.chatId)));
        }
    }

    private void editSheet() {
        final EditText title = ui.edit(ui.t(R.string.chat_title_hint));
        title.setSingleLine(true);
        title.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        title.setText(c.title());
        final EditText bio = ui.edit(ui.t(R.string.chat_bio_hint));
        bio.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        bio.setText(c.bio);
        Sheet s = new Sheet(a).title(ui.t(R.string.chat_edit));
        s.view(title);
        bio.setLayoutParams(ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        s.view(bio);
        s.buttons(ui.t(R.string.cancel), ui.t(R.string.save), false, () -> {
            String tt = title.getText().toString().trim();
            if (tt.isEmpty()) {
                a.toast(ui.t(R.string.err_chat_title));
                return;
            }
            post("/chat/edit", Api.obj("id", Long.valueOf(c.chatId), "title", tt, "bio", bio.getText().toString().trim()));
        });
        s.show();
    }

    @Override
    void onResult(int req, final Uri uri) {
        if (req != REQ_AVATAR) return;
        a.toast(ui.t(R.string.preparing));
        a.io.execute(() -> {
            final Images.Encoded e = Images.encode(a, uri, 512, true, 800 * 1024);
            a.runOnUiThread(() -> {
                if (e == null) {
                    a.toast(ui.t(R.string.err_bad_image));
                    return;
                }
                a.apiBytes("/chat/avatar?id=" + c.chatId, e.data, r -> {
                    Model.Row n = r.code == 200 && r.json != null ? Model.chat(r.json) : null;
                    if (n == null) {
                        a.toast(a.errText(r));
                        return;
                    }
                    Images.forget();
                    apply(n);
                });
            });
        });
    }

    private void loadMembers() {
        if (!c.member && !Session.admin) {
            a.toast(ui.t(R.string.err_forbidden));
            return;
        }
        a.api("GET", "/chat/members?id=" + c.chatId, null, r -> {
            JSONArray arr = r.code == 200 && r.json != null ? r.json.optJSONArray("users") : null;
            if (arr == null) {
                if (r.code != 200) a.toast(a.errText(r));
                return;
            }
            membersBody.removeAllViews();
            membersCard.setVisibility(View.VISIBLE);
            TextView head = ui.label(ui.t(R.string.chat_members) + " · " + arr.length(), 13, p.sub, true);
            head.setPadding(ui.dp(18), ui.dp(14), ui.dp(18), ui.dp(6));
            membersBody.addView(head);
            List<Model.Row> users = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                final Model.Row u = Model.user(o);
                if (u == null) continue;
                users.add(u);
                LinearLayout row = ui.horizontal();
                row.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8));
                row.setBackground(ui.ripple(0x00000000, 22));
                row.setClickable(true);
                AvatarView av = new AvatarView(a, ui.dp(44), 0);
                av.bind(u);
                av.setOnline("online".equals(u.status));
                row.addView(av, ui.lpm(ui.dp(44), ui.dp(44), 0, 0, 12, 0));
                LinearLayout names = ui.vertical();
                NameLine nl = new NameLine(a, 16, p.text, true, 15);
                nl.set(u.title(), u.user, u.badge);
                names.addView(nl, ui.lp(Ui.WRAP, Ui.WRAP));
                String st = Model.statusText(a, u.status);
                TextView sub = ui.label(st.isEmpty() ? "@" + u.user : st, 13, "online".equals(u.status) ? p.accent : p.sub, false);
                names.addView(sub);
                row.addView(names, ui.lpw(0, Ui.WRAP, 1f));
                if (o != null && o.optBoolean("owner")) {
                    row.addView(ui.label(ui.t(R.string.chat_owner), 12, p.sub, true));
                }
                row.setOnClickListener(v -> a.push(new UserScreen(a, u)));
                membersBody.addView(row);
            }
        });
    }
}
