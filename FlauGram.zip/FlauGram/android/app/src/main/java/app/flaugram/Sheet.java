package app.flaugram;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Нижняя выезжающая панель. Заменяет все системные окошки-диалоги. */
final class Sheet {
    interface TextCb {
        void got(String s);
    }

    private final MainActivity a;
    private final Ui ui;
    private final Palette p;
    private final Dialog dlg;
    private final FrameLayout root;
    private final View dim;
    private final LinearLayout box;
    private boolean closing;

    Sheet(MainActivity a) {
        this.a = a;
        this.ui = a.ui;
        this.p = ui.p;
        dlg = new Dialog(a, android.R.style.Theme_Translucent_NoTitleBar);
        root = new FrameLayout(a);
        dim = new View(a);
        dim.setBackgroundColor(p.scrim);
        dim.setOnClickListener(v -> dismiss());
        root.addView(dim, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        box = ui.vertical();
        GradientDrawable g = new GradientDrawable();
        g.setColor(p.surface);
        float r = ui.dp(28);
        g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(g);
        box.setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(22));
        box.setClickable(true);
        View handle = new View(a);
        handle.setBackground(ui.rounded(p.divider, 2));
        LinearLayout.LayoutParams hp = ui.lp(ui.dp(38), ui.dp(4));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.bottomMargin = ui.dp(12);
        box.addView(handle, hp);
        root.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM));
    }

    Sheet title(String s) {
        TextView t = ui.label(s, 19, p.text, true);
        t.setPadding(ui.dp(4), 0, ui.dp(4), ui.dp(8));
        box.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        return this;
    }

    Sheet text(String s) {
        TextView t = ui.label(s, 15, p.sub, false);
        t.setPadding(ui.dp(4), 0, ui.dp(4), ui.dp(12));
        box.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        return this;
    }

    Sheet view(View v) {
        box.addView(v);
        return this;
    }

    /** Пункт меню. color == 0: обычный цвет текста. */
    Sheet item(int icon, String label, int color, final Runnable action) {
        int c = color == 0 ? p.text : color;
        LinearLayout row = ui.horizontal();
        row.setPadding(ui.dp(8), 0, ui.dp(8), 0);
        row.setBackground(ui.ripple(0x00000000, 16));
        row.setClickable(true);
        if (icon != 0) {
            row.addView(ui.icon(icon, 22, color == 0 ? p.sub : color), ui.lpm(ui.dp(22), ui.dp(22), 0, 0, 16, 0));
        }
        row.addView(ui.label(label, 17, c, false), ui.lpw(0, Ui.WRAP, 1f));
        row.setOnClickListener(v -> {
            dismiss();
            if (action != null) action.run();
        });
        box.addView(row, ui.lp(Ui.MATCH, ui.dp(54)));
        return this;
    }

    /** Две кнопки в ряд: «Отмена» и основное действие. */
    Sheet buttons(String cancel, String ok, boolean danger, final Runnable onOk) {
        LinearLayout row = ui.horizontal();
        TextView c = ui.softButton(cancel, p.text);
        c.setOnClickListener(v -> dismiss());
        row.addView(c, ui.lpw(0, Ui.WRAP, 1f));
        TextView o = ui.button(ok);
        if (danger) o.setBackground(ui.ripple(p.danger, 16));
        o.setOnClickListener(v -> {
            dismiss();
            if (onOk != null) onOk.run();
        });
        row.addView(o, ui.lpm(0, Ui.WRAP, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) o.getLayoutParams()).weight = 1f;
        box.addView(row, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        return this;
    }

    /** Показ значка подтверждения с текстом владельца. */
    Sheet badgeInfo(String user, Model.Badge b) {
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, ui.dp(8), 0, ui.dp(8));
        BadgeView bv = new BadgeView(a, 56);
        bv.bind(user, b);
        bv.setOnClickListener(null);
        bv.setClickable(false);
        col.addView(bv, ui.lp(ui.dp(56), ui.dp(56)));
        TextView t = ui.label(BadgeView.message(a, user, b), 18, p.text, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(ui.dp(12), ui.dp(14), ui.dp(12), ui.dp(6));
        col.addView(t, ui.lp(Ui.MATCH, Ui.WRAP));
        box.addView(col, ui.lp(Ui.MATCH, Ui.WRAP));
        return this;
    }

    void show() {
        Window w = dlg.getWindow();
        dlg.setContentView(root);
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        dlg.show();
        dim.setAlpha(0f);
        dim.animate().alpha(1f).setDuration(180).start();
        box.setVisibility(View.INVISIBLE);
        box.post(() -> {
            box.setTranslationY(box.getHeight());
            box.setVisibility(View.VISIBLE);
            box.animate().translationY(0).setDuration(220).start();
        });
    }

    void dismiss() {
        if (closing) return;
        closing = true;
        a.hideKeyboard();
        dim.animate().alpha(0f).setDuration(160).start();
        box.animate().translationY(box.getHeight()).setDuration(180).withEndAction(() -> {
            try {
                dlg.dismiss();
            } catch (Exception ignored) {
                // окно уже закрыто
            }
        }).start();
    }

    // ------------------------------------------------------------------ готовые панели

    static void confirm(MainActivity a, String title, String text, String ok, boolean danger, Runnable onOk) {
        Sheet s = new Sheet(a).title(title);
        if (text != null && !text.isEmpty()) s.text(text);
        s.buttons(a.getString(R.string.cancel), ok, danger, onOk).show();
    }

    static void input(MainActivity a, String title, String hint, String initial, int maxLen, boolean multiline,
                      String ok, final TextCb cb) {
        final Sheet s = new Sheet(a).title(title);
        final EditText e = a.ui.edit(hint);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLen)});
        if (multiline) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        if (initial != null) {
            e.setText(initial);
            e.setSelection(e.getText().length());
        }
        s.view(e);
        s.buttons(a.getString(R.string.cancel), ok, false, () -> cb.got(e.getText().toString().trim()));
        s.show();
        e.requestFocus();
    }
}
