package app.flaugram;

import android.animation.ObjectAnimator;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Профиль другого человека: повторяет референс (свечение, статус, пять кнопок, юзернейм с иконкой). */
final class UserScreen extends Screen {
    private final Model.Row r;
    private AvatarView avatar;
    private NameLine name;
    private TextView status, likeCount, soundLabel, username, bioText, contactText;
    private ImageView likeIcon, soundIcon, contactIcon;
    private LinearLayout bioCard, contactRow;

    UserScreen(MainActivity a, Model.Row seed) {
        super(a);
        this.r = seed;
    }

    @Override
    View build() {
        FrameLayout frame = new FrameLayout(a);
        frame.setBackgroundColor(p.bg);

        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = ui.vertical();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, ui.dp(52), 0, ui.dp(32));

        avatar = new AvatarView(a, ui.dp(132), ui.dp(250));
        col.addView(avatar, ui.lp(ui.dp(250), ui.dp(250)));

        name = new NameLine(a, 23, p.text, true, 22).center();
        col.addView(name, ui.lpm(Ui.WRAP, Ui.WRAP, 24, 2, 24, 0));
        status = ui.label("", 16, p.sub, false);
        status.setGravity(Gravity.CENTER);
        col.addView(status, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 2, 0, 22));

        // пять кнопок
        LinearLayout actions = ui.horizontal();
        actions.setWeightSum(5f);
        actions.setPadding(ui.dp(8), 0, ui.dp(8), 0);
        LinearLayout tChat = tile(R.drawable.ic_chat_solid, ui.t(R.string.act_chat));
        LinearLayout tCall = tile(R.drawable.ic_phone, ui.t(R.string.act_call));
        LinearLayout tSound = tile(R.drawable.ic_bell, ui.t(R.string.act_sound));
        LinearLayout tGift = tile(R.drawable.ic_gift, ui.t(R.string.act_gift));
        LinearLayout tLike = tile(R.drawable.ic_heart, "0");
        soundIcon = (ImageView) ((LinearLayout) tSound).getChildAt(0);
        soundLabel = (TextView) tSound.getChildAt(1);
        likeIcon = (ImageView) tLike.getChildAt(0);
        likeCount = (TextView) tLike.getChildAt(1);
        for (LinearLayout t : new LinearLayout[]{tChat, tCall, tSound, tGift, tLike}) {
            actions.addView(t, ui.lpm(0, ui.dp(88), 4, 0, 4, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        col.addView(actions, ui.lp(Ui.MATCH, Ui.WRAP));
        tChat.setOnClickListener(v -> openChat());
        tCall.setOnClickListener(v -> a.toast(ui.t(R.string.soon)));
        tGift.setOnClickListener(v -> a.toast(ui.t(R.string.soon)));
        tSound.setOnClickListener(v -> toggleMute());
        tLike.setOnClickListener(v -> toggleLike());

        // юзернейм
        LinearLayout uname = ui.horizontal();
        uname.setPadding(ui.dp(28), ui.dp(30), ui.dp(28), ui.dp(6));
        LinearLayout un = ui.vertical();
        username = ui.label("", 23, p.text, false);
        username.setSingleLine(true);
        un.addView(username);
        un.addView(ui.label(ui.t(R.string.username_label), 15, p.text, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 6, 0, 0));
        uname.addView(un, ui.lpw(0, Ui.WRAP, 1f));
        ImageView qr = ui.icon(R.drawable.ic_qr, 36, p.sub);
        qr.setOnClickListener(v -> a.copy("@" + r.user));
        uname.addView(qr);
        col.addView(uname, ui.lp(Ui.MATCH, Ui.WRAP));

        // о себе
        bioCard = ui.card();
        bioCard.setPadding(ui.dp(18), ui.dp(14), ui.dp(18), ui.dp(14));
        bioText = ui.label("", 16, p.text, false);
        bioCard.addView(bioText);
        bioCard.addView(ui.label(ui.t(R.string.profile_bio), 13, p.sub, false), ui.lpm(Ui.WRAP, Ui.WRAP, 0, 4, 0, 0));
        col.addView(bioCard, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 16, 16, 0));

        // контакт
        contactRow = ui.horizontal();
        contactRow.setPadding(ui.dp(18), ui.dp(16), ui.dp(18), ui.dp(16));
        contactRow.setBackground(ui.ripple(p.surface, 22));
        contactRow.setClickable(true);
        contactIcon = ui.icon(R.drawable.ic_person, 22, p.accent);
        contactRow.addView(contactIcon, ui.lpm(ui.dp(22), ui.dp(22), 0, 0, 14, 0));
        contactText = ui.label("", 16, p.accent, true);
        contactRow.addView(contactText);
        contactRow.setOnClickListener(v -> toggleContact());
        col.addView(contactRow, ui.lpm(Ui.MATCH, Ui.WRAP, 16, 12, 16, 0));

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        frame.addView(sv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        ImageView back = ui.iconButton(R.drawable.ic_back, p.text);
        back.setOnClickListener(v -> a.pop());
        frame.addView(back, new FrameLayout.LayoutParams(ui.dp(48), ui.dp(48), Gravity.TOP | Gravity.START));
        ((FrameLayout.LayoutParams) back.getLayoutParams()).setMargins(ui.dp(8), ui.dp(8), 0, 0);
        ImageView more = ui.iconButton(R.drawable.ic_more, p.text);
        more.setOnClickListener(v -> menu());
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(ui.dp(48), ui.dp(48), Gravity.TOP | Gravity.END);
        mp.setMargins(0, ui.dp(8), ui.dp(8), 0);
        frame.addView(more, mp);

        bind();
        return frame;
    }

    private LinearLayout tile(int icon, String label) {
        LinearLayout t = ui.vertical();
        t.setGravity(Gravity.CENTER);
        t.setBackground(ui.ripple(p.card, 22));
        t.setClickable(true);
        t.addView(ui.icon(icon, 28, p.text), ui.lpm(ui.dp(28), ui.dp(28), 0, 0, 0, 8));
        TextView tv = ui.label(label, 13, p.text, true);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        t.addView(tv);
        return t;
    }

    private void bind() {
        avatar.bind(r);
        avatar.setGlow(r.avatar > 0 ? 0xFFFFFFFF : Images.nameColor(r.user));
        avatar.setOnline("online".equals(r.status));
        name.set(r.title(), r.user, r.badge);
        String st = Model.statusText(a, r.status);
        status.setText(st);
        status.setTextColor("online".equals(r.status) ? p.accent : p.sub);
        username.setText("@" + r.user);
        bioCard.setVisibility(r.bio.isEmpty() ? View.GONE : View.VISIBLE);
        bioText.setText(r.bio);
        boolean muted = Session.isMuted(r.key());
        soundIcon.setImageDrawable(ui.drawable(muted ? R.drawable.ic_bell_off : R.drawable.ic_bell, p.text));
        soundLabel.setText(muted ? ui.t(R.string.act_muted) : ui.t(R.string.act_sound));
        likeIcon.setImageDrawable(ui.drawable(r.liked ? R.drawable.ic_heart_solid : R.drawable.ic_heart,
                r.liked ? 0xFFFF4D6A : p.text));
        likeCount.setText(String.valueOf(r.likes));
        contactText.setText(r.contact ? ui.t(R.string.contact_remove) : ui.t(R.string.contact_add));
        contactText.setTextColor(r.contact ? p.danger : p.accent);
        contactIcon.setImageDrawable(ui.drawable(R.drawable.ic_person, r.contact ? p.danger : p.accent));
        boolean self = r.user.equalsIgnoreCase(Session.me);
        contactRow.setVisibility(self ? View.GONE : View.VISIBLE);
    }

    @Override
    void onShow() {
        if (!stale()) return;
        a.api("GET", "/user?name=" + Api.enc(r.user), null, res -> {
            if (res.code != 200 || res.json == null) return;
            Model.Row n = Model.user(res.json);
            if (n == null) return;
            copyFrom(n);
            bind();
        });
    }

    private void copyFrom(Model.Row n) {
        r.name = n.name;
        r.bio = n.bio;
        r.avatar = n.avatar;
        r.verified = n.verified;
        r.badge = n.badge;
        r.status = n.status;
        r.likes = n.likes;
        r.liked = n.liked;
        r.contact = n.contact;
        r.blocked = n.blocked;
        r.blockedMe = n.blockedMe;
        r.isOwnerAccount = n.isOwnerAccount;
        r.id = n.id;
    }

    private void openChat() {
        Screen below = a.below(this);
        if (below instanceof ChatScreen && ((ChatScreen) below).isWith(r)) {
            a.pop();
            return;
        }
        a.push(new ChatScreen(a, r));
    }

    private void toggleMute() {
        boolean on = !Session.isMuted(r.key());
        Session.setMuted(r.key(), on);
        bind();
        a.toast(on ? ui.t(R.string.muted_on) : ui.t(R.string.muted_off));
    }

    private void toggleLike() {
        if (r.user.equalsIgnoreCase(Session.me)) {
            a.toast(ui.t(R.string.like_self));
            return;
        }
        final boolean want = !r.liked;
        r.liked = want;
        r.likes = Math.max(0, r.likes + (want ? 1 : -1));
        bind();
        ObjectAnimator.ofFloat(likeIcon, "scaleX", 0.6f, 1.15f, 1f).setDuration(260).start();
        ObjectAnimator.ofFloat(likeIcon, "scaleY", 0.6f, 1.15f, 1f).setDuration(260).start();
        a.api("POST", "/like", Api.obj("name", r.user, "like", Boolean.valueOf(want)), res -> {
            if (res.code == 200 && res.json != null) {
                Model.Row n = Model.user(res.json);
                if (n != null) {
                    r.likes = n.likes;
                    r.liked = n.liked;
                    bind();
                }
            } else {
                a.toast(a.errText(res));
            }
        });
    }

    private void toggleContact() {
        final boolean add = !r.contact;
        a.api("POST", "/contact", Api.obj("name", r.user, "add", Boolean.valueOf(add)), res -> {
            if (res.code == 200 && res.json != null) {
                Model.Row n = Model.user(res.json);
                if (n != null) r.contact = n.contact;
                bind();
                a.toast(add ? ui.t(R.string.contact_added) : ui.t(R.string.contact_removed));
            } else {
                a.toast(a.errText(res));
            }
        });
    }

    private void toggleBlock() {
        final boolean block = !r.blocked;
        a.api("POST", "/block", Api.obj("username", r.user, "blocked", Boolean.valueOf(block)), res -> {
            if (res.code == 200 && res.json != null) {
                r.blocked = res.json.optBoolean("blocked");
                r.blockedMe = res.json.optBoolean("blocked_me");
                a.toast(r.blocked ? ui.t(R.string.blocked_toast) : ui.t(R.string.unblocked_toast));
            } else {
                a.toast(a.errText(res));
            }
        });
    }

    private void menu() {
        Sheet s = new Sheet(a).title(r.title());
        s.item(R.drawable.ic_copy, ui.t(R.string.copy_username), 0, () -> a.copy("@" + r.user));
        if (!r.user.equalsIgnoreCase(Session.me) && !r.isOwnerAccount) {
            s.item(R.drawable.ic_block, r.blocked ? ui.t(R.string.unblock_user) : ui.t(R.string.block_user), p.danger, this::toggleBlock);
        }
        if (!r.user.equalsIgnoreCase(Session.me)) {
            s.item(R.drawable.ic_person, r.contact ? ui.t(R.string.contact_remove) : ui.t(R.string.contact_add), 0, this::toggleContact);
        }
        if (Session.admin && !r.isOwnerAccount) {
            s.item(R.drawable.ic_verified, ui.t(R.string.admin_badge), p.accent, () -> a.push(new BadgeScreen(a, r)));
            s.item(R.drawable.ic_block, ui.t(R.string.admin_ban), p.danger, () -> AdminUsersScreen.banDialog(a, r.user, null));
        }
        s.show();
    }
}
