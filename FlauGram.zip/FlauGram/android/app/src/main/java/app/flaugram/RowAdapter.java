package app.flaugram;

import android.text.TextUtils;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Список диалогов, людей и результатов поиска. */
final class RowAdapter extends BaseAdapter {
    static final int DIALOGS = 0, PEOPLE = 1;

    private final MainActivity a;
    private final Ui ui;
    private final Palette p;
    private final int mode;
    private List<Model.Row> rows = new ArrayList<>();
    private final SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final SimpleDateFormat df = new SimpleDateFormat("dd.MM", Locale.getDefault());

    RowAdapter(MainActivity a, int mode) {
        this.a = a;
        this.ui = a.ui;
        this.p = a.ui.p;
        this.mode = mode;
    }

    void set(List<Model.Row> r) {
        rows = new ArrayList<>(r);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return rows.size(); }
    @Override public Object getItem(int i) { return rows.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override
    public View getView(int pos, View convert, ViewGroup parent) {
        Holder h;
        if (convert == null) {
            h = new Holder();
            convert = h.build();
            convert.setTag(h);
        } else {
            h = (Holder) convert.getTag();
        }
        h.bind(rows.get(pos));
        return convert;
    }

    private String when(long ts) {
        Date d = new Date(ts);
        return DateUtils.isToday(ts) ? tf.format(d) : df.format(d);
    }

    private final class Holder {
        LinearLayout root;
        AvatarView avatar;
        NameLine name;
        TextView sub, time, badge;
        ImageView mute, pin;

        View build() {
            root = ui.horizontal();
            root.setPadding(ui.dp(16), ui.dp(9), ui.dp(16), ui.dp(9));
            root.setBackground(ui.ripple(0x00000000, 0));

            avatar = new AvatarView(a, ui.dp(54), 0);
            root.addView(avatar, ui.lpm(ui.dp(54), ui.dp(54), 0, 0, 14, 0));

            LinearLayout col = ui.vertical();
            name = new NameLine(a, 16, p.text, true, 16);
            sub = ui.label("", 14, p.sub, false);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(name, ui.lp(Ui.WRAP, Ui.WRAP));
            col.addView(sub, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
            root.addView(col, ui.lpw(0, Ui.WRAP, 1f));

            LinearLayout right = ui.vertical();
            right.setGravity(Gravity.END);
            time = ui.label("", 12, p.sub, false);
            right.addView(time);
            LinearLayout line = ui.horizontal();
            pin = ui.icon(R.drawable.ic_pin, 14, p.sub);
            line.addView(pin, ui.lpm(ui.dp(14), ui.dp(14), 0, 0, 6, 0));
            mute = ui.icon(R.drawable.ic_bell_off, 14, p.sub);
            line.addView(mute, ui.lpm(ui.dp(14), ui.dp(14), 0, 0, 6, 0));
            badge = ui.label("", 12, 0xFFFFFFFF, true);
            badge.setGravity(Gravity.CENTER);
            badge.setMinWidth(ui.dp(22));
            badge.setPadding(ui.dp(7), ui.dp(2), ui.dp(7), ui.dp(2));
            line.addView(badge);
            right.addView(line, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 5, 0, 0));
            root.addView(right, ui.lp(Ui.WRAP, Ui.WRAP));
            return root;
        }

        void bind(Model.Row r) {
            avatar.bind(r);
            avatar.setOnline(!r.isChat() && "online".equals(r.status));
            name.set(r.title(), r.user, r.badge);
            if (mode == PEOPLE) {
                sub.setText(r.sub);
                sub.setTextColor("online".equals(r.status) ? p.accent : p.sub);
                time.setVisibility(View.GONE);
                badge.setVisibility(View.GONE);
                mute.setVisibility(View.GONE);
                return;
            }
            sub.setTextColor(p.sub);
            sub.setText((r.mine && !r.isChat() ? (r.seen ? "\u2713\u2713 " : "\u2713 ") : "") + (r.mine ? ui.t(R.string.you_prefix) : "") + r.sub);
            boolean muted = Session.isMuted(r.key());
            time.setVisibility(r.ts > 0 ? View.VISIBLE : View.GONE);
            time.setText(when(r.ts));
            time.setTextColor(r.unread > 0 && !muted ? p.accent : p.sub);
            mute.setVisibility(muted ? View.VISIBLE : View.GONE);
            pin.setVisibility(Session.isPinnedChat(r.key()) ? View.VISIBLE : View.GONE);
            if (r.unread > 0) {
                badge.setVisibility(View.VISIBLE);
                badge.setText(r.unread > 99 ? "99+" : String.valueOf(r.unread));
                badge.setBackground(ui.rounded(muted ? ui.dim(p.sub, 150) : p.accent, 12));
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }
}
