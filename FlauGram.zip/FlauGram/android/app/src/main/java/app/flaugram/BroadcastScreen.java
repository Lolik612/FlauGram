package app.flaugram;

import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Рассылка сообщения всем пользователям от имени владельца. */
final class BroadcastScreen extends Screen {
    BroadcastScreen(MainActivity a) {
        super(a);
    }

    @Override
    View build() {
        LinearLayout root = ui.vertical();
        root.setBackgroundColor(p.bg);
        root.addView(topBar(ui.t(R.string.admin_broadcast), null), ui.lp(Ui.MATCH, Ui.WRAP));
        LinearLayout col = ui.vertical();
        col.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(16));
        TextView info = ui.label(ui.t(R.string.broadcast_info), 14, p.sub, false);
        info.setPadding(ui.dp(6), 0, ui.dp(6), ui.dp(12));
        col.addView(info);
        final EditText text = ui.edit(ui.t(R.string.broadcast_hint));
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        text.setMinLines(6);
        text.setGravity(Gravity.TOP);
        text.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        col.addView(text, ui.lp(Ui.MATCH, Ui.WRAP));
        TextView send = ui.button(ui.t(R.string.broadcast_send));
        send.setOnClickListener(v -> {
            final String t = text.getText().toString().trim();
            if (t.isEmpty()) return;
            Sheet.confirm(a, ui.t(R.string.broadcast_confirm_title), ui.t(R.string.broadcast_confirm_text), ui.t(R.string.broadcast_send), false, () ->
                    a.api("POST", "/admin/broadcast", Api.obj("text", t), r -> {
                        if (r.code == 200 && r.json != null) {
                            a.toast(ui.t(R.string.broadcast_done, r.json.optInt("sent")));
                            a.pop();
                        } else {
                            a.toast(a.errText(r));
                        }
                    }));
        });
        col.addView(send, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        root.addView(col, ui.lp(Ui.MATCH, Ui.WRAP));
        return root;
    }
}
