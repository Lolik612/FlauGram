package app.flaugram;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Переписка: личная, группа или канал. */
final class ChatScreen extends Screen {
    private static final int REQ_PHOTO = 1;

    private Model.Row peer;
    private AvatarView avatar;
    private NameLine title;
    private TextView sub;
    private ListView list;
    private Adapter adapter;
    private EditText input;
    private ImageView sendIcon;
    private LinearLayout inputBar, quoteBar;
    private TextView joinBar, readOnlyBar, quoteTitle, quotePreview;
    private Model.Msg replyingTo, editing;
    private boolean historyLoaded;

    ChatScreen(MainActivity a, Model.Row peer) {
        super(a);
        this.peer = peer;
    }

    boolean isWith(Model.Row o) {
        return peer.isChat() ? o.chatId == peer.chatId : o.chatId == 0 && o.user.equalsIgnoreCase(peer.user);
    }

    private boolean matches(Model.Msg m) {
        if (peer.isChat()) return m.chat == peer.chatId;
        if (m.chat != 0) return false;
        String other = m.from.equalsIgnoreCase(Session.me) ? m.to : m.from;
        return other.equalsIgnoreCase(peer.user);
    }

    @Override
    boolean showsChat(Model.Msg m) {
        return matches(m);
    }

    @Override
    View build() {
        LinearLayout col = ui.vertical();
        col.setBackgroundColor(p.bg);

        // шапка
        LinearLayout head = ui.horizontal();
        head.setPadding(ui.dp(4), ui.dp(6), ui.dp(8), ui.dp(6));
        ImageView back = ui.iconButton(R.drawable.ic_back, p.text);
        back.setOnClickListener(v -> a.pop());
        head.addView(back);
        LinearLayout who = ui.horizontal();
        who.setClickable(true);
        who.setBackground(ui.ripple(0x00000000, 16));
        who.setPadding(ui.dp(4), ui.dp(2), ui.dp(8), ui.dp(2));
        who.setOnClickListener(v -> openProfile());
        avatar = new AvatarView(a, ui.dp(42), 0);
        who.addView(avatar, ui.lpm(ui.dp(42), ui.dp(42), 0, 0, 12, 0));
        LinearLayout names = ui.vertical();
        title = new NameLine(a, 17, p.text, true, 16);
        sub = ui.label("", 13, p.sub, false);
        sub.setSingleLine(true);
        names.addView(title, ui.lp(Ui.WRAP, Ui.WRAP));
        names.addView(sub);
        who.addView(names, ui.lpw(0, Ui.WRAP, 1f));
        head.addView(who, ui.lpw(0, Ui.WRAP, 1f));
        ImageView more = ui.iconButton(R.drawable.ic_more, p.text);
        more.setOnClickListener(v -> menu());
        head.addView(more);
        col.addView(head, ui.lp(Ui.MATCH, Ui.WRAP));

        adapter = new Adapter();
        list = new ListView(a);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setClipToPadding(false);
        list.setPadding(0, ui.dp(6), 0, ui.dp(6));
        list.setAdapter(adapter);
        col.addView(list, ui.lpw(Ui.MATCH, 0, 1f));

        // панель «ответ» или «редактирование»
        quoteBar = ui.horizontal();
        quoteBar.setBackgroundColor(p.surface);
        quoteBar.setPadding(ui.dp(14), ui.dp(8), ui.dp(4), ui.dp(8));
        View strip = new View(a);
        strip.setBackground(ui.rounded(p.accent, 2));
        quoteBar.addView(strip, ui.lpm(ui.dp(3), ui.dp(36), 0, 0, 10, 0));
        LinearLayout qcol = ui.vertical();
        quoteTitle = ui.label("", 13, p.accent, true);
        quotePreview = ui.label("", 14, p.sub, false);
        quotePreview.setSingleLine(true);
        quotePreview.setEllipsize(TextUtils.TruncateAt.END);
        qcol.addView(quoteTitle);
        qcol.addView(quotePreview);
        quoteBar.addView(qcol, ui.lpw(0, Ui.WRAP, 1f));
        ImageView cancel = ui.iconButton(R.drawable.ic_close, p.sub);
        cancel.setOnClickListener(v -> clearQuote());
        quoteBar.addView(cancel);
        quoteBar.setVisibility(View.GONE);
        col.addView(quoteBar, ui.lp(Ui.MATCH, Ui.WRAP));

        // ввод
        inputBar = ui.horizontal();
        inputBar.setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(10));
        inputBar.setGravity(Gravity.BOTTOM);
        LinearLayout pill = ui.horizontal();
        pill.setGravity(Gravity.BOTTOM);
        pill.setBackground(ui.rounded(p.input, 26));
        ImageView attach = ui.iconButton(R.drawable.ic_image, p.sub);
        attach.setOnClickListener(v -> a.pickImage(this, REQ_PHOTO));
        pill.addView(attach, ui.lp(ui.dp(46), ui.dp(48)));
        input = new EditText(a);
        input.setHint(ui.t(R.string.message_hint));
        input.setHintTextColor(p.sub);
        input.setTextColor(p.text);
        input.setTextSize(16);
        input.setBackground(null);
        input.setPadding(0, ui.dp(13), ui.dp(14), ui.dp(13));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMaxLines(5);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        pill.addView(input, ui.lpw(0, Ui.WRAP, 1f));
        inputBar.addView(pill, ui.lpw(0, Ui.WRAP, 1f));
        FrameLayout send = new FrameLayout(a);
        send.setBackground(ui.ripple(p.accent, 26));
        send.setClickable(true);
        sendIcon = ui.icon(R.drawable.ic_send, 22, Color.WHITE);
        send.addView(sendIcon, new FrameLayout.LayoutParams(ui.dp(22), ui.dp(22), Gravity.CENTER));
        send.setOnClickListener(v -> submit());
        inputBar.addView(send, ui.lpm(ui.dp(50), ui.dp(50), 8, 0, 0, 0));
        col.addView(inputBar, ui.lp(Ui.MATCH, Ui.WRAP));

        joinBar = ui.button(ui.t(R.string.chat_join));
        joinBar.setOnClickListener(v -> join());
        col.addView(joinBar, ui.lpm(Ui.MATCH, Ui.WRAP, 14, 6, 14, 14));
        readOnlyBar = ui.label(ui.t(R.string.chat_readonly), 14, p.sub, false);
        readOnlyBar.setGravity(Gravity.CENTER);
        readOnlyBar.setPadding(ui.dp(12), ui.dp(16), ui.dp(12), ui.dp(16));
        col.addView(readOnlyBar, ui.lp(Ui.MATCH, Ui.WRAP));

        bindHeader();
        updateBottom();
        return col;
    }

    // ------------------------------------------------------------------ шапка и меню

    private void bindHeader() {
        avatar.bind(peer);
        avatar.setOnline(!peer.isChat() && "online".equals(peer.status));
        title.set(peer.title(), peer.user, peer.badge);
        if (peer.isChat()) {
            sub.setText(("channel".equals(peer.kind) ? ui.t(R.string.kind_channel) : ui.t(R.string.kind_group))
                    + (peer.members > 0 ? "  ·  " + ("channel".equals(peer.kind) ? ui.t(R.string.subscribers_count, peer.members)
                    : ui.t(R.string.members_count, peer.members)) : ""));
            sub.setTextColor(p.sub);
        } else {
            String st = Model.statusText(a, peer.status);
            sub.setText(st.isEmpty() ? "@" + peer.user : st);
            sub.setTextColor("online".equals(peer.status) ? p.accent : p.sub);
        }
    }

    private void updateBottom() {
        boolean chat = peer.isChat();
        boolean canWrite = !chat || (peer.member && ("group".equals(peer.kind) || peer.owner));
        inputBar.setVisibility(canWrite ? View.VISIBLE : View.GONE);
        joinBar.setVisibility(chat && !peer.member ? View.VISIBLE : View.GONE);
        readOnlyBar.setVisibility(chat && peer.member && !canWrite ? View.VISIBLE : View.GONE);
    }

    private void openProfile() {
        if (peer.isChat()) a.push(new ChatInfoScreen(a, peer)); else a.push(new UserScreen(a, peer));
    }

    private void menu() {
        final boolean muted = Session.isMuted(peer.key());
        Sheet s = new Sheet(a).title(peer.title());
        s.item(peer.isChat() ? R.drawable.ic_group : R.drawable.ic_person,
                peer.isChat() ? ui.t(R.string.menu_about) : ui.t(R.string.menu_profile), 0, this::openProfile);
        s.item(muted ? R.drawable.ic_bell : R.drawable.ic_bell_off, muted ? ui.t(R.string.unmute) : ui.t(R.string.mute), 0, () -> {
            Session.setMuted(peer.key(), !muted);
            a.toast(!muted ? ui.t(R.string.muted_on) : ui.t(R.string.muted_off));
        });
        s.show();
    }

    // ------------------------------------------------------------------ загрузка

    @Override
    void onShow() {
        a.cancelNotification(peer);
        if (!stale()) return;
        if (peer.isChat()) {
            a.api("GET", "/chat?id=" + peer.chatId, null, r -> {
                if (r.code == 404) {
                    a.toast(ui.t(R.string.chat_gone));
                    a.pop();
                    return;
                }
                Model.Row row = r.json == null ? null : Model.chat(r.json);
                if (row == null) return;
                peer.name = row.name;
                peer.bio = row.bio;
                peer.avatar = row.avatar;
                peer.members = row.members;
                peer.member = row.member;
                peer.owner = row.owner;
                peer.kind = row.kind;
                bindHeader();
                updateBottom();
                if (row.member) loadHistory();
            });
        } else {
            a.api("GET", "/user?name=" + Api.enc(peer.user), null, r -> {
                Model.Row row = r.code == 200 && r.json != null ? Model.user(r.json) : null;
                if (row == null) return;
                peer.name = row.name;
                peer.bio = row.bio;
                peer.avatar = row.avatar;
                peer.status = row.status;
                peer.badge = row.badge;
                peer.verified = row.verified;
                peer.likes = row.likes;
                peer.liked = row.liked;
                peer.contact = row.contact;
                bindHeader();
            });
            loadHistory();
        }
    }

    private void loadHistory() {
        final String path = peer.isChat() ? "/history?chat=" + peer.chatId + "&limit=100"
                : "/history?with=" + Api.enc(peer.user) + "&limit=100";
        a.api("GET", path, null, r -> {
            if (r.code != 200 || r.json == null) return;
            adapter.merge(Model.msgs(r.json.optJSONArray("messages")), false);
            if (!historyLoaded) {
                historyLoaded = true;
                scrollToEnd();
            }
            String st = r.json.optString("status");
            if (!st.isEmpty() && !peer.isChat()) {
                peer.status = st;
                bindHeader();
            }
        });
    }

    private void join() {
        a.api("POST", "/chat/join", Api.obj("id", Long.valueOf(peer.chatId)), r -> {
            Model.Row row = r.code == 200 && r.json != null ? Model.chat(r.json) : null;
            if (row == null) {
                a.toast(a.errText(r));
                return;
            }
            peer.member = row.member;
            peer.members = row.members;
            peer.owner = row.owner;
            bindHeader();
            updateBottom();
            loadHistory();
        });
    }

    // ------------------------------------------------------------------ новые сообщения

    @Override
    void onUpdates(List<Model.Msg> l) {
        long maxIncoming = 0;
        boolean atBottom = list.getLastVisiblePosition() >= adapter.getCount() - 1;
        boolean added = false;
        for (Model.Msg m : l) {
            if (!matches(m)) continue;
            if (m.deleted) {
                adapter.remove(m.id);
                continue;
            }
            if (adapter.merge(Collections.singletonList(m), true)) added = true;
            if (!m.from.equalsIgnoreCase(Session.me) && !m.edited) maxIncoming = Math.max(maxIncoming, m.id);
        }
        if (added && atBottom) scrollToEnd();
        if (maxIncoming > 0 && a.top() == this) {
            JSONObject body = peer.isChat() ? Api.obj("chat", Long.valueOf(peer.chatId), "upto", Long.valueOf(maxIncoming))
                    : Api.obj("with", peer.user, "upto", Long.valueOf(maxIncoming));
            a.api("POST", "/read", body, null);
        }
    }

    private void scrollToEnd() {
        list.post(() -> {
            if (adapter.getCount() > 0) list.setSelection(adapter.getCount() - 1);
        });
    }

    // ------------------------------------------------------------------ отправка и правка

    private void submit() {
        final String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        if (editing != null) {
            final Model.Msg m = editing;
            if (text.equals(m.text)) {
                clearQuote();
                return;
            }
            input.setText("");
            clearQuote();
            a.api("POST", "/edit", Api.obj("id", Long.valueOf(m.id), "text", text), r -> {
                JSONObject mo = r.json == null ? null : r.json.optJSONObject("message");
                Model.Msg nm = Model.msg(mo);
                if (r.code == 200 && nm != null) adapter.merge(Collections.singletonList(nm), true);
                else a.toast(a.errText(r));
            });
            return;
        }
        final Model.Msg rep = replyingTo;
        input.setText("");
        clearQuote();
        Object replyId = rep == null ? JSONObject.NULL : (Object) Long.valueOf(rep.id);
        JSONObject body = peer.isChat() ? Api.obj("chat", Long.valueOf(peer.chatId), "text", text, "reply_to", replyId)
                : Api.obj("to", peer.user, "text", text, "reply_to", replyId);
        a.api("POST", "/send", body, r -> {
            JSONObject mo = r.json == null ? null : r.json.optJSONObject("message");
            Model.Msg m = Model.msg(mo);
            if (r.code == 200 && m != null) {
                adapter.merge(Collections.singletonList(m), true);
                scrollToEnd();
                return;
            }
            a.toast(a.errText(r));
            if (input.getText().length() == 0) {
                input.setText(text);
                input.setSelection(input.getText().length());
            }
        });
    }

    private void setReply(Model.Msg m) {
        editing = null;
        replyingTo = m;
        quoteTitle.setText(ui.t(R.string.reply_to, m.fromName.isEmpty() ? m.from : m.fromName));
        quotePreview.setText(quote(!m.photo.isEmpty(), m.text).replace('\n', ' '));
        quoteBar.setVisibility(View.VISIBLE);
        sendIcon.setImageDrawable(ui.drawable(R.drawable.ic_send, Color.WHITE));
        focusInput();
    }

    private void setEdit(Model.Msg m) {
        replyingTo = null;
        editing = m;
        quoteTitle.setText(ui.t(R.string.editing));
        quotePreview.setText(quote(!m.photo.isEmpty(), m.text).replace('\n', ' '));
        quoteBar.setVisibility(View.VISIBLE);
        sendIcon.setImageDrawable(ui.drawable(R.drawable.ic_check, Color.WHITE));
        input.setText(m.text);
        input.setSelection(input.getText().length());
        focusInput();
    }

    private void clearQuote() {
        boolean wasEdit = editing != null;
        replyingTo = null;
        editing = null;
        quoteBar.setVisibility(View.GONE);
        sendIcon.setImageDrawable(ui.drawable(R.drawable.ic_send, Color.WHITE));
        if (wasEdit) input.setText("");
    }

    private void focusInput() {
        input.requestFocus();
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) a.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, 0);
    }

    @Override
    boolean onBack() {
        if (quoteBar.getVisibility() == View.VISIBLE) {
            clearQuote();
            return true;
        }
        return false;
    }

    private String quote(boolean photo, String text) {
        if (!photo) return text;
        return text.isEmpty() ? ui.t(R.string.msg_photo) : ui.t(R.string.msg_photo) + ": " + text;
    }

    // ------------------------------------------------------------------ действия над сообщением

    private void messageMenu(final Model.Msg m) {
        boolean mine = m.from.equalsIgnoreCase(Session.me);
        boolean canWrite = !peer.isChat() || (peer.member && ("group".equals(peer.kind) || peer.owner));
        Sheet s = new Sheet(a);
        if (canWrite) s.item(R.drawable.ic_reply, ui.t(R.string.msg_reply), 0, () -> setReply(m));
        if (!m.text.isEmpty()) s.item(R.drawable.ic_copy, ui.t(R.string.msg_copy), 0, () -> a.copy(m.text));
        if (mine) s.item(R.drawable.ic_edit, ui.t(R.string.msg_edit), 0, () -> setEdit(m));
        if (mine || Session.admin || (peer.isChat() && peer.owner)) {
            s.item(R.drawable.ic_delete, ui.t(R.string.msg_delete), p.danger, () ->
                    Sheet.confirm(a, ui.t(R.string.msg_delete_title), ui.t(R.string.msg_delete_text), ui.t(R.string.msg_delete), true, () ->
                            a.api("POST", "/delete", Api.obj("id", Long.valueOf(m.id)), r -> {
                                if (r.code == 200) adapter.remove(m.id); else a.toast(a.errText(r));
                            })));
        }
        s.show();
    }

    // ------------------------------------------------------------------ фото

    @Override
    void onResult(int req, final Uri uri) {
        if (req != REQ_PHOTO) return;
        a.toast(ui.t(R.string.preparing));
        a.io.execute(() -> {
            final Images.Encoded e = Images.encode(a, uri, 1280, false, 5 * 1024 * 1024);
            a.runOnUiThread(() -> {
                if (e == null) a.toast(ui.t(R.string.err_bad_image)); else photoSheet(e);
            });
        });
    }

    private void photoSheet(final Images.Encoded e) {
        ImageView iv = new ImageView(a);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setMaxHeight(ui.dp(320));
        Bitmap bmp = BitmapFactory.decodeByteArray(e.data, 0, e.data.length);
        if (bmp != null) iv.setImageBitmap(bmp);
        final EditText cap = ui.edit(ui.t(R.string.photo_caption_hint));
        cap.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        Sheet s = new Sheet(a).title(ui.t(R.string.photo_send_title));
        s.view(iv);
        cap.setLayoutParams(ui.lpm(Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        s.view(cap);
        s.buttons(ui.t(R.string.cancel), ui.t(R.string.send), false, () -> uploadPhoto(e, cap.getText().toString().trim()));
        s.show();
    }

    private void uploadPhoto(Images.Encoded e, String caption) {
        final Model.Msg rep = replyingTo;
        clearQuote();
        a.toast(ui.t(R.string.sending));
        String path = "/photo?" + (peer.isChat() ? "chat=" + peer.chatId : "to=" + Api.enc(peer.user))
                + "&w=" + e.w + "&h=" + e.h + (caption.isEmpty() ? "" : "&caption=" + Api.enc(caption))
                + (rep == null ? "" : "&reply_to=" + rep.id);
        a.apiBytes(path, e.data, r -> {
            Model.Msg m = Model.msg(r.json == null ? null : r.json.optJSONObject("message"));
            if (r.code == 200 && m != null) {
                adapter.merge(Collections.singletonList(m), true);
                scrollToEnd();
            } else {
                a.toast(a.errText(r));
            }
        });
    }

    private void viewPhoto(String file) {
        final Dialog d = new Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        ImageView iv = new ImageView(a);
        iv.setBackgroundColor(Color.BLACK);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setOnClickListener(v -> d.dismiss());
        d.setContentView(iv);
        Images.photo(iv, file, Session.token, 2048);
        d.show();
    }

    // ------------------------------------------------------------------ список

    private final class Adapter extends BaseAdapter {
        private final ArrayList<Model.Msg> msgs = new ArrayList<>();
        private ArrayList<Object> entries = new ArrayList<>();
        private final SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final SimpleDateFormat df = new SimpleDateFormat("d MMMM", Locale.getDefault());
        private final int maxW = (int) (a.getResources().getDisplayMetrics().widthPixels * 0.78f);

        /** Добавляет или заменяет сообщения. true, если появилось новое. */
        boolean merge(List<Model.Msg> more, boolean replace) {
            boolean added = false, changed = false;
            for (Model.Msg m : more) {
                int idx = indexOf(m.id);
                if (idx < 0) {
                    msgs.add(m);
                    added = true;
                    changed = true;
                } else if (replace || m.rev > msgs.get(idx).rev) {
                    msgs.set(idx, m);
                    changed = true;
                }
            }
            if (changed) {
                Collections.sort(msgs, (x, y) -> Long.compare(x.id, y.id));
                rebuild();
            }
            return added;
        }

        void remove(long id) {
            int i = indexOf(id);
            if (i >= 0) {
                msgs.remove(i);
                rebuild();
            }
        }

        int indexOf(long id) {
            for (int i = 0; i < msgs.size(); i++) if (msgs.get(i).id == id) return i;
            return -1;
        }

        int positionOf(long id) {
            for (int i = 0; i < entries.size(); i++) {
                Object o = entries.get(i);
                if (o instanceof Model.Msg && ((Model.Msg) o).id == id) return i;
            }
            return -1;
        }

        private void rebuild() {
            ArrayList<Object> out = new ArrayList<>();
            String lastDay = "";
            SimpleDateFormat key = new SimpleDateFormat("yyyyMMdd", Locale.US);
            for (Model.Msg m : msgs) {
                String day = key.format(new Date(m.ts));
                if (!day.equals(lastDay)) {
                    out.add(Long.valueOf(m.ts));
                    lastDay = day;
                }
                out.add(m);
            }
            entries = out;
            notifyDataSetChanged();
        }

        private String dayLabel(long ts) {
            if (DateUtils.isToday(ts)) return ui.t(R.string.today);
            if (DateUtils.isToday(ts + 86400000L)) return ui.t(R.string.yesterday);
            return df.format(new Date(ts));
        }

        @Override public int getCount() { return entries.size(); }
        @Override public Object getItem(int i) { return entries.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return entries.get(i) instanceof Long ? 0 : 1; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Object o = entries.get(pos);
            if (o instanceof Long) {
                TextView t;
                if (convert == null) {
                    t = ui.label("", 13, p.sub, true);
                    t.setGravity(Gravity.CENTER);
                    t.setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(4));
                    t.setBackground(ui.rounded(p.surface, 12));
                    FrameLayout f = new FrameLayout(a);
                    f.setPadding(0, ui.dp(8), 0, ui.dp(4));
                    f.addView(t, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
                    f.setTag(t);
                    convert = f;
                }
                ((TextView) convert.getTag()).setText(dayLabel((Long) o));
                return convert;
            }
            Holder h;
            if (convert == null) {
                h = new Holder();
                convert = h.build();
                convert.setTag(h);
            } else {
                h = (Holder) convert.getTag();
            }
            h.bind((Model.Msg) o);
            return convert;
        }

        private final class Holder {
            LinearLayout row, bubble, quote;
            View strip;
            ImageView photo;
            NameLine sender;
            TextView qFrom, qText, text, time;

            View build() {
                row = new LinearLayout(a);
                row.setPadding(ui.dp(10), ui.dp(2), ui.dp(10), ui.dp(2));
                bubble = ui.vertical();
                bubble.setPadding(ui.dp(12), ui.dp(7), ui.dp(12), ui.dp(6));

                sender = new NameLine(a, 13, p.accent, true, 12);
                bubble.addView(sender, ui.lp(Ui.WRAP, Ui.WRAP));

                quote = ui.horizontal();
                quote.setPadding(ui.dp(8), ui.dp(5), ui.dp(10), ui.dp(5));
                strip = new View(a);
                quote.addView(strip, ui.lpm(ui.dp(3), Ui.MATCH, 0, 0, 8, 0));
                LinearLayout qcol = ui.vertical();
                qFrom = ui.label("", 12, p.accent, true);
                qText = ui.label("", 13, p.sub, false);
                qText.setMaxLines(2);
                qText.setEllipsize(TextUtils.TruncateAt.END);
                qText.setMaxWidth(maxW - ui.dp(48));
                qcol.addView(qFrom);
                qcol.addView(qText);
                quote.addView(qcol);
                bubble.addView(quote, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 2, 0, 5));

                photo = new ImageView(a);
                photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
                bubble.addView(photo, ui.lpm(maxW, maxW, 0, 0, 0, 4));

                text = ui.label("", 16, p.text, false);
                text.setMaxWidth(maxW);
                bubble.addView(text, ui.lp(Ui.WRAP, Ui.WRAP));

                time = ui.label("", 11, p.sub, false);
                LinearLayout.LayoutParams tp = ui.lp(Ui.WRAP, Ui.WRAP);
                tp.gravity = Gravity.END;
                bubble.addView(time, tp);
                row.addView(bubble, ui.lp(Ui.WRAP, Ui.WRAP));
                return row;
            }

            void bind(final Model.Msg m) {
                boolean mine = m.from.equalsIgnoreCase(Session.me);
                row.setGravity(mine ? Gravity.END : Gravity.START);
                GradientDrawable g = new GradientDrawable();
                g.setColor(mine ? p.outBubble : p.inBubble);
                float big = ui.dp(19), small = ui.dp(6);
                g.setCornerRadii(mine ? new float[]{big, big, big, big, small, small, big, big}
                        : new float[]{big, big, big, big, big, big, small, small});
                bubble.setBackground(g);

                if (!mine && peer.isChat() && "group".equals(peer.kind)) {
                    sender.set(m.fromName.isEmpty() ? m.from : m.fromName, m.from, m.fromBadge);
                    sender.text.setTextColor(Images.nameColor(m.from));
                    sender.setVisibility(View.VISIBLE);
                } else {
                    sender.setVisibility(View.GONE);
                }
                text.setTextColor(mine ? Color.WHITE : p.text);
                text.setText(m.text);
                text.setVisibility(m.text.isEmpty() ? View.GONE : View.VISIBLE);
                time.setTextColor(mine ? 0xB3FFFFFF : p.sub);
                time.setText((m.edited ? ui.t(R.string.edited) + "  " : "") + tf.format(new Date(m.ts)));

                if (m.photo.isEmpty()) {
                    photo.setVisibility(View.GONE);
                    photo.setTag(null);
                    photo.setOnClickListener(null);
                } else {
                    float ratio = m.w > 0 && m.h > 0 ? (float) m.h / m.w : 0.75f;
                    int bw = maxW;
                    int bh = Math.round(bw * ratio);
                    int maxH = ui.dp(340);
                    if (bh > maxH) {
                        bh = maxH;
                        bw = Math.max(ui.dp(80), Math.round(bh / ratio));
                    }
                    if (bh < ui.dp(60)) bh = ui.dp(60);
                    LinearLayout.LayoutParams pp = (LinearLayout.LayoutParams) photo.getLayoutParams();
                    pp.width = bw;
                    pp.height = bh;
                    photo.setLayoutParams(pp);
                    photo.setBackgroundColor(mine ? 0x33FFFFFF : 0x22888888);
                    photo.setVisibility(View.VISIBLE);
                    Images.photo(photo, m.photo, Session.token, 800);
                    final String file = m.photo;
                    photo.setOnClickListener(v -> viewPhoto(file));
                }

                if (m.replyId > 0) {
                    quote.setVisibility(View.VISIBLE);
                    quote.setBackground(ui.rounded(mine ? 0x33FFFFFF : 0x22888888, 10));
                    strip.setBackground(ui.rounded(mine ? 0xCCFFFFFF : p.accent, 2));
                    qFrom.setText(m.replyName.isEmpty() ? m.replyFrom : m.replyName);
                    qFrom.setTextColor(mine ? Color.WHITE : p.accent);
                    qText.setText(m.replyDeleted ? ui.t(R.string.msg_deleted) : quote(m.replyPhoto, m.replyText));
                    qText.setTextColor(mine ? 0xCCFFFFFF : p.sub);
                    quote.setOnClickListener(v -> {
                        int at = positionOf(m.replyId);
                        if (at >= 0) list.setSelection(at); else a.toast(ui.t(R.string.msg_above));
                    });
                } else {
                    quote.setVisibility(View.GONE);
                    quote.setOnClickListener(null);
                }
                bubble.setOnClickListener(v -> messageMenu(m));
                bubble.setOnLongClickListener(v -> {
                    messageMenu(m);
                    return true;
                });
            }
        }
    }
}
