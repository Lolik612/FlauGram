package app.flaugram;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int SCREEN_REGISTER = 0, SCREEN_LIST = 1, SCREEN_CHAT = 2;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final String EMPTY_DIALOGS = "Пока нет диалогов.\nНайдите человека по юзернейму в поиске выше.";

    /** Пропускает только латиницу, цифры и подчёркивание. */
    private static final InputFilter NAME_FILTER = (src, start, end, dest, ds, de) -> {
        StringBuilder sb = null;
        for (int i = start; i < end; i++) {
            char ch = src.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_';
            if (ok) {
                if (sb != null) sb.append(ch);
            } else if (sb == null) {
                sb = new StringBuilder();
                sb.append(src, start, i);
            }
        }
        return sb == null ? null : sb.toString();
    };

    static class Msg {
        long id;
        String from = "", to = "", text = "";
        long ts;
        long replyId;
        String replyFrom = "", replyText = "";
    }

    static class Row {
        String user = "", sub = "";
        long ts;
        int unread;
        boolean mine;
    }

    // общее состояние
    private SharedPreferences prefs;
    private Palette p;
    private boolean dark;
    private String token, me;
    private int screen = SCREEN_REGISTER;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView statusView;

    // экран списка
    private ListView dialogsList;
    private RowAdapter rowAdapter;
    private TextView emptyView;
    private EditText searchBox;
    private final List<Row> dialogRows = new ArrayList<>();
    private boolean searching = false;
    private boolean dialogsLoaded = false;
    private Runnable pendingSearch;

    // экран чата
    private String chatWith;
    private ListView chatList;
    private ChatAdapter chatAdapter;
    private EditText input;
    private Msg replyingTo;
    private LinearLayout replyBar;
    private TextView replyTitle, replyPreview;

    /** Открыто ли приложение сейчас. Пока открыто, уведомления не показываем. */
    static volatile boolean visible = false;

    // опрос сервера
    private volatile boolean running = false;
    private volatile int generation = 0;

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("flaugram", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", true);
        setTheme(dark ? android.R.style.Theme_DeviceDefault_NoActionBar
                : android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        super.onCreate(b);
        p = dark ? Palette.dark() : Palette.light();
        token = prefs.getString("token", null);
        me = prefs.getString("me", null);
        applyBars();
        if (token == null || me == null) showRegister(null); else showList();
        handleIntent(getIntent());
    }

    @Override
    protected void onStart() {
        super.onStart();
        visible = true;
        startPolling();
        if (token != null && prefs.getBoolean("notify", true)) PollService.start(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        visible = false;
        stopPolling();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** Нажатие на уведомление открывает переписку с отправителем. */
    private void handleIntent(Intent i) {
        if (i == null || token == null) return;
        String chat = i.getStringExtra("chat");
        if (chat == null || chat.isEmpty()) return;
        i.removeExtra("chat");
        openChat(chat);
    }

    @Override
    public void onBackPressed() {
        if (screen == SCREEN_CHAT) {
            showList();
            return;
        }
        super.onBackPressed();
    }

    private void applyBars() {
        Window w = getWindow();
        w.setStatusBarColor(p.bar);
        w.setNavigationBarColor(p.bg);
        View d = w.getDecorView();
        int f = d.getSystemUiVisibility();
        if (Build.VERSION.SDK_INT >= 23) {
            f = p.dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            f = p.dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        d.setSystemUiVisibility(f);
    }

    // ------------------------------------------------------------------ регистрация

    private void showRegister(String error) {
        screen = SCREEN_REGISTER;
        statusView = null;
        stopPolling();
        hideKeyboard();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(24), dp(28), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        root.addView(logo, lp(dp(96), dp(96)));

        TextView title = label("FlauGram", 30, p.text, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, 0);
        root.addView(title, lp(MATCH, WRAP));

        TextView sub = label("Придумайте юзернейм — по нему вас смогут найти и написать", 15, p.sub, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(24));
        root.addView(sub, lp(MATCH, WRAP));

        final EditText name = edit("юзернейм");
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        name.setFilters(new InputFilter[]{NAME_FILTER, new InputFilter.LengthFilter(20)});
        root.addView(name, lp(MATCH, WRAP));

        TextView hint = label("3–20 символов: латиница, цифры и _", 12, p.sub, false);
        hint.setPadding(dp(4), dp(6), 0, 0);
        root.addView(hint, lp(MATCH, WRAP));

        final TextView err = label(error == null ? "" : error, 14, p.danger, false);
        err.setGravity(Gravity.CENTER);
        err.setPadding(0, dp(10), 0, dp(10));
        root.addView(err, lp(MATCH, WRAP));

        final TextView go = button("Создать аккаунт");
        root.addView(go, lp(MATCH, WRAP));

        TextView login = label("Уже есть аккаунт? Войти по ключу", 14, p.accent, false);
        login.setGravity(Gravity.CENTER);
        login.setPadding(0, dp(18), 0, dp(6));
        login.setClickable(true);
        root.addView(login, lp(MATCH, WRAP));

        go.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.length() < 3) {
                err.setText("Минимум 3 символа");
                return;
            }
            doRegister(n, go, err);
        });
        login.setOnClickListener(v -> showLoginByKey());

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(p.bg);
        sv.addView(root, new FrameLayout.LayoutParams(MATCH, WRAP));
        setContentView(sv);
    }

    private void doRegister(final String name, final TextView btn, final TextView err) {
        btn.setEnabled(false);
        btn.setAlpha(0.5f);
        err.setText("");
        io.execute(() -> {
            final Api.Res r = Api.call("POST", "/register", null, Api.obj("username", name), 10000);
            runOnUiThread(() -> {
                btn.setEnabled(true);
                btn.setAlpha(1f);
                if (r.netFail) {
                    err.setText(netMsg());
                } else if (r.code == 200 && r.json != null && r.json.optString("token").length() > 0) {
                    saveAccount(r.json.optString("token"), r.json.optString("username", name));
                    showList();
                    startPolling();
                } else if (r.code == 409) {
                    err.setText("Этот юзернейм занят, придумайте другой");
                } else if (r.code == 400) {
                    err.setText("Недопустимый юзернейм (3–20 символов: латиница, цифры, _)");
                } else if (r.code == 429) {
                    err.setText("Слишком много попыток, подождите немного");
                } else {
                    err.setText("Ошибка сервера (" + r.code + ")");
                }
            });
        });
    }

    private void showLoginByKey() {
        final EditText key = edit("ключ входа");
        key.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Вход по ключу")
                .setMessage("Вставьте ключ из раздела «Мой аккаунт» на старом устройстве.")
                .setView(padded(key))
                .setPositiveButton("Войти", (d, w) -> loginWithKey(key.getText().toString().trim()))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void loginWithKey(final String key) {
        if (key.isEmpty()) return;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/me", key, null, 10000);
            runOnUiThread(() -> {
                if (r.code == 200 && r.json != null && r.json.optString("username").length() > 0) {
                    saveAccount(key, r.json.optString("username"));
                    showList();
                    startPolling();
                } else if (r.netFail) {
                    toast(netMsg());
                } else {
                    toast("Ключ не подходит");
                }
            });
        });
    }

    private void saveAccount(String tok, String name) {
        token = tok;
        me = name;
        prefs.edit().putString("token", tok).putString("me", name).remove("notif_after").apply();
        if (prefs.getBoolean("notify", true)) PollService.start(this);
    }

    private void forceLogout(String message) {
        token = null;
        me = null;
        prefs.edit().remove("token").remove("me").remove("notif_after").apply();
        PollService.stop(this);
        stopPolling();
        showRegister(message);
    }

    private boolean authFailed(Api.Res r) {
        if (r.code == 401 && token != null) {
            forceLogout("Аккаунт не найден на сервере. Создайте новый или войдите по ключу.");
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ список диалогов и поиск

    private void showList() {
        screen = SCREEN_LIST;
        chatWith = null;
        chatAdapter = null;
        chatList = null;
        searching = false;
        dialogsLoaded = false;
        hideKeyboard();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(p.bar);
        header.setPadding(dp(16), dp(8), dp(4), dp(8));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(label("FlauGram", 20, p.text, true));
        titles.addView(label("@" + me, 13, p.sub, false));
        header.addView(titles, lpw(0, WRAP, 1f));

        ImageButton menu = iconButton(android.R.drawable.ic_menu_more);
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu, lp(dp(48), dp(48)));
        root.addView(header, lp(MATCH, WRAP));

        statusView = banner();
        root.addView(statusView, lp(MATCH, WRAP));

        searchBox = edit("Поиск по юзернейму");
        searchBox.setSingleLine(true);
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchBox.setFilters(new InputFilter[]{NAME_FILTER, new InputFilter.LengthFilter(20)});
        LinearLayout.LayoutParams sp = lp(MATCH, WRAP);
        sp.setMargins(dp(12), dp(10), dp(12), dp(6));
        root.addView(searchBox, sp);

        FrameLayout frame = new FrameLayout(this);
        dialogsList = new ListView(this);
        dialogsList.setDivider(null);
        dialogsList.setDividerHeight(0);
        dialogsList.setCacheColorHint(Color.TRANSPARENT);
        dialogsList.setSelector(new ColorDrawable(0x22888888));
        rowAdapter = new RowAdapter();
        dialogsList.setAdapter(rowAdapter);
        frame.addView(dialogsList, new FrameLayout.LayoutParams(MATCH, MATCH));

        emptyView = label("Загрузка…", 15, p.sub, false);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(32), dp(32), dp(32), dp(32));
        frame.addView(emptyView, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER));
        dialogsList.setEmptyView(emptyView);
        root.addView(frame, lpw(MATCH, 0, 1f));

        dialogsList.setOnItemClickListener((parent, v, pos, id) -> {
            Row r = (Row) rowAdapter.getItem(pos);
            openChat(r.user);
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { onSearchChanged(e.toString().trim()); }
        });

        setContentView(root);
        refreshDialogs();
        if (!prefs.getBoolean("asked_notif", false)) {
            prefs.edit().putBoolean("asked_notif", true).apply();
            askNotifPermission();
        }
    }

    private void onSearchChanged(final String q) {
        if (pendingSearch != null) ui.removeCallbacks(pendingSearch);
        if (q.isEmpty()) {
            searching = false;
            emptyView.setText(dialogsLoaded ? EMPTY_DIALOGS : "Загрузка…");
            rowAdapter.setRows(dialogRows, false);
            return;
        }
        searching = true;
        pendingSearch = () -> doSearch(q);
        ui.postDelayed(pendingSearch, 250);
    }

    private void doSearch(final String q) {
        final String tok = token;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/search?q=" + Api.enc(q), tok, null, 10000);
            runOnUiThread(() -> {
                if (screen != SCREEN_LIST || !searching || searchBox == null) return;
                if (!searchBox.getText().toString().trim().equals(q)) return;
                if (authFailed(r)) return;
                if (r.netFail || r.code != 200 || r.json == null) {
                    setStatus(netMsg());
                    return;
                }
                setStatus(null);
                List<Row> rows = new ArrayList<>();
                JSONArray a = r.json.optJSONArray("users");
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        Row row = new Row();
                        row.user = a.optString(i);
                        if (!row.user.isEmpty()) rows.add(row);
                    }
                }
                emptyView.setText("Никого не найдено");
                rowAdapter.setRows(rows, true);
            });
        });
    }

    private void refreshDialogs() {
        final String tok = token;
        if (tok == null) return;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/dialogs", tok, null, 10000);
            runOnUiThread(() -> {
                if (!tok.equals(token)) return;
                if (authFailed(r)) return;
                if (r.netFail || r.code != 200 || r.json == null) {
                    setStatus(netMsg());
                    return;
                }
                setStatus(null);
                dialogRows.clear();
                JSONArray a = r.json.optJSONArray("dialogs");
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.optJSONObject(i);
                        if (o == null) continue;
                        Row row = new Row();
                        row.user = o.optString("user");
                        row.sub = o.optString("text");
                        row.ts = o.optLong("ts");
                        row.unread = o.optInt("unread");
                        row.mine = o.optBoolean("mine");
                        dialogRows.add(row);
                    }
                }
                dialogsLoaded = true;
                if (screen == SCREEN_LIST && !searching && rowAdapter != null) {
                    emptyView.setText(EMPTY_DIALOGS);
                    rowAdapter.setRows(dialogRows, false);
                }
            });
        });
    }

    private void showMenu() {
        final boolean notify = prefs.getBoolean("notify", true);
        final String[] items = {
                dark ? "Светлая тема" : "Чёрная тема",
                notify ? "Уведомления: включены" : "Уведомления: выключены",
                "Не засыпать в фоне",
                "Мой аккаунт",
                "Выйти"};
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            if (which == 0) {
                prefs.edit().putBoolean("dark", !dark).apply();
                recreate();
            } else if (which == 1) {
                setNotifications(!notify);
            } else if (which == 2) {
                showBatteryHelp();
            } else if (which == 3) {
                showAccount();
            } else {
                confirmLogout();
            }
        }).show();
    }

    private void setNotifications(boolean on) {
        prefs.edit().putBoolean("notify", on).apply();
        if (on) {
            askNotifPermission();
            PollService.start(this);
            toast("Уведомления включены");
        } else {
            PollService.stop(this);
            toast("Уведомления выключены");
        }
    }

    private void askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void showBatteryHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Уведомления в фоне")
                .setMessage("Чтобы сообщения приходили, даже когда телефон долго лежит, найдите FlauGram в списке "
                        + "и выберите «Не оптимизировать» (или «Без ограничений»).")
                .setPositiveButton("Открыть настройки", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception e) {
                        toast("Откройте настройки телефона → Батарея → FlauGram");
                    }
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private void showAccount() {
        new AlertDialog.Builder(this)
                .setTitle("@" + me)
                .setMessage("Ключ входа — это ваш пароль. Сохраните его: по нему можно войти на другом телефоне "
                        + "или после переустановки приложения. Никому его не показывайте.\n\n" + token)
                .setPositiveButton("Скопировать ключ", (d, w) -> copy(token))
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
                .setMessage("Выйти из аккаунта? Если вы не сохранили ключ входа, вернуться в него не получится.")
                .setPositiveButton("Выйти", (d, w) -> forceLogout(null))
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ------------------------------------------------------------------ чат

    private void openChat(final String peer) {
        screen = SCREEN_CHAT;
        chatWith = peer;
        replyingTo = null;
        hideKeyboard();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(PollService.tag(peer), PollService.MSG_ID);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(p.bar);
        header.setPadding(dp(4), dp(6), dp(12), dp(6));

        TextView back = label("←", 26, p.text, false);
        back.setPadding(dp(12), 0, dp(12), dp(2));
        back.setClickable(true);
        back.setOnClickListener(v -> showList());
        header.addView(back, lp(WRAP, WRAP));

        TextView av = avatar(peer);
        LinearLayout.LayoutParams ap = lp(dp(36), dp(36));
        ap.rightMargin = dp(10);
        header.addView(av, ap);

        header.addView(label("@" + peer, 18, p.text, true), lpw(0, WRAP, 1f));
        root.addView(header, lp(MATCH, WRAP));

        statusView = banner();
        root.addView(statusView, lp(MATCH, WRAP));

        chatAdapter = new ChatAdapter();
        chatList = new ListView(this);
        chatList.setDivider(null);
        chatList.setDividerHeight(0);
        chatList.setSelector(new ColorDrawable(Color.TRANSPARENT));
        chatList.setCacheColorHint(Color.TRANSPARENT);
        chatList.setClipToPadding(false);
        chatList.setPadding(0, dp(6), 0, dp(6));
        chatList.setAdapter(chatAdapter);
        root.addView(chatList, lpw(MATCH, 0, 1f));

        // панель «ответ на сообщение»
        replyBar = new LinearLayout(this);
        replyBar.setOrientation(LinearLayout.HORIZONTAL);
        replyBar.setGravity(Gravity.CENTER_VERTICAL);
        replyBar.setBackgroundColor(p.surface);
        replyBar.setPadding(dp(12), dp(6), dp(4), dp(6));
        View strip = new View(this);
        strip.setBackgroundColor(p.accent);
        LinearLayout.LayoutParams stp = lp(dp(3), dp(36));
        stp.rightMargin = dp(10);
        replyBar.addView(strip, stp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        replyTitle = label("", 13, p.accent, true);
        replyPreview = label("", 14, p.sub, false);
        replyPreview.setSingleLine(true);
        replyPreview.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(replyTitle);
        col.addView(replyPreview);
        replyBar.addView(col, lpw(0, WRAP, 1f));
        ImageButton cancel = iconButton(android.R.drawable.ic_menu_close_clear_cancel);
        cancel.setOnClickListener(v -> clearReply());
        replyBar.addView(cancel, lp(dp(44), dp(44)));
        replyBar.setVisibility(View.GONE);
        root.addView(replyBar, lp(MATCH, WRAP));

        // ввод сообщения
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(p.bar);
        bar.setPadding(dp(8), dp(6), dp(4), dp(6));
        input = edit("Сообщение");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMaxLines(5);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        bar.addView(input, lpw(0, WRAP, 1f));
        ImageButton send = iconButton(android.R.drawable.ic_menu_send);
        send.setColorFilter(p.accent);
        send.setOnClickListener(v -> sendMessage());
        bar.addView(send, lp(dp(48), dp(48)));
        root.addView(bar, lp(MATCH, WRAP));

        setContentView(root);
        loadHistory();
    }

    private void loadHistory() {
        final String peer = chatWith;
        final String tok = token;
        if (peer == null || tok == null) return;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/history?with=" + Api.enc(peer) + "&limit=100", tok, null, 10000);
            runOnUiThread(() -> {
                if (screen != SCREEN_CHAT || chatAdapter == null || !peer.equalsIgnoreCase(chatWith)) return;
                if (authFailed(r)) return;
                if (r.netFail || r.code != 200 || r.json == null) {
                    setStatus(netMsg());
                    return;
                }
                setStatus(null);
                chatAdapter.merge(parseMsgs(r.json.optJSONArray("messages")));
                scrollToEnd();
            });
        });
    }

    private void sendMessage() {
        if (input == null || chatWith == null) return;
        final String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        final String to = chatWith;
        final Msg rep = replyingTo;
        final String tok = token;
        input.setText("");
        clearReply();
        io.execute(() -> {
            final Object replyId = rep == null ? JSONObject.NULL : (Object) Long.valueOf(rep.id);
            final Api.Res r = Api.call("POST", "/send", tok, Api.obj("to", to, "text", t, "reply_to", replyId), 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                JSONObject mo = r.json == null ? null : r.json.optJSONObject("message");
                if (r.code == 200 && mo != null) {
                    Msg m = parseMsg(mo);
                    if (m != null && screen == SCREEN_CHAT && to.equalsIgnoreCase(chatWith)) addToChat(m);
                    return;
                }
                String err;
                if (r.netFail) err = netMsg();
                else if (r.code == 429) err = "Слишком часто, подождите секунду";
                else if (r.code == 404) err = "Пользователь не найден";
                else err = "Не отправилось (" + r.code + ")";
                toast(err);
                if (input != null && screen == SCREEN_CHAT && to.equalsIgnoreCase(chatWith)
                        && input.getText().length() == 0) {
                    input.setText(t);
                    input.setSelection(input.getText().length());
                }
            });
        });
    }

    private void addToChat(Msg m) {
        if (chatAdapter == null || chatList == null) return;
        boolean atBottom = chatAdapter.getCount() == 0
                || chatList.getLastVisiblePosition() >= chatAdapter.getCount() - 1;
        int before = chatAdapter.getCount();
        chatAdapter.merge(Collections.singletonList(m));
        if (chatAdapter.getCount() > before && (atBottom || m.from.equalsIgnoreCase(me))) scrollToEnd();
    }

    private void scrollToEnd() {
        if (chatList == null || chatAdapter == null) return;
        chatList.post(() -> {
            if (chatList != null && chatAdapter != null && chatAdapter.getCount() > 0) {
                chatList.setSelection(chatAdapter.getCount() - 1);
            }
        });
    }

    private void onMessageTap(final Msg m) {
        new AlertDialog.Builder(this)
                .setItems(new String[]{"Ответить", "Копировать текст"}, (d, which) -> {
                    if (which == 0) setReply(m); else copy(m.text);
                })
                .show();
    }

    private void setReply(Msg m) {
        replyingTo = m;
        if (replyBar == null) return;
        replyTitle.setText("Ответ для @" + m.from);
        replyPreview.setText(m.text);
        replyBar.setVisibility(View.VISIBLE);
        input.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, 0);
    }

    private void clearReply() {
        replyingTo = null;
        if (replyBar != null) replyBar.setVisibility(View.GONE);
    }

    private void jumpTo(long id) {
        if (chatAdapter == null || chatList == null) return;
        int idx = chatAdapter.indexOf(id);
        if (idx >= 0) chatList.setSelection(idx); else toast("Это сообщение выше в истории");
    }

    private void postRead(final String peer, final long upto) {
        final String tok = token;
        if (peer == null || tok == null) return;
        io.execute(() -> Api.call("POST", "/read", tok, Api.obj("with", peer, "upto", Long.valueOf(upto)), 10000));
    }

    // ------------------------------------------------------------------ состояние сети

    private boolean online() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    /** Текст для плашки. Адрес сервера пользователю не показываем. */
    private String netMsg() {
        return online() ? "Сервер недоступен, пробуем снова…" : "Нет подключения к интернету";
    }

    // ------------------------------------------------------------------ получение сообщений (long-poll)

    private void startPolling() {
        if (running || token == null) return;
        running = true;
        final int gen = ++generation;
        final String tok = token;
        new Thread(() -> pollLoop(gen, tok)).start();
    }

    private void stopPolling() {
        running = false;
        generation++;
    }

    private void pollLoop(final int gen, final String tok) {
        long after = -1;
        while (running && gen == generation) {
            Api.Res r = Api.call("GET", "/updates" + (after >= 0 ? "?after=" + after : ""), tok, null, 35000);
            if (!running || gen != generation) return;
            if (r.code == 401) {
                runOnUiThread(() -> {
                    if (gen == generation) forceLogout("Аккаунт не найден на сервере. Создайте новый или войдите по ключу.");
                });
                return;
            }
            if (r.netFail || r.code != 200 || r.json == null) {
                setStatus(netMsg());
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    return;
                }
                continue;
            }
            final boolean first = after < 0;
            final boolean reset = r.json.optBoolean("reset", false);
            final List<Msg> list = parseMsgs(r.json.optJSONArray("messages"));
            after = r.json.optLong("last", after);
            setStatus(null);
            runOnUiThread(() -> {
                if (gen != generation) return;
                // после первого ответа (или сброса базы) подтягиваем актуальное состояние экрана
                if (first || reset) refreshCurrent();
                onUpdates(list);
            });
        }
    }

    private void refreshCurrent() {
        if (screen == SCREEN_LIST) refreshDialogs();
        else if (screen == SCREEN_CHAT) loadHistory();
    }

    private void onUpdates(List<Msg> list) {
        if (list.isEmpty() || me == null) return;
        long maxIncoming = 0;
        Msg foreign = null;
        for (Msg m : list) {
            boolean mine = m.from.equalsIgnoreCase(me);
            String other = mine ? m.to : m.from;
            if (screen == SCREEN_CHAT && chatWith != null && other.equalsIgnoreCase(chatWith)) {
                addToChat(m);
                if (!mine) maxIncoming = Math.max(maxIncoming, m.id);
            } else if (!mine) {
                foreign = m;
            }
        }
        if (maxIncoming > 0) postRead(chatWith, maxIncoming);
        if (foreign != null) toast("@" + foreign.from + ": " + preview(foreign.text));
        if (screen == SCREEN_LIST) refreshDialogs();
    }

    // ------------------------------------------------------------------ разбор JSON

    private static Msg parseMsg(JSONObject o) {
        if (o == null) return null;
        Msg m = new Msg();
        m.id = o.optLong("id");
        m.from = o.optString("from");
        m.to = o.optString("to");
        m.text = o.optString("text");
        m.ts = o.optLong("ts");
        JSONObject r = o.optJSONObject("reply");
        if (r != null) {
            m.replyId = r.optLong("id");
            m.replyFrom = r.optString("from");
            m.replyText = r.optString("text");
        }
        return m.id > 0 ? m : null;
    }

    private static List<Msg> parseMsgs(JSONArray a) {
        List<Msg> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            Msg m = parseMsg(a.optJSONObject(i));
            if (m != null) out.add(m);
        }
        return out;
    }

    private static String preview(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 60 ? s.substring(0, 60) + "…" : s;
    }

    // ------------------------------------------------------------------ вспомогательные виды

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout.LayoutParams lpw(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String text) {
        TextView t = label(text, 16, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(13), dp(16), dp(13));
        t.setBackground(rounded(p.accent, 14));
        t.setClickable(true);
        return t;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(p.sub);
        e.setTextColor(p.text);
        e.setTextSize(16);
        e.setBackground(rounded(p.input, 14));
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        return e;
    }

    private ImageButton iconButton(int res) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setColorFilter(p.sub);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private TextView banner() {
        TextView t = label("", 13, Color.WHITE, false);
        t.setBackgroundColor(p.danger);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(5), dp(8), dp(5));
        t.setVisibility(View.GONE);
        return t;
    }

    private TextView avatar(String name) {
        TextView t = label(name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT), 18, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(circle(nameColor(name)));
        return t;
    }

    private static int nameColor(String name) {
        int hue = (name.toLowerCase(Locale.ROOT).hashCode() & 0x7fffffff) % 360;
        return Color.HSVToColor(new float[]{hue, 0.55f, 0.75f});
    }

    private View padded(View v) {
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(v);
        return f;
    }

    private void setStatus(final String text) {
        runOnUiThread(() -> {
            if (statusView == null) return;
            if (text == null) {
                statusView.setVisibility(View.GONE);
            } else {
                statusView.setText(text);
                statusView.setVisibility(View.VISIBLE);
            }
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("FlauGram", s));
            toast("Скопировано");
        }
    }

    private void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    // ------------------------------------------------------------------ адаптеры

    /** Список диалогов и результатов поиска. */
    private class RowAdapter extends BaseAdapter {
        private List<Row> rows = new ArrayList<>();
        private boolean search;
        private final SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final SimpleDateFormat df = new SimpleDateFormat("dd.MM", Locale.getDefault());

        void setRows(List<Row> r, boolean isSearch) {
            rows = new ArrayList<>(r);
            search = isSearch;
            notifyDataSetChanged();
        }

        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            RowHolder h;
            if (convert == null) {
                h = new RowHolder();
                convert = h.build();
                convert.setTag(h);
            } else {
                h = (RowHolder) convert.getTag();
            }
            h.bind(rows.get(pos));
            return convert;
        }

        private String when(long ts) {
            Date d = new Date(ts);
            return DateUtils.isToday(ts) ? tf.format(d) : df.format(d);
        }

        private class RowHolder {
            LinearLayout root;
            TextView avatar, name, sub, time, badge;

            View build() {
                root = new LinearLayout(MainActivity.this);
                root.setOrientation(LinearLayout.HORIZONTAL);
                root.setGravity(Gravity.CENTER_VERTICAL);
                root.setPadding(dp(14), dp(10), dp(14), dp(10));

                avatar = label("", 18, Color.WHITE, true);
                avatar.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams ap = lp(dp(46), dp(46));
                ap.rightMargin = dp(12);
                root.addView(avatar, ap);

                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                name = label("", 16, p.text, true);
                name.setSingleLine(true);
                sub = label("", 14, p.sub, false);
                sub.setSingleLine(true);
                sub.setEllipsize(TextUtils.TruncateAt.END);
                col.addView(name);
                col.addView(sub);
                root.addView(col, lpw(0, WRAP, 1f));

                LinearLayout right = new LinearLayout(MainActivity.this);
                right.setOrientation(LinearLayout.VERTICAL);
                right.setGravity(Gravity.END);
                time = label("", 12, p.sub, false);
                badge = label("", 12, Color.WHITE, true);
                badge.setGravity(Gravity.CENTER);
                badge.setMinWidth(dp(22));
                badge.setPadding(dp(6), dp(1), dp(6), dp(1));
                right.addView(time);
                LinearLayout.LayoutParams bp = lp(WRAP, WRAP);
                bp.topMargin = dp(4);
                right.addView(badge, bp);
                root.addView(right, lp(WRAP, WRAP));
                return root;
            }

            void bind(Row r) {
                avatar.setText(r.user.isEmpty() ? "?" : r.user.substring(0, 1).toUpperCase(Locale.ROOT));
                avatar.setBackground(circle(nameColor(r.user)));
                name.setText("@" + r.user);
                if (search) {
                    sub.setText("Написать сообщение");
                    time.setVisibility(View.GONE);
                    badge.setVisibility(View.GONE);
                    return;
                }
                sub.setText((r.mine ? "Вы: " : "") + r.sub.replace('\n', ' '));
                time.setVisibility(View.VISIBLE);
                time.setText(when(r.ts));
                time.setTextColor(r.unread > 0 ? p.accent : p.sub);
                if (r.unread > 0) {
                    badge.setVisibility(View.VISIBLE);
                    badge.setText(r.unread > 99 ? "99+" : String.valueOf(r.unread));
                    badge.setBackground(rounded(p.accent, 11));
                } else {
                    badge.setVisibility(View.GONE);
                }
            }
        }
    }

    /** Сообщения переписки. */
    private class ChatAdapter extends BaseAdapter {
        private final ArrayList<Msg> items = new ArrayList<>();
        private final HashSet<Long> ids = new HashSet<>();
        private final SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final int maxW = (int) (getResources().getDisplayMetrics().widthPixels * 0.78f);

        void merge(List<Msg> more) {
            boolean changed = false;
            for (Msg m : more) {
                if (ids.add(m.id)) {
                    items.add(m);
                    changed = true;
                }
            }
            if (changed) {
                Collections.sort(items, (a, b) -> Long.compare(a.id, b.id));
                notifyDataSetChanged();
            }
        }

        int indexOf(long id) {
            for (int i = 0; i < items.size(); i++) if (items.get(i).id == id) return i;
            return -1;
        }

        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return items.get(i).id; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Holder h;
            if (convert == null) {
                h = new Holder();
                convert = h.build();
                convert.setTag(h);
            } else {
                h = (Holder) convert.getTag();
            }
            h.bind(items.get(pos));
            return convert;
        }

        private class Holder {
            LinearLayout row, bubble, quote;
            View strip;
            TextView qFrom, qText, text, time;

            View build() {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(8), dp(3), dp(8), dp(3));

                bubble = new LinearLayout(MainActivity.this);
                bubble.setOrientation(LinearLayout.VERTICAL);
                bubble.setPadding(dp(11), dp(7), dp(11), dp(6));

                quote = new LinearLayout(MainActivity.this);
                quote.setOrientation(LinearLayout.HORIZONTAL);
                quote.setPadding(dp(8), dp(4), dp(8), dp(4));
                strip = new View(MainActivity.this);
                LinearLayout.LayoutParams stp = lp(dp(3), MATCH);
                stp.rightMargin = dp(8);
                quote.addView(strip, stp);
                LinearLayout qcol = new LinearLayout(MainActivity.this);
                qcol.setOrientation(LinearLayout.VERTICAL);
                qFrom = label("", 12, p.accent, true);
                qText = label("", 13, p.sub, false);
                qText.setMaxLines(2);
                qText.setEllipsize(TextUtils.TruncateAt.END);
                qText.setMaxWidth(maxW - dp(40));
                qcol.addView(qFrom);
                qcol.addView(qText);
                quote.addView(qcol);
                LinearLayout.LayoutParams qp = lp(WRAP, WRAP);
                qp.bottomMargin = dp(5);
                bubble.addView(quote, qp);

                text = label("", 16, p.text, false);
                text.setMaxWidth(maxW);
                bubble.addView(text, lp(WRAP, WRAP));

                time = label("", 11, p.sub, false);
                LinearLayout.LayoutParams tp = lp(WRAP, WRAP);
                tp.gravity = Gravity.END;
                bubble.addView(time, tp);

                row.addView(bubble, lp(WRAP, WRAP));
                return row;
            }

            void bind(final Msg m) {
                boolean mine = m.from.equalsIgnoreCase(me);
                row.setGravity(mine ? Gravity.END : Gravity.START);
                bubble.setBackground(rounded(mine ? p.outBubble : p.inBubble, 16));
                text.setTextColor(mine ? Color.WHITE : p.text);
                text.setText(m.text);
                time.setTextColor(mine ? 0xB3FFFFFF : p.sub);
                time.setText(tf.format(new Date(m.ts)));

                if (m.replyId > 0) {
                    quote.setVisibility(View.VISIBLE);
                    quote.setBackground(rounded(mine ? 0x33FFFFFF : 0x22888888, 8));
                    strip.setBackgroundColor(mine ? 0xCCFFFFFF : p.accent);
                    qFrom.setText("@" + m.replyFrom);
                    qFrom.setTextColor(mine ? Color.WHITE : p.accent);
                    qText.setText(m.replyText);
                    qText.setTextColor(mine ? 0xCCFFFFFF : p.sub);
                    quote.setOnClickListener(v -> jumpTo(m.replyId));
                } else {
                    quote.setVisibility(View.GONE);
                    quote.setOnClickListener(null);
                }
                bubble.setOnClickListener(v -> onMessageTap(m));
                bubble.setOnLongClickListener(v -> {
                    onMessageTap(m);
                    return true;
                });
            }
        }
    }
}
