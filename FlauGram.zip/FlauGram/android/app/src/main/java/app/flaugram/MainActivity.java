package app.flaugram;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int SCREEN_REGISTER = 0, SCREEN_LIST = 1, SCREEN_CHAT = 2, SCREEN_PROFILE = 3;
    private static final int REQ_AVATAR = 11, REQ_PHOTO = 12, REQ_CHAT_AVATAR = 13;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final long UPDATE_CHECK_EVERY_MS = 6L * 60 * 60 * 1000;

    /** Пропускает только латиницу, цифры и подчёркивание (для юзернейма). */
    private static final InputFilter NAME_FILTER = (src, start, end, dest, ds, de) -> {
        StringBuilder sb = null;
        for (int i = start; i < end; i++) {
            char ch = src.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_';
            if (ok) {
                if (sb != null) sb.append(ch);
            } else if (sb == null) {
                sb = new StringBuilder();
                sb.append(src, start, i);
            }
        }
        return sb == null ? null : sb.toString();
    };

    static class Msg {
        long id;
        String from = "", fromName = "", to = "", text = "", photo = "";
        long ts, fromAvatar, chat;
        String chatTitle = "";
        boolean fromVerified;
        int w, h;
        long replyId;
        String replyFrom = "", replyName = "", replyText = "";
        boolean replyPhoto;
    }

    /** Человек в списке диалогов, результатах поиска или в шапке чата. */
    static class Row {
        String user = "", name = "", bio = "", sub = "", kind = "user";
        long avatar, ts, chatId;
        int unread, members;
        boolean mine, verified, member = true, owner;

        boolean isChat() {
            return chatId > 0;
        }

        String title() {
            return name.isEmpty() ? user : name;
        }
    }

    // общее состояние
    private SharedPreferences prefs;
    private Palette p;
    private boolean dark;
    private String token, me, meName, meBio;
    private long meAvatar;
    private int screen = SCREEN_REGISTER;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView statusView;
    private Updater.Info pendingUpdate;

    // экран списка
    private ListView dialogsList;
    private RowAdapter rowAdapter;
    private TextView emptyView, updateView;
    private EditText searchBox;
    private ImageView headerAvatar;
    private final List<Row> dialogRows = new ArrayList<>();
    private boolean searching = false;
    private boolean dialogsLoaded = false;
    private Runnable pendingSearch;

    // экран чата
    private String chatWith;
    private Row chatPeer;
    private long chatId;
    private LinearLayout inputBar;
    private TextView joinBar, readOnlyBar;
    private ListView chatList;
    private ChatAdapter chatAdapter;
    private EditText input;
    private Msg replyingTo;
    private LinearLayout replyBar;
    private TextView replyTitle, replyPreview, chatTitle, chatSub;
    private ImageView chatAvatar;

    // экран профиля
    private ImageView profileAvatar;

    /** Открыто ли приложение сейчас. Пока открыто, уведомления не показываем. */
    static volatile boolean visible = false;

    // опрос сервера
    private volatile boolean running = false;
    private volatile int generation = 0;

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    @Override
    protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("flaugram", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", true);
        setTheme(dark ? android.R.style.Theme_DeviceDefault_NoActionBar
                : android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        super.onCreate(b);
        p = dark ? Palette.dark() : Palette.light();
        token = prefs.getString("token", null);
        me = prefs.getString("me", null);
        meName = prefs.getString("me_name", me);
        meBio = prefs.getString("me_bio", "");
        meAvatar = prefs.getLong("me_avatar", 0);
        applyBars();
        if (token == null || me == null) showRegister(null); else showList();
        handleIntent(getIntent());
    }

    @Override
    protected void onStart() {
        super.onStart();
        visible = true;
        startPolling();
        if (token != null && prefs.getBoolean("notify", true)) PollService.start(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        visible = false;
        stopPolling();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** Нажатие на уведомление открывает переписку с отправителем. */
    private void handleIntent(Intent i) {
        if (i == null || token == null) return;
        long cid = i.getLongExtra("chat_id", 0);
        if (cid > 0) {
            i.removeExtra("chat_id");
            Row r = new Row();
            r.chatId = cid;
            r.kind = "group";
            openChat(r);
            return;
        }
        String chat = i.getStringExtra("chat");
        if (chat == null || chat.isEmpty()) return;
        i.removeExtra("chat");
        Row r = new Row();
        r.user = chat;
        openChat(r);
    }

    @Override
    public void onBackPressed() {
        if (screen == SCREEN_CHAT || screen == SCREEN_PROFILE) {
            showList();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_AVATAR) uploadAvatar(data.getData());
        else if (req == REQ_PHOTO) preparePhoto(data.getData());
        else if (req == REQ_CHAT_AVATAR) uploadChatAvatar(data.getData());
    }

    private void applyBars() {
        Window w = getWindow();
        w.setStatusBarColor(p.bar);
        w.setNavigationBarColor(p.bg);
        View d = w.getDecorView();
        int f = d.getSystemUiVisibility();
        if (Build.VERSION.SDK_INT >= 23) {
            f = p.dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            f = p.dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        d.setSystemUiVisibility(f);
    }

    private String t(int id, Object... args) {
        return getString(id, args);
    }

    // ------------------------------------------------------------------ регистрация

    private void showRegister(String error) {
        screen = SCREEN_REGISTER;
        statusView = null;
        stopPolling();
        hideKeyboard();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(24), dp(28), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        root.addView(logo, lp(dp(96), dp(96)));

        TextView title = label(t(R.string.app_name), 30, p.text, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, 0);
        root.addView(title, lp(MATCH, WRAP));

        TextView sub = label(t(R.string.reg_subtitle), 15, p.sub, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(24));
        root.addView(sub, lp(MATCH, WRAP));

        final EditText display = edit(t(R.string.reg_display_hint));
        display.setSingleLine(true);
        display.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        display.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        root.addView(display, lp(MATCH, WRAP));

        final EditText name = edit(t(R.string.reg_username_hint));
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        name.setFilters(new InputFilter[]{NAME_FILTER, new InputFilter.LengthFilter(20)});
        LinearLayout.LayoutParams np = lp(MATCH, WRAP);
        np.topMargin = dp(10);
        root.addView(name, np);

        TextView hint = label(t(R.string.reg_username_rules), 12, p.sub, false);
        hint.setPadding(dp(4), dp(6), 0, 0);
        root.addView(hint, lp(MATCH, WRAP));

        final TextView err = label(error == null ? "" : error, 14, p.danger, false);
        err.setGravity(Gravity.CENTER);
        err.setPadding(0, dp(10), 0, dp(10));
        root.addView(err, lp(MATCH, WRAP));

        final TextView go = button(t(R.string.reg_create));
        root.addView(go, lp(MATCH, WRAP));

        TextView login = label(t(R.string.reg_login_by_key), 14, p.accent, false);
        login.setGravity(Gravity.CENTER);
        login.setPadding(0, dp(18), 0, dp(6));
        login.setClickable(true);
        root.addView(login, lp(MATCH, WRAP));

        go.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.length() < 3) {
                err.setText(t(R.string.err_username_short));
                return;
            }
            doRegister(n, display.getText().toString().trim(), go, err);
        });
        login.setOnClickListener(v -> showLoginByKey());

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(p.bg);
        sv.addView(root, new FrameLayout.LayoutParams(MATCH, WRAP));
        setContentView(sv);
    }

    private void doRegister(final String name, final String display, final TextView btn, final TextView err) {
        btn.setEnabled(false);
        btn.setAlpha(0.5f);
        err.setText("");
        io.execute(() -> {
            final Api.Res r = Api.call("POST", "/register", null,
                    Api.obj("username", name, "display_name", display), 10000);
            runOnUiThread(() -> {
                btn.setEnabled(true);
                btn.setAlpha(1f);
                if (r.netFail) {
                    err.setText(netMsg());
                } else if (r.code == 200 && r.json != null && r.json.optString("token").length() > 0) {
                    saveAccount(r.json.optString("token"), r.json.optString("username", name),
                            r.json.optString("display_name", name), "", 0);
                    showList();
                    startPolling();
                } else if (r.code == 409) {
                    err.setText(t(R.string.err_username_taken));
                } else if (r.code == 400) {
                    err.setText(t(R.string.err_username_invalid));
                } else if (r.code == 429) {
                    err.setText(t(R.string.err_too_many));
                } else {
                    err.setText(t(R.string.err_server, r.code));
                }
            });
        });
    }

    private void showLoginByKey() {
        final EditText key = edit(t(R.string.login_key_hint));
        key.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle(t(R.string.login_title))
                .setMessage(t(R.string.login_message))
                .setView(padded(key))
                .setPositiveButton(t(R.string.login_go), (d, w) -> loginWithKey(key.getText().toString().trim()))
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    private void loginWithKey(final String key) {
        if (key.isEmpty()) return;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/me", key, null, 10000);
            runOnUiThread(() -> {
                if (r.code == 200 && r.json != null && r.json.optString("username").length() > 0) {
                    saveAccount(key, r.json.optString("username"), r.json.optString("display_name"),
                            r.json.optString("bio"), r.json.optLong("avatar"));
                    showList();
                    startPolling();
                } else if (r.netFail) {
                    toast(netMsg());
                } else {
                    toast(t(R.string.err_bad_key));
                }
            });
        });
    }

    private void saveAccount(String tok, String name, String display, String bio, long avatar) {
        token = tok;
        me = name;
        meName = display.isEmpty() ? name : display;
        meBio = bio;
        meAvatar = avatar;
        prefs.edit().putString("token", tok).putString("me", name).putString("me_name", meName)
                .putString("me_bio", bio).putLong("me_avatar", avatar).remove("notif_after").apply();
        Images.forget();
        if (prefs.getBoolean("notify", true)) PollService.start(this);
    }

    private void saveMe(String display, String bio, long avatar) {
        meName = display.isEmpty() ? me : display;
        meBio = bio;
        meAvatar = avatar;
        prefs.edit().putString("me_name", meName).putString("me_bio", bio).putLong("me_avatar", avatar).apply();
    }

    private void forceLogout(String message) {
        token = null;
        me = null;
        prefs.edit().remove("token").remove("me").remove("me_name").remove("me_bio").remove("me_avatar")
                .remove("notif_after").apply();
        PollService.stop(this);
        stopPolling();
        Images.forget();
        showRegister(message);
    }

    private boolean authFailed(Api.Res r) {
        if (r.code == 401 && token != null) {
            forceLogout(t(R.string.err_account_missing));
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ список диалогов и поиск

    private void showList() {
        screen = SCREEN_LIST;
        chatWith = null;
        chatPeer = null;
        chatId = 0;
        chatAdapter = null;
        chatList = null;
        searching = false;
        dialogsLoaded = false;
        hideKeyboard();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(p.bar);
        header.setPadding(dp(14), dp(8), dp(4), dp(8));

        headerAvatar = new ImageView(this);
        headerAvatar.setOnClickListener(v -> showProfile());
        LinearLayout.LayoutParams hp = lp(dp(40), dp(40));
        hp.rightMargin = dp(12);
        header.addView(headerAvatar, hp);
        bindMeAvatar(headerAvatar, 40);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(label(t(R.string.app_name), 20, p.text, true));
        TextView who = label(meName + "  @" + me, 13, p.sub, false);
        who.setSingleLine(true);
        who.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(who);
        header.addView(titles, lpw(0, WRAP, 1f));

        ImageButton menu = iconButton(android.R.drawable.ic_menu_more);
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu, lp(dp(48), dp(48)));
        root.addView(header, lp(MATCH, WRAP));

        statusView = banner();
        root.addView(statusView, lp(MATCH, WRAP));

        updateView = label("", 14, Color.WHITE, true);
        updateView.setBackgroundColor(p.accent);
        updateView.setGravity(Gravity.CENTER);
        updateView.setPadding(dp(10), dp(9), dp(10), dp(9));
        updateView.setVisibility(View.GONE);
        updateView.setOnClickListener(v -> openDownload(pendingUpdate));
        root.addView(updateView, lp(MATCH, WRAP));

        searchBox = edit(t(R.string.search_hint));
        searchBox.setSingleLine(true);
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchBox.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        LinearLayout.LayoutParams sp = lp(MATCH, WRAP);
        sp.setMargins(dp(12), dp(10), dp(12), dp(6));
        root.addView(searchBox, sp);

        FrameLayout frame = new FrameLayout(this);
        dialogsList = new ListView(this);
        dialogsList.setDivider(null);
        dialogsList.setDividerHeight(0);
        dialogsList.setCacheColorHint(Color.TRANSPARENT);
        dialogsList.setSelector(new ColorDrawable(0x22888888));
        rowAdapter = new RowAdapter();
        dialogsList.setAdapter(rowAdapter);
        frame.addView(dialogsList, new FrameLayout.LayoutParams(MATCH, MATCH));

        emptyView = label(t(R.string.loading), 15, p.sub, false);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(32), dp(32), dp(32), dp(32));
        frame.addView(emptyView, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER));
        dialogsList.setEmptyView(emptyView);
        root.addView(frame, lpw(MATCH, 0, 1f));

        dialogsList.setOnItemClickListener((parent, v, pos, id) -> openChat((Row) rowAdapter.getItem(pos)));

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { onSearchChanged(e.toString().trim()); }
        });

        setContentView(root);
        showPendingUpdate();
        refreshDialogs();
        refreshMe();
        autoCheckUpdate();
        if (!prefs.getBoolean("asked_notif", false)) {
            prefs.edit().putBoolean("asked_notif", true).apply();
            askNotifPermission();
        }
    }

    private void bindMeAvatar(ImageView iv, int sizeDp) {
        Images.avatar(iv, me, meName, meAvatar, dp(sizeDp), token);
    }

    private void onSearchChanged(final String q) {
        if (pendingSearch != null) ui.removeCallbacks(pendingSearch);
        if (q.isEmpty()) {
            searching = false;
            emptyView.setText(dialogsLoaded ? t(R.string.empty_dialogs) : t(R.string.loading));
            rowAdapter.setRows(dialogRows, false);
            return;
        }
        searching = true;
        pendingSearch = () -> doSearch(q);
        ui.postDelayed(pendingSearch, 250);
    }

    private void doSearch(final String q) {
        final String tok = token;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/search?q=" + Api.enc(q), tok, null, 10000);
            runOnUiThread(() -> {
                if (screen != SCREEN_LIST || !searching || searchBox == null) return;
                if (!searchBox.getText().toString().trim().equals(q)) return;
                if (authFailed(r)) return;
                if (r.netFail || r.code != 200 || r.json == null) {
                    setStatus(netMsg());
                    return;
                }
                setStatus(null);
                List<Row> rows = new ArrayList<>();
                JSONArray a = r.json.optJSONArray("users");
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.optJSONObject(i);
                        Row row = parseUser(o);
                        if (row != null) {
                            row.sub = "@" + row.user + (row.bio.isEmpty() ? "" : "  ·  " + row.bio.replace('\n', ' '));
                            rows.add(row);
                        }
                    }
                }
                JSONArray ca = r.json.optJSONArray("chats");
                if (ca != null) {
                    for (int i = 0; i < ca.length(); i++) {
                        Row row = parseChat(ca.optJSONObject(i));
                        if (row != null) {
                            row.sub = kindLabel(row.kind) + "  ·  " + membersText(row);
                            rows.add(row);
                        }
                    }
                }
                emptyView.setText(t(R.string.search_none));
                rowAdapter.setRows(rows, true);
            });
        });
    }

    private void refreshDialogs() {
        final String tok = token;
        if (tok == null) return;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/dialogs", tok, null, 10000);
            runOnUiThread(() -> {
                if (!tok.equals(token)) return;
                if (authFailed(r)) return;
                if (r.netFail || r.code != 200 || r.json == null) {
                    setStatus(netMsg());
                    return;
                }
                setStatus(null);
                dialogRows.clear();
                JSONArray a = r.json.optJSONArray("dialogs");
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.optJSONObject(i);
                        if (o == null) continue;
                        Row row = new Row();
                        row.user = o.optString("user");
                        row.name = o.optString("display_name");
                        row.bio = o.optString("bio");
                        row.avatar = o.optLong("avatar");
                        row.chatId = o.optLong("chat");
                        row.kind = o.optString("kind", "user");
                        row.verified = o.optBoolean("verified");
                        String text = o.optString("text").replace('\n', ' ');
                        if (o.optBoolean("photo")) {
                            text = text.isEmpty() ? t(R.string.msg_photo) : t(R.string.msg_photo) + ": " + text;
                        }
                        String who = o.optString("sender");
                        if (row.isChat() && "group".equals(row.kind) && !who.isEmpty() && !text.isEmpty() && !o.optBoolean("mine")) {
                            text = who + ": " + text;
                        }
                        row.sub = text;
                        row.ts = o.optLong("ts");
                        row.unread = o.optInt("unread");
                        row.mine = o.optBoolean("mine");
                        dialogRows.add(row);
                    }
                }
                dialogsLoaded = true;
                if (screen == SCREEN_LIST && !searching && rowAdapter != null) {
                    emptyView.setText(t(R.string.empty_dialogs));
                    rowAdapter.setRows(dialogRows, false);
                }
            });
        });
    }

    /** Подтягивает мой профиль с сервера (имя, описание, аватарка могли поменяться с другого устройства). */
    private void refreshMe() {
        final String tok = token;
        if (tok == null) return;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/me", tok, null, 10000);
            runOnUiThread(() -> {
                if (!tok.equals(token) || r.code != 200 || r.json == null) return;
                saveMe(r.json.optString("display_name"), r.json.optString("bio"), r.json.optLong("avatar"));
                if (screen == SCREEN_LIST && headerAvatar != null) bindMeAvatar(headerAvatar, 40);
            });
        });
    }

    // ------------------------------------------------------------------ меню

    private void showMenu() {
        final boolean notify = prefs.getBoolean("notify", true);
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        labels.add(t(R.string.menu_profile));
        actions.add(this::showProfile);
        labels.add(t(R.string.menu_new_group));
        actions.add(() -> showCreateChat("group"));
        labels.add(t(R.string.menu_new_channel));
        actions.add(() -> showCreateChat("channel"));
        labels.add(dark ? t(R.string.menu_theme_light) : t(R.string.menu_theme_dark));
        actions.add(() -> {
            prefs.edit().putBoolean("dark", !dark).apply();
            recreate();
        });
        labels.add(notify ? t(R.string.menu_notif_on) : t(R.string.menu_notif_off));
        actions.add(() -> setNotifications(!notify));
        labels.add(t(R.string.menu_battery));
        actions.add(this::showBatteryHelp);
        if (Build.VERSION.SDK_INT >= 26) {
            labels.add(t(R.string.menu_hide_notif));
            actions.add(this::showHideNotifHelp);
        }
        labels.add(t(R.string.menu_language));
        actions.add(this::showLanguage);
        if (Updater.enabled()) {
            labels.add(t(R.string.menu_check_update));
            actions.add(this::checkUpdateManually);
        }
        labels.add(t(R.string.menu_account));
        actions.add(this::showAccount);
        labels.add(t(R.string.menu_logout));
        actions.add(this::confirmLogout);
        new AlertDialog.Builder(this)
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .show();
    }

    private void setNotifications(boolean on) {
        prefs.edit().putBoolean("notify", on).apply();
        if (on) {
            askNotifPermission();
            PollService.start(this);
            toast(t(R.string.notif_enabled));
        } else {
            PollService.stop(this);
            toast(t(R.string.notif_disabled));
        }
    }

    private void askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void showBatteryHelp() {
        new AlertDialog.Builder(this)
                .setTitle(t(R.string.battery_title))
                .setMessage(t(R.string.battery_message))
                .setPositiveButton(t(R.string.open_settings), (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception e) {
                        toast(t(R.string.battery_fallback));
                    }
                })
                .setNegativeButton(t(R.string.close), null)
                .show();
    }

    private void showHideNotifHelp() {
        new AlertDialog.Builder(this)
                .setTitle(t(R.string.hide_title))
                .setMessage(t(R.string.hide_message))
                .setPositiveButton(t(R.string.open_settings), (d, w) -> {
                    try {
                        Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                        i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        i.putExtra(Settings.EXTRA_CHANNEL_ID, PollService.CH_BG);
                        startActivity(i);
                    } catch (Exception e) {
                        toast(t(R.string.battery_fallback));
                    }
                })
                .setNegativeButton(t(R.string.close), null)
                .show();
    }

    private void showLanguage() {
        String cur = Lang.get(this);
        int checked = "ru".equals(cur) ? 1 : "en".equals(cur) ? 2 : 0;
        final String[] codes = {"auto", "ru", "en"};
        final String[] names = {t(R.string.lang_auto), "Русский", "English"};
        new AlertDialog.Builder(this)
                .setTitle(t(R.string.menu_language))
                .setSingleChoiceItems(names, checked, (d, which) -> {
                    d.dismiss();
                    prefs.edit().putString("lang", codes[which]).apply();
                    recreate();
                })
                .show();
    }

    private void showAccount() {
        new AlertDialog.Builder(this)
                .setTitle(meName + "  @" + me)
                .setMessage(t(R.string.account_message) + "\n\n" + token)
                .setPositiveButton(t(R.string.copy_key), (d, w) -> copy(token))
                .setNegativeButton(t(R.string.close), null)
                .show();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
                .setMessage(t(R.string.logout_confirm))
                .setPositiveButton(t(R.string.logout), (d, w) -> forceLogout(null))
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    // ------------------------------------------------------------------ обновление приложения

    private void autoCheckUpdate() {
        if (!Updater.enabled()) return;
        long last = prefs.getLong("upd_checked", 0);
        if (System.currentTimeMillis() - last < UPDATE_CHECK_EVERY_MS) return;
        io.execute(() -> {
            final Updater.Info i = Updater.check();
            if (i == null) return;
            prefs.edit().putLong("upd_checked", System.currentTimeMillis()).apply();
            runOnUiThread(() -> {
                pendingUpdate = Updater.isNewer(i) ? i : null;
                showPendingUpdate();
            });
        });
    }

    private void showPendingUpdate() {
        if (updateView == null || screen != SCREEN_LIST) return;
        if (pendingUpdate != null && Updater.isNewer(pendingUpdate)) {
            updateView.setText(t(R.string.update_banner, pendingUpdate.name));
            updateView.setVisibility(View.VISIBLE);
        } else {
            updateView.setVisibility(View.GONE);
        }
    }

    private void checkUpdateManually() {
        toast(t(R.string.update_checking));
        io.execute(() -> {
            final Updater.Info i = Updater.check();
            runOnUiThread(() -> {
                if (i == null) {
                    toast(netMsg());
                } else if (Updater.isNewer(i)) {
                    pendingUpdate = i;
                    showPendingUpdate();
                    new AlertDialog.Builder(this)
                            .setTitle(t(R.string.update_available, i.name))
                            .setMessage(t(R.string.update_howto))
                            .setPositiveButton(t(R.string.update_download), (d, w) -> openDownload(i))
                            .setNegativeButton(t(R.string.cancel), null)
                            .show();
                } else {
                    pendingUpdate = null;
                    showPendingUpdate();
                    toast(t(R.string.update_latest));
                }
            });
        });
    }

    private void openDownload(Updater.Info i) {
        if (i == null || i.url.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(i.url)));
        } catch (Exception e) {
            toast(t(R.string.err_no_browser));
        }
    }

    // ------------------------------------------------------------------ мой профиль

    private void pickImage(int req) {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, t(R.string.pick_image)), req);
        } catch (Exception e) {
            toast(t(R.string.err_no_gallery));
        }
    }

    private void showProfile() {
        screen = SCREEN_PROFILE;
        statusView = null;
        hideKeyboard();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(p.bar);
        header.setPadding(dp(4), dp(10), dp(12), dp(10));
        TextView back = label("←", 26, p.text, false);
        back.setPadding(dp(12), 0, dp(12), dp(2));
        back.setClickable(true);
        back.setOnClickListener(v -> showList());
        header.addView(back, lp(WRAP, WRAP));
        header.addView(label(t(R.string.menu_profile), 18, p.text, true), lpw(0, WRAP, 1f));
        root.addView(header, lp(MATCH, WRAP));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(20), dp(20), dp(20), dp(20));

        profileAvatar = new ImageView(this);
        profileAvatar.setOnClickListener(v -> pickImage(REQ_AVATAR));
        body.addView(profileAvatar, lp(dp(112), dp(112)));
        bindMeAvatar(profileAvatar, 112);

        LinearLayout links = new LinearLayout(this);
        links.setOrientation(LinearLayout.HORIZONTAL);
        links.setGravity(Gravity.CENTER);
        links.setPadding(0, dp(10), 0, dp(14));
        TextView change = label(t(R.string.profile_change_photo), 14, p.accent, false);
        change.setPadding(dp(10), dp(6), dp(10), dp(6));
        change.setOnClickListener(v -> pickImage(REQ_AVATAR));
        links.addView(change);
        TextView remove = label(t(R.string.profile_remove_photo), 14, p.danger, false);
        remove.setPadding(dp(10), dp(6), dp(10), dp(6));
        remove.setOnClickListener(v -> removeAvatar());
        links.addView(remove);
        body.addView(links, lp(WRAP, WRAP));

        TextView un = label("@" + me, 15, p.sub, false);
        un.setGravity(Gravity.CENTER);
        un.setPadding(0, 0, 0, dp(14));
        body.addView(un, lp(MATCH, WRAP));

        TextView l1 = label(t(R.string.profile_display_name), 12, p.sub, false);
        l1.setPadding(dp(4), 0, 0, dp(4));
        body.addView(l1, lp(MATCH, WRAP));
        final EditText nameEd = edit(t(R.string.reg_display_hint));
        nameEd.setSingleLine(true);
        nameEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        nameEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        nameEd.setText(meName);
        body.addView(nameEd, lp(MATCH, WRAP));

        TextView l2 = label(t(R.string.profile_bio), 12, p.sub, false);
        l2.setPadding(dp(4), dp(14), 0, dp(4));
        body.addView(l2, lp(MATCH, WRAP));
        final EditText bioEd = edit(t(R.string.profile_bio_hint));
        bioEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        bioEd.setMinLines(3);
        bioEd.setGravity(Gravity.TOP);
        bioEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        bioEd.setText(meBio);
        body.addView(bioEd, lp(MATCH, WRAP));

        TextView hint = label(t(R.string.profile_hint), 12, p.sub, false);
        hint.setPadding(dp(4), dp(8), 0, dp(16));
        body.addView(hint, lp(MATCH, WRAP));

        TextView save = button(t(R.string.save));
        save.setOnClickListener(v -> saveProfile(nameEd.getText().toString().trim(), bioEd.getText().toString().trim(), save));
        body.addView(save, lp(MATCH, WRAP));

        ScrollView sv = new ScrollView(this);
        sv.addView(body, new FrameLayout.LayoutParams(MATCH, WRAP));
        root.addView(sv, lpw(MATCH, 0, 1f));
        setContentView(root);
    }

    private void saveProfile(final String name, final String bio, final TextView btn) {
        final String tok = token;
        btn.setEnabled(false);
        btn.setAlpha(0.5f);
        io.execute(() -> {
            final Api.Res r = Api.call("POST", "/profile", tok, Api.obj("display_name", name, "bio", bio), 10000);
            runOnUiThread(() -> {
                btn.setEnabled(true);
                btn.setAlpha(1f);
                if (authFailed(r)) return;
                if (r.code == 200 && r.json != null) {
                    saveMe(r.json.optString("display_name", name), r.json.optString("bio", bio), meAvatar);
                    toast(t(R.string.profile_saved));
                    if (screen == SCREEN_PROFILE) showList();
                } else {
                    toast(r.netFail ? netMsg() : t(R.string.err_server, r.code));
                }
            });
        });
    }

    private void uploadAvatar(final Uri uri) {
        final String tok = token;
        toast(t(R.string.preparing));
        io.execute(() -> {
            final Images.Encoded e = Images.encode(this, uri, 512, true, 800 * 1024);
            if (e == null) {
                runOnUiThread(() -> toast(t(R.string.err_bad_image)));
                return;
            }
            final Api.Res r = Api.postBytes("/avatar", tok, e.data, 30000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                if (r.code == 200 && r.json != null) {
                    saveMe(meName, meBio, r.json.optLong("avatar"));
                    Images.forget();
                    if (screen == SCREEN_PROFILE && profileAvatar != null) bindMeAvatar(profileAvatar, 112);
                    toast(t(R.string.profile_saved));
                } else {
                    toast(r.netFail ? netMsg() : t(R.string.err_server, r.code));
                }
            });
        });
    }

    private void removeAvatar() {
        final String tok = token;
        io.execute(() -> {
            final Api.Res r = Api.call("POST", "/avatar/remove", tok, new JSONObject(), 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                if (r.code == 200) {
                    saveMe(meName, meBio, 0);
                    Images.forget();
                    if (screen == SCREEN_PROFILE && profileAvatar != null) bindMeAvatar(profileAvatar, 112);
                } else {
                    toast(r.netFail ? netMsg() : t(R.string.err_server, r.code));
                }
            });
        });
    }

    /** Карточка другого человека: аватарка, имя, юзернейм и описание. */
    private void showUserCard(Row r) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24), dp(20), dp(24), dp(8));
        ImageView av = new ImageView(this);
        box.addView(av, lp(dp(96), dp(96)));
        Images.avatar(av, r.user, r.title(), r.avatar, dp(96), token);
        TextView n = label("", 20, p.text, true);
        n.setText(badge(r.title(), r.verified, r.user));
        n.setMovementMethod(LinkMovementMethod.getInstance());
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(12), 0, 0);
        box.addView(n, lp(MATCH, WRAP));
        TextView u = label("@" + r.user, 14, p.accent, false);
        u.setGravity(Gravity.CENTER);
        box.addView(u, lp(MATCH, WRAP));
        TextView b = label(r.bio.isEmpty() ? t(R.string.profile_no_bio) : r.bio, 15, r.bio.isEmpty() ? p.sub : p.text, false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, dp(14), 0, dp(6));
        box.addView(b, lp(MATCH, WRAP));
        new AlertDialog.Builder(this).setView(box).setPositiveButton(t(R.string.close), null).show();
    }

    // ------------------------------------------------------------------ группы и каналы

    private void showCreateChat(final String kind) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText title = edit(t(R.string.chat_title_hint));
        title.setSingleLine(true);
        title.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        box.addView(title, lp(MATCH, WRAP));
        final EditText bio = edit(t(R.string.chat_bio_hint));
        bio.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        LinearLayout.LayoutParams bp = lp(MATCH, WRAP);
        bp.topMargin = dp(10);
        box.addView(bio, bp);
        new AlertDialog.Builder(this)
                .setTitle("channel".equals(kind) ? t(R.string.menu_new_channel) : t(R.string.menu_new_group))
                .setView(box)
                .setPositiveButton(t(R.string.create), (d, w) -> {
                    String tt = title.getText().toString().trim();
                    if (tt.isEmpty()) {
                        toast(t(R.string.err_chat_title));
                        return;
                    }
                    createChat(kind, tt, bio.getText().toString().trim());
                })
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    private void createChat(String kind, String title, String bio) {
        final String tok = token;
        final JSONObject body = Api.obj("kind", kind, "title", title, "bio", bio);
        io.execute(() -> {
            final Api.Res r = Api.call("POST", "/chat/create", tok, body, 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                Row row = r.code == 200 && r.json != null ? parseChat(r.json) : null;
                if (row == null) {
                    toast(r.netFail ? netMsg() : r.code == 429 ? t(R.string.err_too_many) : t(R.string.err_server, r.code));
                    return;
                }
                openChat(row);
            });
        });
    }

    private void applyChat(Row row) {
        if (row == null || screen != SCREEN_CHAT || chatId != row.chatId) return;
        chatPeer = row;
        bindChatHeader();
        updateBottom();
    }

    private void showChatCard() {
        final Row c = chatPeer;
        if (c == null || !c.isChat()) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24), dp(20), dp(24), dp(8));
        ImageView av = new ImageView(this);
        box.addView(av, lp(dp(96), dp(96)));
        bindAvatar(av, c, 96);
        TextView n = label(c.title(), 20, p.text, true);
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(12), 0, 0);
        box.addView(n, lp(MATCH, WRAP));
        TextView k = label(kindLabel(c.kind) + "  ·  " + membersText(c), 14, p.sub, false);
        k.setGravity(Gravity.CENTER);
        box.addView(k, lp(MATCH, WRAP));
        TextView b = label(c.bio.isEmpty() ? t(R.string.profile_no_bio) : c.bio, 15, c.bio.isEmpty() ? p.sub : p.text, false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, dp(14), 0, dp(6));
        box.addView(b, lp(MATCH, WRAP));
        AlertDialog.Builder ab = new AlertDialog.Builder(this).setView(box).setNegativeButton(t(R.string.close), null);
        if (c.member) {
            TextView ml = label(t(R.string.chat_members), 15, p.accent, true);
            ml.setGravity(Gravity.CENTER);
            ml.setPadding(0, dp(10), 0, dp(10));
            box.addView(ml, lp(MATCH, WRAP));
            ml.setOnClickListener(v -> showMembers(c));
        }
        if (c.owner) {
            ab.setNeutralButton(t(R.string.chat_manage), (d, w) -> showChatManage(c));
        } else if (c.member) {
            ab.setPositiveButton(t(R.string.chat_leave), (d, w) -> confirmLeave(c));
        } else {
            ab.setPositiveButton(t(R.string.chat_join), (d, w) -> joinChat());
        }
        ab.show();
    }

    private void showMembers(Row c) {
        final String tok = token;
        final long id = c.chatId;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/chat/members?id=" + id, tok, null, 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                JSONArray a = r.code == 200 && r.json != null ? r.json.optJSONArray("users") : null;
                if (a == null) {
                    toast(r.netFail ? netMsg() : t(R.string.err_server, r.code));
                    return;
                }
                final List<Row> users = new ArrayList<>();
                List<String> names = new ArrayList<>();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    Row u = parseUser(o);
                    if (u == null) continue;
                    users.add(u);
                    names.add(u.title() + (u.verified ? " \u2714" : "") + "  @" + u.user
                            + (o.optBoolean("owner") ? "  (" + t(R.string.chat_owner) + ")" : ""));
                }
                new AlertDialog.Builder(this)
                        .setTitle(t(R.string.chat_members))
                        .setItems(names.toArray(new String[0]), (d, which) -> showUserCard(users.get(which)))
                        .setNegativeButton(t(R.string.close), null)
                        .show();
            });
        });
    }

    private void showChatManage(final Row c) {
        final String[] items = {t(R.string.chat_edit), t(R.string.profile_change_photo),
                t(R.string.profile_remove_photo), t(R.string.chat_delete)};
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            if (which == 0) showEditChat(c);
            else if (which == 1) pickImage(REQ_CHAT_AVATAR);
            else if (which == 2) chatAction("/chat/avatar/remove", Api.obj("id", Long.valueOf(c.chatId)), false);
            else confirmDelete(c);
        }).show();
    }

    private void showEditChat(final Row c) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText title = edit(t(R.string.chat_title_hint));
        title.setSingleLine(true);
        title.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        title.setText(c.title());
        box.addView(title, lp(MATCH, WRAP));
        final EditText bio = edit(t(R.string.chat_bio_hint));
        bio.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        bio.setText(c.bio);
        LinearLayout.LayoutParams bp = lp(MATCH, WRAP);
        bp.topMargin = dp(10);
        box.addView(bio, bp);
        new AlertDialog.Builder(this)
                .setTitle(t(R.string.chat_edit))
                .setView(box)
                .setPositiveButton(t(R.string.save), (d, w) -> {
                    String tt = title.getText().toString().trim();
                    if (tt.isEmpty()) {
                        toast(t(R.string.err_chat_title));
                        return;
                    }
                    chatAction("/chat/edit", Api.obj("id", Long.valueOf(c.chatId), "title", tt,
                            "bio", bio.getText().toString().trim()), false);
                })
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    /** POST-действие над чатом; в ответе новая карточка чата (или выход в список после удаления/выхода). */
    private void chatAction(final String path, JSONObject body, final boolean leaveScreen) {
        final String tok = token;
        final long id = chatId;
        final JSONObject b = body;
        io.execute(() -> {
            final Api.Res r = Api.call("POST", path, tok, b, 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                if (r.code != 200) {
                    toast(r.netFail ? netMsg() : r.code == 403 ? t(R.string.err_forbidden) : t(R.string.err_server, r.code));
                    return;
                }
                if (leaveScreen) {
                    if (screen == SCREEN_CHAT && chatId == id) showList();
                    return;
                }
                Row row = r.json == null ? null : parseChat(r.json);
                if (row != null) applyChat(row);
            });
        });
    }

    private void confirmLeave(final Row c) {
        new AlertDialog.Builder(this)
                .setMessage(t(R.string.chat_leave_confirm, c.title()))
                .setPositiveButton(t(R.string.chat_leave), (d, w) ->
                        chatAction("/chat/leave", Api.obj("id", Long.valueOf(c.chatId)), true))
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    private void confirmDelete(final Row c) {
        new AlertDialog.Builder(this)
                .setMessage(t(R.string.chat_delete_confirm, c.title()))
                .setPositiveButton(t(R.string.chat_delete), (d, w) ->
                        chatAction("/chat/delete", Api.obj("id", Long.valueOf(c.chatId)), true))
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    private void uploadChatAvatar(final Uri uri) {
        if (chatId <= 0) return;
        final long id = chatId;
        final String tok = token;
        toast(t(R.string.preparing));
        io.execute(() -> {
            final Images.Encoded e = Images.encode(this, uri, 512, true, 800 * 1024);
            if (e == null) {
                runOnUiThread(() -> toast(t(R.string.err_bad_image)));
                return;
            }
            final Api.Res r = Api.postBytes("/chat/avatar?id=" + id, tok, e.data, 30000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                Row row = r.code == 200 && r.json != null ? parseChat(r.json) : null;
                if (row != null) {
                    Images.forget();
                    applyChat(row);
                } else {
                    toast(r.netFail ? netMsg() : t(R.string.err_server, r.code));
                }
            });
        });
    }

    // ------------------------------------------------------------------ чат

    private void openChat(final Row peer) {
        screen = SCREEN_CHAT;
        chatId = peer.chatId;
        chatWith = peer.isChat() ? "#" + peer.chatId : peer.user;
        chatPeer = peer;
        replyingTo = null;
        hideKeyboard();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(peer.isChat() ? PollService.chatTag(peer.chatId) : PollService.tag(peer.user), PollService.MSG_ID);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(p.bar);
        header.setPadding(dp(4), dp(6), dp(12), dp(6));

        TextView back = label("←", 26, p.text, false);
        back.setPadding(dp(12), 0, dp(12), dp(2));
        back.setClickable(true);
        back.setOnClickListener(v -> showList());
        header.addView(back, lp(WRAP, WRAP));

        LinearLayout who = new LinearLayout(this);
        who.setOrientation(LinearLayout.HORIZONTAL);
        who.setGravity(Gravity.CENTER_VERTICAL);
        who.setOnClickListener(v -> {
            if (chatPeer == null) return;
            if (chatPeer.isChat()) showChatCard(); else showUserCard(chatPeer);
        });
        chatAvatar = new ImageView(this);
        LinearLayout.LayoutParams ap = lp(dp(38), dp(38));
        ap.rightMargin = dp(10);
        who.addView(chatAvatar, ap);
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        chatTitle = label("", 17, p.text, true);
        chatTitle.setSingleLine(true);
        chatTitle.setEllipsize(TextUtils.TruncateAt.END);
        chatSub = label("", 12, p.sub, false);
        chatSub.setSingleLine(true);
        names.addView(chatTitle);
        names.addView(chatSub);
        who.addView(names, lpw(0, WRAP, 1f));
        header.addView(who, lpw(0, WRAP, 1f));
        root.addView(header, lp(MATCH, WRAP));
        bindChatHeader();
        if (peer.isChat()) loadChatInfo(peer.chatId); else loadPeer(peer.user);

        statusView = banner();
        root.addView(statusView, lp(MATCH, WRAP));

        chatAdapter = new ChatAdapter();
        chatList = new ListView(this);
        chatList.setDivider(null);
        chatList.setDividerHeight(0);
        chatList.setSelector(new ColorDrawable(Color.TRANSPARENT));
        chatList.setCacheColorHint(Color.TRANSPARENT);
        chatList.setClipToPadding(false);
        chatList.setPadding(0, dp(6), 0, dp(6));
        chatList.setAdapter(chatAdapter);
        root.addView(chatList, lpw(MATCH, 0, 1f));

        // панель «ответ на сообщение»
        replyBar = new LinearLayout(this);
        replyBar.setOrientation(LinearLayout.HORIZONTAL);
        replyBar.setGravity(Gravity.CENTER_VERTICAL);
        replyBar.setBackgroundColor(p.surface);
        replyBar.setPadding(dp(12), dp(6), dp(4), dp(6));
        View strip = new View(this);
        strip.setBackgroundColor(p.accent);
        LinearLayout.LayoutParams stp = lp(dp(3), dp(36));
        stp.rightMargin = dp(10);
        replyBar.addView(strip, stp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        replyTitle = label("", 13, p.accent, true);
        replyPreview = label("", 14, p.sub, false);
        replyPreview.setSingleLine(true);
        replyPreview.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(replyTitle);
        col.addView(replyPreview);
        replyBar.addView(col, lpw(0, WRAP, 1f));
        ImageButton cancel = iconButton(android.R.drawable.ic_menu_close_clear_cancel);
        cancel.setOnClickListener(v -> clearReply());
        replyBar.addView(cancel, lp(dp(44), dp(44)));
        replyBar.setVisibility(View.GONE);
        root.addView(replyBar, lp(MATCH, WRAP));

        // ввод сообщения
        LinearLayout bar = new LinearLayout(this);
        inputBar = bar;
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(p.bar);
        bar.setPadding(dp(4), dp(6), dp(4), dp(6));
        ImageButton attach = iconButton(android.R.drawable.ic_menu_gallery);
        attach.setOnClickListener(v -> pickImage(REQ_PHOTO));
        bar.addView(attach, lp(dp(44), dp(44)));
        input = edit(t(R.string.message_hint));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMaxLines(5);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        bar.addView(input, lpw(0, WRAP, 1f));
        ImageButton send = iconButton(android.R.drawable.ic_menu_send);
        send.setColorFilter(p.accent);
        send.setOnClickListener(v -> sendMessage());
        bar.addView(send, lp(dp(48), dp(48)));
        root.addView(bar, lp(MATCH, WRAP));

        joinBar = button(t(R.string.chat_join));
        joinBar.setBackground(rounded(p.accent, 0));
        joinBar.setOnClickListener(v -> joinChat());
        root.addView(joinBar, lp(MATCH, WRAP));
        readOnlyBar = label(t(R.string.chat_readonly), 14, p.sub, false);
        readOnlyBar.setGravity(Gravity.CENTER);
        readOnlyBar.setBackgroundColor(p.bar);
        readOnlyBar.setPadding(dp(12), dp(14), dp(12), dp(14));
        root.addView(readOnlyBar, lp(MATCH, WRAP));
        updateBottom();

        setContentView(root);
        if (!peer.isChat() || peer.member) loadHistory();
    }

    /** Что показывать внизу: поле ввода, кнопку «Вступить» или подпись «пишет только владелец». */
    private void updateBottom() {
        if (inputBar == null || chatPeer == null) return;
        boolean chat = chatPeer.isChat();
        boolean canWrite = !chat || (chatPeer.member && ("group".equals(chatPeer.kind) || chatPeer.owner));
        inputBar.setVisibility(canWrite ? View.VISIBLE : View.GONE);
        joinBar.setVisibility(chat && !chatPeer.member ? View.VISIBLE : View.GONE);
        readOnlyBar.setVisibility(chat && chatPeer.member && !canWrite ? View.VISIBLE : View.GONE);
    }

    private void bindChatHeader() {
        if (chatPeer == null || chatTitle == null) return;
        chatTitle.setText(badge(chatPeer.title(), chatPeer.verified, chatPeer.user));
        chatTitle.setMovementMethod(LinkMovementMethod.getInstance());
        chatSub.setText(chatPeer.isChat() ? kindLabel(chatPeer.kind) + "  ·  " + membersText(chatPeer) : "@" + chatPeer.user);
        bindAvatar(chatAvatar, chatPeer, 38);
    }

    private void bindAvatar(ImageView iv, Row r, int sizeDp) {
        if (r.isChat()) Images.chatAvatar(iv, r.chatId, r.title(), r.avatar, dp(sizeDp), token);
        else Images.avatar(iv, r.user, r.title(), r.avatar, dp(sizeDp), token);
    }

    private String kindLabel(String kind) {
        return "channel".equals(kind) ? t(R.string.kind_channel) : t(R.string.kind_group);
    }

    private String membersText(Row r) {
        return "channel".equals(r.kind) ? t(R.string.subscribers_count, r.members) : t(R.string.members_count, r.members);
    }

    /** Имя с галочкой владельца. Если clickUser не null, по галочке показывается пояснение. */
    private CharSequence badge(String name, boolean verified, final String clickUser) {
        if (!verified) return name;
        SpannableStringBuilder sb = new SpannableStringBuilder(name + " \u2714");
        int a = name.length() + 1;
        sb.setSpan(new ForegroundColorSpan(p.accent), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (clickUser != null && !clickUser.isEmpty()) {
            sb.setSpan(new ClickableSpan() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setMessage(t(R.string.verified_owner, clickUser))
                            .setPositiveButton(t(R.string.close), null)
                            .show();
                }

                @Override
                public void updateDrawState(android.text.TextPaint ds) {
                    ds.setColor(p.accent);
                    ds.setUnderlineText(false);
                }
            }, a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return sb;
    }

    /** Имя и аватарка собеседника с сервера (при открытии из уведомления их ещё нет). */
    private void loadPeer(final String user) {
        final String tok = token;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/user?name=" + Api.enc(user), tok, null, 10000);
            runOnUiThread(() -> {
                if (r.code != 200 || r.json == null || screen != SCREEN_CHAT || !user.equalsIgnoreCase(chatWith)) return;
                Row row = parseUser(r.json);
                if (row == null) return;
                chatPeer = row;
                bindChatHeader();
            });
        });
    }

    /** Данные группы или канала с сервера. */
    private void loadChatInfo(final long id) {
        final String tok = token;
        io.execute(() -> {
            final Api.Res r = Api.call("GET", "/chat?id=" + id, tok, null, 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                if (screen != SCREEN_CHAT || chatId != id) return;
                if (r.code == 404) {
                    toast(t(R.string.chat_gone));
                    showList();
                    return;
                }
                Row row = r.json == null ? null : parseChat(r.json);
                if (row == null) return;
                boolean wasMember = chatPeer != null && chatPeer.member && chatPeer.isChat();
                chatPeer = row;
                bindChatHeader();
                updateBottom();
                if (row.member && !wasMember) loadHistory();
            });
        });
    }

    private void joinChat() {
        if (chatPeer == null || !chatPeer.isChat()) return;
        final long id = chatPeer.chatId;
        final String tok = token;
        io.execute(() -> {
            final Api.Res r = Api.call("POST", "/chat/join", tok, Api.obj("id", Long.valueOf(id)), 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                Row row = r.code == 200 && r.json != null ? parseChat(r.json) : null;
                if (row == null) {
                    toast(r.netFail ? netMsg() : t(R.string.err_server, r.code));
                    return;
                }
                if (screen == SCREEN_CHAT && chatId == id) {
                    chatPeer = row;
                    bindChatHeader();
                    updateBottom();
                    loadHistory();
                }
            });
        });
    }

    private void loadHistory() {
        final String peer = chatWith;
        final long cid = chatId;
        final String tok = token;
        if (peer == null || tok == null) return;
        final String path = cid > 0 ? "/history?chat=" + cid + "&limit=100"
                : "/history?with=" + Api.enc(peer) + "&limit=100";
        io.execute(() -> {
            final Api.Res r = Api.call("GET", path, tok, null, 10000);
            runOnUiThread(() -> {
                if (screen != SCREEN_CHAT || chatAdapter == null || !peer.equalsIgnoreCase(chatWith)) return;
                if (authFailed(r)) return;
                if (r.code == 403) return;
                if (r.netFail || r.code != 200 || r.json == null) {
                    setStatus(netMsg());
                    return;
                }
                setStatus(null);
                chatAdapter.merge(parseMsgs(r.json.optJSONArray("messages")));
                scrollToEnd();
            });
        });
    }

    private void sendMessage() {
        if (input == null || chatWith == null) return;
        final String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        final String to = chatWith;
        final long cid = chatId;
        final Msg rep = replyingTo;
        final String tok = token;
        input.setText("");
        clearReply();
        io.execute(() -> {
            final Object replyId = rep == null ? JSONObject.NULL : (Object) Long.valueOf(rep.id);
            final JSONObject body = cid > 0 ? Api.obj("chat", Long.valueOf(cid), "text", text, "reply_to", replyId)
                    : Api.obj("to", to, "text", text, "reply_to", replyId);
            final Api.Res r = Api.call("POST", "/send", tok, body, 10000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                JSONObject mo = r.json == null ? null : r.json.optJSONObject("message");
                if (r.code == 200 && mo != null) {
                    Msg m = parseMsg(mo);
                    if (m != null && screen == SCREEN_CHAT && to.equalsIgnoreCase(chatWith)) addToChat(m);
                    return;
                }
                toast(sendError(r));
                if (input != null && screen == SCREEN_CHAT && to.equalsIgnoreCase(chatWith)
                        && input.getText().length() == 0) {
                    input.setText(text);
                    input.setSelection(input.getText().length());
                }
            });
        });
    }

    private String sendError(Api.Res r) {
        if (r.netFail) return netMsg();
        if (r.code == 429) return t(R.string.err_too_fast);
        if (r.code == 404) return t(R.string.err_user_not_found);
        if (r.code == 403) return t(R.string.err_forbidden);
        if (r.code == 413) return t(R.string.err_too_big);
        return t(R.string.err_send, r.code);
    }

    // ----- фото

    private void preparePhoto(final Uri uri) {
        if (chatWith == null) return;
        final String to = chatWith;
        toast(t(R.string.preparing));
        io.execute(() -> {
            final Images.Encoded e = Images.encode(this, uri, 1280, false, 5 * 1024 * 1024);
            runOnUiThread(() -> {
                if (e == null) {
                    toast(t(R.string.err_bad_image));
                    return;
                }
                if (screen != SCREEN_CHAT || !to.equalsIgnoreCase(chatWith)) return;
                confirmPhoto(to, e);
            });
        });
    }

    private void confirmPhoto(final String to, final Images.Encoded e) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), 0);
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setMaxHeight(dp(300));
        Bitmap bmp = BitmapFactory.decodeByteArray(e.data, 0, e.data.length);
        if (bmp != null) iv.setImageBitmap(bmp);
        box.addView(iv, lp(MATCH, WRAP));
        final EditText cap = edit(t(R.string.photo_caption_hint));
        cap.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        LinearLayout.LayoutParams cp = lp(MATCH, WRAP);
        cp.topMargin = dp(10);
        box.addView(cap, cp);
        new AlertDialog.Builder(this)
                .setTitle(t(R.string.photo_send_title))
                .setView(box)
                .setPositiveButton(t(R.string.send), (d, w) -> uploadPhoto(to, e, cap.getText().toString().trim()))
                .setNegativeButton(t(R.string.cancel), null)
                .show();
    }

    private void uploadPhoto(final String to, final Images.Encoded e, final String caption) {
        final String tok = token;
        final Msg rep = replyingTo;
        clearReply();
        toast(t(R.string.sending));
        final long cid = chatId;
        final String path = "/photo?" + (cid > 0 ? "chat=" + cid : "to=" + Api.enc(to)) + "&w=" + e.w + "&h=" + e.h
                + (caption.isEmpty() ? "" : "&caption=" + Api.enc(caption))
                + (rep == null ? "" : "&reply_to=" + rep.id);
        io.execute(() -> {
            final Api.Res r = Api.postBytes(path, tok, e.data, 40000);
            runOnUiThread(() -> {
                if (authFailed(r)) return;
                JSONObject mo = r.json == null ? null : r.json.optJSONObject("message");
                if (r.code == 200 && mo != null) {
                    Msg m = parseMsg(mo);
                    if (m != null && screen == SCREEN_CHAT && to.equalsIgnoreCase(chatWith)) addToChat(m);
                } else {
                    toast(sendError(r));
                }
            });
        });
    }

    private void showPhotoViewer(String file) {
        final Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        ImageView iv = new ImageView(this);
        iv.setBackgroundColor(Color.BLACK);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setOnClickListener(v -> d.dismiss());
        d.setContentView(iv);
        Images.photo(iv, file, token, 2048);
        d.show();
    }

    // ----- сообщения

    private void addToChat(Msg m) {
        if (chatAdapter == null || chatList == null) return;
        boolean atBottom = chatAdapter.getCount() == 0
                || chatList.getLastVisiblePosition() >= chatAdapter.getCount() - 1;
        int before = chatAdapter.getCount();
        chatAdapter.merge(Collections.singletonList(m));
        if (chatAdapter.getCount() > before && (atBottom || m.from.equalsIgnoreCase(me))) scrollToEnd();
    }

    private void scrollToEnd() {
        if (chatList == null || chatAdapter == null) return;
        chatList.post(() -> {
            if (chatList != null && chatAdapter != null && chatAdapter.getCount() > 0) {
                chatList.setSelection(chatAdapter.getCount() - 1);
            }
        });
    }

    private void onMessageTap(final Msg m) {
        final List<String> labels = new ArrayList<>();
        labels.add(t(R.string.msg_reply));
        if (!m.text.isEmpty()) labels.add(t(R.string.msg_copy));
        new AlertDialog.Builder(this)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (which == 0) setReply(m); else copy(m.text);
                })
                .show();
    }

    private String quoteText(boolean photo, String text) {
        if (!photo) return text;
        return text.isEmpty() ? t(R.string.msg_photo) : t(R.string.msg_photo) + ": " + text;
    }

    private void setReply(Msg m) {
        replyingTo = m;
        if (replyBar == null) return;
        replyTitle.setText(t(R.string.reply_to, m.fromName.isEmpty() ? m.from : m.fromName));
        replyPreview.setText(quoteText(!m.photo.isEmpty(), m.text).replace('\n', ' '));
        replyBar.setVisibility(View.VISIBLE);
        input.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, 0);
    }

    private void clearReply() {
        replyingTo = null;
        if (replyBar != null) replyBar.setVisibility(View.GONE);
    }

    private void jumpTo(long id) {
        if (chatAdapter == null || chatList == null) return;
        int idx = chatAdapter.indexOf(id);
        if (idx >= 0) chatList.setSelection(idx); else toast(t(R.string.msg_above));
    }

    private void postRead(final String peer, final long cid, final long upto) {
        final String tok = token;
        if (peer == null || tok == null) return;
        io.execute(() -> Api.call("POST", "/read", tok,
                cid > 0 ? Api.obj("chat", Long.valueOf(cid), "upto", Long.valueOf(upto))
                        : Api.obj("with", peer, "upto", Long.valueOf(upto)), 10000));
    }

    // ------------------------------------------------------------------ состояние сети

    private boolean online() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    /** Текст для плашки. Адрес сервера пользователю не показываем. */
    private String netMsg() {
        return online() ? t(R.string.err_server_down) : t(R.string.err_no_internet);
    }

    // ------------------------------------------------------------------ получение сообщений (long-poll)

    private void startPolling() {
        if (running || token == null) return;
        running = true;
        final int gen = ++generation;
        final String tok = token;
        new Thread(() -> pollLoop(gen, tok)).start();
    }

    private void stopPolling() {
        running = false;
        generation++;
    }

    private void pollLoop(final int gen, final String tok) {
        long after = -1;
        while (running && gen == generation) {
            Api.Res r = Api.call("GET", "/updates" + (after >= 0 ? "?after=" + after : ""), tok, null, 35000);
            if (!running || gen != generation) return;
            if (r.code == 401) {
                runOnUiThread(() -> {
                    if (gen == generation) forceLogout(t(R.string.err_account_missing));
                });
                return;
            }
            if (r.netFail || r.code != 200 || r.json == null) {
                setStatus(netMsg());
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    return;
                }
                continue;
            }
            final boolean first = after < 0;
            final boolean reset = r.json.optBoolean("reset", false);
            final List<Msg> list = parseMsgs(r.json.optJSONArray("messages"));
            after = r.json.optLong("last", after);
            setStatus(null);
            runOnUiThread(() -> {
                if (gen != generation) return;
                // после первого ответа (или сброса базы) подтягиваем актуальное состояние экрана
                if (first || reset) refreshCurrent();
                onUpdates(list);
            });
        }
    }

    private void refreshCurrent() {
        if (screen == SCREEN_LIST) refreshDialogs();
        else if (screen == SCREEN_CHAT) loadHistory();
    }

    private void onUpdates(List<Msg> list) {
        if (list.isEmpty() || me == null) return;
        long maxIncoming = 0;
        Msg foreign = null;
        for (Msg m : list) {
            boolean mine = m.from.equalsIgnoreCase(me);
            String other = mine ? m.to : m.from;
            boolean current = screen == SCREEN_CHAT && chatWith != null
                    && (m.chat > 0 ? m.chat == chatId : chatId == 0 && other.equalsIgnoreCase(chatWith));
            if (current) {
                addToChat(m);
                if (!mine) maxIncoming = Math.max(maxIncoming, m.id);
            } else if (!mine) {
                foreign = m;
            }
        }
        if (maxIncoming > 0) postRead(chatWith, chatId, maxIncoming);
        if (foreign != null && screen != SCREEN_PROFILE) {
            String body = quoteText(!foreign.photo.isEmpty(), foreign.text);
            String who = foreign.fromName.isEmpty() ? foreign.from : foreign.fromName;
            if (foreign.chat > 0 && !foreign.chatTitle.isEmpty()) who = foreign.chatTitle + " · " + who;
            toast(who + ": " + preview(body));
        }
        if (screen == SCREEN_LIST) refreshDialogs();
    }

    // ------------------------------------------------------------------ разбор JSON

    private static Row parseUser(JSONObject o) {
        if (o == null || o.optString("username").isEmpty()) return null;
        Row r = new Row();
        r.user = o.optString("username");
        r.name = o.optString("display_name");
        r.bio = o.optString("bio");
        r.avatar = o.optLong("avatar");
        r.verified = o.optBoolean("verified");
        return r;
    }

    private static Row parseChat(JSONObject o) {
        if (o == null || o.optLong("id") <= 0) return null;
        Row r = new Row();
        r.chatId = o.optLong("id");
        r.kind = o.optString("kind", "group");
        r.name = o.optString("title");
        r.bio = o.optString("bio");
        r.avatar = o.optLong("avatar");
        r.members = o.optInt("members");
        r.member = o.optBoolean("member");
        r.owner = o.optBoolean("owner");
        return r;
    }

    private static Msg parseMsg(JSONObject o) {
        if (o == null) return null;
        Msg m = new Msg();
        m.id = o.optLong("id");
        m.from = o.optString("from");
        m.fromName = o.optString("from_name");
        m.fromAvatar = o.optLong("from_avatar");
        m.fromVerified = o.optBoolean("from_verified");
        m.chat = o.optLong("chat");
        m.chatTitle = o.optString("chat_title");
        m.to = o.optString("to");
        m.text = o.optString("text");
        m.ts = o.optLong("ts");
        if (!o.isNull("photo")) m.photo = o.optString("photo");
        m.w = o.optInt("w");
        m.h = o.optInt("h");
        JSONObject r = o.optJSONObject("reply");
        if (r != null) {
            m.replyId = r.optLong("id");
            m.replyFrom = r.optString("from");
            m.replyName = r.optString("from_name");
            m.replyText = r.optString("text");
            m.replyPhoto = r.optBoolean("photo");
        }
        return m.id > 0 ? m : null;
    }

    private static List<Msg> parseMsgs(JSONArray a) {
        List<Msg> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            Msg m = parseMsg(a.optJSONObject(i));
            if (m != null) out.add(m);
        }
        return out;
    }

    private static String preview(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 60 ? s.substring(0, 60) + "…" : s;
    }

    // ------------------------------------------------------------------ вспомогательные виды

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout.LayoutParams lpw(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView button(String text) {
        TextView tv = label(text, 16, Color.WHITE, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(16), dp(13), dp(16), dp(13));
        tv.setBackground(rounded(p.accent, 14));
        tv.setClickable(true);
        return tv;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(p.sub);
        e.setTextColor(p.text);
        e.setTextSize(16);
        e.setBackground(rounded(p.input, 14));
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        return e;
    }

    private ImageButton iconButton(int res) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setColorFilter(p.sub);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private TextView banner() {
        TextView tv = label("", 13, Color.WHITE, false);
        tv.setBackgroundColor(p.danger);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(5), dp(8), dp(5));
        tv.setVisibility(View.GONE);
        return tv;
    }

    private View padded(View v) {
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(v);
        return f;
    }

    private void setStatus(final String text) {
        runOnUiThread(() -> {
            if (statusView == null) return;
            if (text == null) {
                statusView.setVisibility(View.GONE);
            } else {
                statusView.setText(text);
                statusView.setVisibility(View.VISIBLE);
            }
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("FlauGram", s));
            toast(t(R.string.copied));
        }
    }

    private void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    // ------------------------------------------------------------------ адаптеры

    /** Список диалогов и результатов поиска. */
    private class RowAdapter extends BaseAdapter {
        private List<Row> rows = new ArrayList<>();
        private boolean search;
        private final SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final SimpleDateFormat df = new SimpleDateFormat("dd.MM", Locale.getDefault());

        void setRows(List<Row> r, boolean isSearch) {
            rows = new ArrayList<>(r);
            search = isSearch;
            notifyDataSetChanged();
        }

        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            RowHolder h;
            if (convert == null) {
                h = new RowHolder();
                convert = h.build();
                convert.setTag(h);
            } else {
                h = (RowHolder) convert.getTag();
            }
            h.bind(rows.get(pos));
            return convert;
        }

        private String when(long ts) {
            Date d = new Date(ts);
            return DateUtils.isToday(ts) ? tf.format(d) : df.format(d);
        }

        private class RowHolder {
            LinearLayout root;
            ImageView avatar;
            TextView name, sub, time, badge;

            View build() {
                root = new LinearLayout(MainActivity.this);
                root.setOrientation(LinearLayout.HORIZONTAL);
                root.setGravity(Gravity.CENTER_VERTICAL);
                root.setPadding(dp(14), dp(10), dp(14), dp(10));

                avatar = new ImageView(MainActivity.this);
                LinearLayout.LayoutParams ap = lp(dp(48), dp(48));
                ap.rightMargin = dp(12);
                root.addView(avatar, ap);

                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                name = label("", 16, p.text, true);
                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.END);
                sub = label("", 14, p.sub, false);
                sub.setSingleLine(true);
                sub.setEllipsize(TextUtils.TruncateAt.END);
                col.addView(name);
                col.addView(sub);
                root.addView(col, lpw(0, WRAP, 1f));

                LinearLayout right = new LinearLayout(MainActivity.this);
                right.setOrientation(LinearLayout.VERTICAL);
                right.setGravity(Gravity.END);
                time = label("", 12, p.sub, false);
                badge = label("", 12, Color.WHITE, true);
                badge.setGravity(Gravity.CENTER);
                badge.setMinWidth(dp(22));
                badge.setPadding(dp(6), dp(1), dp(6), dp(1));
                right.addView(time);
                LinearLayout.LayoutParams bp = lp(WRAP, WRAP);
                bp.topMargin = dp(4);
                right.addView(badge, bp);
                root.addView(right, lp(WRAP, WRAP));
                return root;
            }

            void bind(Row r) {
                bindAvatar(avatar, r, 48);
                name.setText(badge(r.title(), r.verified, null));
                if (search) {
                    sub.setText(r.sub);
                    time.setVisibility(View.GONE);
                    badge.setVisibility(View.GONE);
                    return;
                }
                sub.setText((r.mine ? t(R.string.you_prefix) : "") + r.sub);
                time.setVisibility(View.VISIBLE);
                time.setText(when(r.ts));
                time.setTextColor(r.unread > 0 ? p.accent : p.sub);
                if (r.unread > 0) {
                    badge.setVisibility(View.VISIBLE);
                    badge.setText(r.unread > 99 ? "99+" : String.valueOf(r.unread));
                    badge.setBackground(rounded(p.accent, 11));
                } else {
                    badge.setVisibility(View.GONE);
                }
            }
        }
    }

    /** Сообщения переписки. */
    private class ChatAdapter extends BaseAdapter {
        private final ArrayList<Msg> items = new ArrayList<>();
        private final HashSet<Long> ids = new HashSet<>();
        private final SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final int maxW = (int) (getResources().getDisplayMetrics().widthPixels * 0.78f);

        void merge(List<Msg> more) {
            boolean changed = false;
            for (Msg m : more) {
                if (ids.add(m.id)) {
                    items.add(m);
                    changed = true;
                }
            }
            if (changed) {
                Collections.sort(items, (a, b) -> Long.compare(a.id, b.id));
                notifyDataSetChanged();
            }
        }

        int indexOf(long id) {
            for (int i = 0; i < items.size(); i++) if (items.get(i).id == id) return i;
            return -1;
        }

        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return items.get(i).id; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Holder h;
            if (convert == null) {
                h = new Holder();
                convert = h.build();
                convert.setTag(h);
            } else {
                h = (Holder) convert.getTag();
            }
            h.bind(items.get(pos));
            return convert;
        }

        private class Holder {
            LinearLayout row, bubble, quote;
            View strip;
            ImageView photo;
            TextView qFrom, qText, text, time, sender;

            View build() {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(8), dp(3), dp(8), dp(3));

                bubble = new LinearLayout(MainActivity.this);
                bubble.setOrientation(LinearLayout.VERTICAL);
                bubble.setPadding(dp(11), dp(7), dp(11), dp(6));

                quote = new LinearLayout(MainActivity.this);
                quote.setOrientation(LinearLayout.HORIZONTAL);
                quote.setPadding(dp(8), dp(4), dp(8), dp(4));
                strip = new View(MainActivity.this);
                LinearLayout.LayoutParams stp = lp(dp(3), MATCH);
                stp.rightMargin = dp(8);
                quote.addView(strip, stp);
                LinearLayout qcol = new LinearLayout(MainActivity.this);
                qcol.setOrientation(LinearLayout.VERTICAL);
                qFrom = label("", 12, p.accent, true);
                qText = label("", 13, p.sub, false);
                qText.setMaxLines(2);
                qText.setEllipsize(TextUtils.TruncateAt.END);
                qText.setMaxWidth(maxW - dp(40));
                qcol.addView(qFrom);
                qcol.addView(qText);
                quote.addView(qcol);
                sender = label("", 13, p.accent, true);
                bubble.addView(sender, lp(WRAP, WRAP));

                LinearLayout.LayoutParams qp = lp(WRAP, WRAP);
                qp.bottomMargin = dp(5);
                bubble.addView(quote, qp);

                photo = new ImageView(MainActivity.this);
                photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
                LinearLayout.LayoutParams pp = lp(maxW, maxW);
                pp.bottomMargin = dp(4);
                bubble.addView(photo, pp);

                text = label("", 16, p.text, false);
                text.setMaxWidth(maxW);
                bubble.addView(text, lp(WRAP, WRAP));

                time = label("", 11, p.sub, false);
                LinearLayout.LayoutParams tp = lp(WRAP, WRAP);
                tp.gravity = Gravity.END;
                bubble.addView(time, tp);

                row.addView(bubble, lp(WRAP, WRAP));
                return row;
            }

            void bind(final Msg m) {
                boolean mine = m.from.equalsIgnoreCase(me);
                row.setGravity(mine ? Gravity.END : Gravity.START);
                bubble.setBackground(rounded(mine ? p.outBubble : p.inBubble, 16));
                if (!mine && chatPeer != null && "group".equals(chatPeer.kind)) {
                    String nm = m.fromName.isEmpty() ? m.from : m.fromName;
                    sender.setText(badge(nm, m.fromVerified, null));
                    sender.setTextColor(Images.nameColor(m.from));
                    sender.setVisibility(View.VISIBLE);
                } else {
                    sender.setVisibility(View.GONE);
                }
                text.setTextColor(mine ? Color.WHITE : p.text);
                text.setText(m.text);
                text.setVisibility(m.text.isEmpty() ? View.GONE : View.VISIBLE);
                time.setTextColor(mine ? 0xB3FFFFFF : p.sub);
                time.setText(tf.format(new Date(m.ts)));

                if (m.photo.isEmpty()) {
                    photo.setVisibility(View.GONE);
                    photo.setTag(null);
                    photo.setOnClickListener(null);
                } else {
                    float ratio = m.w > 0 && m.h > 0 ? (float) m.h / m.w : 0.75f;
                    int bw = maxW;
                    int bh = Math.round(bw * ratio);
                    int maxH = dp(340);
                    if (bh > maxH) {
                        bh = maxH;
                        bw = Math.max(dp(80), Math.round(bh / ratio));
                    }
                    if (bh < dp(60)) bh = dp(60);
                    LinearLayout.LayoutParams pp = (LinearLayout.LayoutParams) photo.getLayoutParams();
                    pp.width = bw;
                    pp.height = bh;
                    photo.setLayoutParams(pp);
                    photo.setBackgroundColor(mine ? 0x33FFFFFF : 0x22888888);
                    photo.setVisibility(View.VISIBLE);
                    Images.photo(photo, m.photo, token, 800);
                    final String file = m.photo;
                    photo.setOnClickListener(v -> showPhotoViewer(file));
                }

                if (m.replyId > 0) {
                    quote.setVisibility(View.VISIBLE);
                    quote.setBackground(rounded(mine ? 0x33FFFFFF : 0x22888888, 8));
                    strip.setBackgroundColor(mine ? 0xCCFFFFFF : p.accent);
                    qFrom.setText(m.replyName.isEmpty() ? m.replyFrom : m.replyName);
                    qFrom.setTextColor(mine ? Color.WHITE : p.accent);
                    qText.setText(quoteText(m.replyPhoto, m.replyText));
                    qText.setTextColor(mine ? 0xCCFFFFFF : p.sub);
                    quote.setOnClickListener(v -> jumpTo(m.replyId));
                } else {
                    quote.setVisibility(View.GONE);
                    quote.setOnClickListener(null);
                }
                bubble.setOnClickListener(v -> onMessageTap(m));
                bubble.setOnLongClickListener(v -> {
                    onMessageTap(m);
                    return true;
                });
            }
        }
    }
}
