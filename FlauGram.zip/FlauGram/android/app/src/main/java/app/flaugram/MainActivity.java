package app.flaugram;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String SERVER = BuildConfig.SERVER_URL;
    private static final int MAX_SHOWN = 500;

    private static class Msg {
        final String nick, text;
        final long ts;
        Msg(String nick, String text, long ts) { this.nick = nick; this.text = text; this.ts = ts; }
    }

    private SharedPreferences prefs;
    private String nick = "";

    // экран чата
    private ListView listView;
    private EditText input;
    private TextView statusView;
    private final MsgAdapter adapter = new MsgAdapter();
    private boolean chatShown = false;

    // опрос сервера
    private volatile boolean running = false;
    private volatile int generation = 0;
    private volatile long lastId = -1;
    private volatile HttpURLConnection curConn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("chat", MODE_PRIVATE);
        nick = prefs.getString("nick", "");
        if (nick.length() < 2) showLogin(); else showChat();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (chatShown) startPolling();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopPolling();
    }

    // ---------- экран ввода ника ----------

    private void showLogin() {
        chatShown = false;
        stopPolling();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(32), dp(32), dp(32), dp(32));

        TextView title = new TextView(this);
        title.setText("FlauGram");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Один чат на весь мир.\nПридумай ник и заходи.");
        sub.setTextSize(16);
        sub.setTextColor(0xFF666666);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(8), 0, dp(24));
        root.addView(sub);

        final EditText et = new EditText(this);
        et.setHint("Твой ник");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        et.setText(nick);
        root.addView(et, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button go = new Button(this);
        go.setText("Войти");
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        glp.topMargin = dp(16);
        root.addView(go, glp);

        final Runnable submit = new Runnable() {
            @Override public void run() {
                String n = cleanNick(et.getText().toString());
                if (n.length() < 2) {
                    Toast.makeText(MainActivity.this, "Ник — минимум 2 символа", Toast.LENGTH_SHORT).show();
                    return;
                }
                nick = n;
                prefs.edit().putString("nick", n).apply();
                showChat();
            }
        };
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { submit.run(); }
        });
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent e) {
                submit.run();
                return true;
            }
        });

        setContentView(root);
    }

    // ---------- экран чата ----------

    private void showChat() {
        stopPolling();
        chatShown = true;
        adapter.clear();
        lastId = -1;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        // шапка
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(0xFFF2F2F2);
        header.setPadding(dp(16), dp(8), dp(8), dp(8));

        TextView title = new TextView(this);
        title.setText("FlauGram");
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.BLACK);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button nickBtn = new Button(this);
        nickBtn.setText("Ник: " + nick);
        nickBtn.setAllCaps(false);
        nickBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { changeNick(); }
        });
        header.addView(nickBtn);
        root.addView(header);

        // статус соединения
        statusView = new TextView(this);
        statusView.setTextColor(Color.WHITE);
        statusView.setBackgroundColor(0xFFC0392B);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
        statusView.setVisibility(View.GONE);
        root.addView(statusView);

        // список сообщений
        listView = new ListView(this);
        listView.setDivider(null);
        listView.setAdapter(adapter);
        root.addView(listView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // поле ввода
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFF2F2F2);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));

        input = new EditText(this);
        input.setHint("Сообщение");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMaxLines(4);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});
        bar.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button sendBtn = new Button(this);
        sendBtn.setText("Отправить");
        sendBtn.setAllCaps(false);
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendMessage(); }
        });
        bar.addView(sendBtn);
        root.addView(bar);

        setContentView(root);
        startPolling();
    }

    private void changeNick() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(nick);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        FrameLayoutPad pad = new FrameLayoutPad(et);
        new AlertDialog.Builder(this)
                .setTitle("Новый ник")
                .setView(pad)
                .setPositiveButton("Сохранить", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String n = cleanNick(et.getText().toString());
                        if (n.length() < 2) {
                            Toast.makeText(MainActivity.this, "Ник — минимум 2 символа", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        nick = n;
                        prefs.edit().putString("nick", n).apply();
                        showChat();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    /** Обёртка с отступами для поля внутри диалога. */
    private class FrameLayoutPad extends android.widget.FrameLayout {
        FrameLayoutPad(View child) {
            super(MainActivity.this);
            setPadding(dp(24), dp(8), dp(24), 0);
            addView(child);
        }
    }

    // ---------- отправка ----------

    private void sendMessage() {
        final String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        final String who = nick;

        new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection c = null;
                String error = null;
                try {
                    byte[] body = new JSONObject().put("nick", who).put("text", t).toString().getBytes("UTF-8");
                    c = (HttpURLConnection) new URL(SERVER + "/send").openConnection();
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(10000);
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    c.setFixedLengthStreamingMode(body.length);
                    OutputStream os = c.getOutputStream();
                    os.write(body);
                    os.close();
                    int code = c.getResponseCode();
                    if (code == 429) error = "Слишком часто, подожди секунду";
                    else if (code != 200) error = "Не отправилось (" + code + ")";
                } catch (Exception e) {
                    error = "Нет связи с сервером";
                } finally {
                    if (c != null) c.disconnect();
                }
                if (error != null) {
                    final String msg = error;
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                            if (input != null && input.getText().length() == 0) input.setText(t);
                        }
                    });
                }
            }
        }).start();
    }

    // ---------- получение (long-poll) ----------

    private void startPolling() {
        if (running) return;
        running = true;
        final int gen = ++generation;
        new Thread(new Runnable() {
            @Override public void run() { pollLoop(gen); }
        }).start();
    }

    private void stopPolling() {
        running = false;
        generation++;
        final HttpURLConnection c = curConn;
        if (c != null) {
            new Thread(new Runnable() {
                @Override public void run() { try { c.disconnect(); } catch (Exception ignored) { } }
            }).start();
        }
    }

    private void pollLoop(final int gen) {
        while (running && gen == generation) {
            HttpURLConnection c = null;
            try {
                String q = SERVER + "/messages" + (lastId >= 0 ? "?after=" + lastId : "");
                c = (HttpURLConnection) new URL(q).openConnection();
                curConn = c;
                c.setConnectTimeout(8000);
                c.setReadTimeout(35000);
                c.setUseCaches(false);
                int code = c.getResponseCode();
                if (code != 200) throw new IOException("HTTP " + code);
                JSONObject o = new JSONObject(readAll(c.getInputStream()));
                JSONArray arr = o.getJSONArray("messages");
                final boolean reset = o.optBoolean("reset", false);
                final List<Msg> list = new ArrayList<Msg>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject m = arr.getJSONObject(i);
                    list.add(new Msg(m.optString("nick", "?"), m.optString("text", ""), m.optLong("ts", 0)));
                }
                if (gen != generation) break;
                lastId = o.optLong("last", lastId);
                runOnUiThread(new Runnable() {
                    @Override public void run() { deliver(list, reset, gen); }
                });
            } catch (Exception e) {
                if (!running || gen != generation) break;
                setStatus("Нет связи с " + SERVER);
                try { Thread.sleep(3000); } catch (InterruptedException ie) { break; }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void deliver(List<Msg> list, boolean reset, int gen) {
        if (gen != generation || !chatShown) return;
        statusView.setVisibility(View.GONE);
        if (reset) adapter.clear();
        if (list.isEmpty()) return;
        boolean atBottom = adapter.getCount() == 0
                || listView.getLastVisiblePosition() >= adapter.getCount() - 1;
        adapter.addAll(list);
        if (atBottom) listView.setSelection(adapter.getCount() - 1);
    }

    private void setStatus(final String text) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (statusView == null || !chatShown) return;
                statusView.setText(text);
                statusView.setVisibility(View.VISIBLE);
            }
        });
    }

    // ---------- вспомогательное ----------

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    private static String cleanNick(String s) {
        s = s.replaceAll("\\s+", " ").trim();
        if (s.length() > 20) s = s.substring(0, 20).trim();
        return s;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static int nickColor(String nick) {
        int hue = Math.abs(nick.hashCode()) % 360;
        return Color.HSVToColor(new float[]{hue, 0.65f, 0.70f});
    }

    private class MsgAdapter extends BaseAdapter {
        private final ArrayList<Msg> items = new ArrayList<Msg>();
        private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.getDefault());

        void clear() { items.clear(); notifyDataSetChanged(); }

        void addAll(List<Msg> more) {
            items.addAll(more);
            while (items.size() > MAX_SHOWN) items.remove(0);
            notifyDataSetChanged();
        }

        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int i, View convert, ViewGroup parent) {
            TextView tv = (TextView) convert;
            if (tv == null) {
                tv = new TextView(MainActivity.this);
                tv.setTextSize(16);
                tv.setTextColor(Color.BLACK);
                tv.setPadding(dp(14), dp(6), dp(14), dp(6));
            }
            Msg m = items.get(i);
            SpannableStringBuilder sb = new SpannableStringBuilder();
            int s = sb.length();
            sb.append(m.nick);
            sb.setSpan(new StyleSpan(Typeface.BOLD), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new ForegroundColorSpan(nickColor(m.nick)), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (m.ts > 0) {
                s = sb.length();
                sb.append("  ").append(fmt.format(new Date(m.ts)));
                sb.setSpan(new ForegroundColorSpan(0xFF999999), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.setSpan(new RelativeSizeSpan(0.75f), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            sb.append("\n").append(m.text);
            tv.setText(sb);
            return tv;
        }
    }
}
