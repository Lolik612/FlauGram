package app.flaugram;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Одна activity, внутри стек экранов (см. Screen). Здесь же получение сообщений и всплывающие плашки. */
public class MainActivity extends Activity {

    interface Cb {
        void done(Api.Res r);
    }

    static final int REQ_PICK = 21;

    /** Открыто ли приложение сейчас. Пока открыто, системные уведомления не показываем. */
    static volatile boolean visible = false;

    Ui ui;
    Palette p;
    final ExecutorService io = Executors.newCachedThreadPool();
    final Handler h = new Handler(Looper.getMainLooper());

    private FrameLayout content, overlay;
    private final ArrayList<Screen> stack = new ArrayList<>();
    private Screen pickOwner;
    private int pickReq;
    private View bannerView, toastView;
    private Runnable bannerHide, toastHide;

    private volatile boolean running = false;
    private volatile int generation = 0;
    private boolean bannedShown = false;

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    @Override
    protected void onCreate(Bundle b) {
        Session.load(this);
        setTheme(Session.dark ? android.R.style.Theme_DeviceDefault_NoActionBar
                : android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        super.onCreate(b);
        p = Session.dark ? Palette.dark(Session.theme, Session.accent) : Palette.light(Session.accent);
        ui = new Ui(this, p);
        applyBars();

        FrameLayout rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(p.bg);
        content = new FrameLayout(this);
        rootFrame.addView(content, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        overlay = new FrameLayout(this);
        overlay.setClipChildren(false);
        rootFrame.addView(overlay, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setContentView(rootFrame);

        if (Session.loggedIn()) startSession(); else resetTo(new RegisterScreen(this));
        handleIntent(getIntent());
        Updater.onAppStart(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        visible = true;
        startPolling();
        if (Session.loggedIn() && Session.prefs.getBoolean("notify", true)) PollService.start(this);
        Screen t = top();
        if (t != null) t.onShow();
    }

    @Override
    protected void onStop() {
        super.onStop();
        visible = false;
        stopPolling();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        for (Screen s : stack) s.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** Нажатие на уведомление открывает переписку с отправителем. */
    private void handleIntent(Intent i) {
        if (i == null || !Session.loggedIn()) return;
        long cid = i.getLongExtra("chat_id", 0);
        if (cid > 0) {
            i.removeExtra("chat_id");
            Model.Row r = new Model.Row();
            r.chatId = cid;
            r.kind = "group";
            push(new ChatScreen(this, r));
            return;
        }
        String chat = i.getStringExtra("chat");
        if (chat == null || chat.isEmpty()) return;
        i.removeExtra("chat");
        Model.Row r = new Model.Row();
        r.user = chat;
        push(new ChatScreen(this, r));
    }

    @Override
    public void onBackPressed() {
        Screen t = top();
        if (t != null && t.onBack()) return;
        if (stack.size() > 1) pop(); else super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || pickOwner == null) return;
        Screen owner = pickOwner;
        int r = pickReq;
        pickOwner = null;
        if (res == RESULT_OK && data != null && data.getData() != null) owner.onResult(r, data.getData());
    }

    private void applyBars() {
        Window w = getWindow();
        w.setStatusBarColor(p.bg);
        w.setNavigationBarColor(p.bg);
        View d = w.getDecorView();
        int f = d.getSystemUiVisibility();
        if (Build.VERSION.SDK_INT >= 23) {
            f = p.dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            f = p.dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        d.setSystemUiVisibility(f);
    }

    // ------------------------------------------------------------------ стек экранов

    /** Экран, лежащий в стеке прямо под этим. */
    Screen below(Screen s) {
        int i = stack.indexOf(s);
        return i > 0 ? stack.get(i - 1) : null;
    }

    Screen top() {
        return stack.isEmpty() ? null : stack.get(stack.size() - 1);
    }

    void push(final Screen s) {
        hideKeyboard();
        final Screen prev = top();
        s.root = s.build();
        stack.add(s);
        content.addView(s.root, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        if (prev != null) {
            s.root.setAlpha(0f);
            s.root.setTranslationX(ui.dp(40));
            s.root.animate().alpha(1f).translationX(0).setDuration(200).withEndAction(() -> {
                if (prev.root != null && top() != prev) content.removeView(prev.root);
            }).start();
            prev.onHide();
        }
        s.onShow();
    }

    boolean pop() {
        if (stack.size() <= 1) return false;
        hideKeyboard();
        final Screen s = stack.remove(stack.size() - 1);
        Screen prev = top();
        if (prev.root.getParent() == null) content.addView(prev.root, 0, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        final View v = s.root;
        s.onHide();
        s.onDestroy();
        v.animate().alpha(0f).translationX(ui.dp(40)).setDuration(160).withEndAction(() -> content.removeView(v)).start();
        prev.onShow();
        return true;
    }

    /** Убирает все экраны и показывает один (после входа и выхода). */
    void resetTo(Screen s) {
        hideKeyboard();
        for (Screen old : stack) old.onDestroy();
        stack.clear();
        content.removeAllViews();
        s.root = s.build();
        stack.add(s);
        content.addView(s.root, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        s.onShow();
    }

    /** Пересоздать всё (смена темы и языка). */
    void restart() {
        recreate();
    }

    // ------------------------------------------------------------------ вход и выход

    void startSession() {
        bannedShown = false;
        resetTo(new ShellScreen(this));
        startPolling();
        if (Session.prefs.getBoolean("notify", true)) PollService.start(this);
        if (!Session.prefs.getBoolean("asked_notif", false)) {
            Session.prefs.edit().putBoolean("asked_notif", true).apply();
            askNotifPermission();
        }
        refreshMe();
    }

    void refreshMe() {
        api("GET", "/me", null, r -> {
            if (r.code != 200 || r.json == null) return;
            Session.saveMe(r.json.optString("display_name"), r.json.optString("bio"), r.json.optLong("avatar"),
                    r.json.optBoolean("admin"), r.json.optBoolean("verified"));
            Session.setMail(r.json.optString("email"), r.json.optBoolean("mail_enabled"), r.json.optLong("key_next_ms"));
            for (Screen s : new ArrayList<>(stack)) s.onMeChanged();
            // один раз предлагаем привязать почту аккаунтам, созданным до почты
            if (Session.mailEnabled && Session.email.isEmpty() && !Session.prefs.getBoolean("mail_nudged", false)) {
                Session.prefs.edit().putBoolean("mail_nudged", true).apply();
                new Sheet(this).title(ui.t(R.string.mail_nudge_title)).text(ui.t(R.string.mail_nudge_text))
                        .buttons(ui.t(R.string.later), ui.t(R.string.mail_bind_go), false, () -> MailFlow.bind(this)).show();
            }
        });
    }

    /** Ключ доступа сменился (перевыпуск): перезапускаем получение сообщений с новым ключом. */
    void tokenChanged() {
        stopPolling();
        startPolling();
        PollService.stop(this);
        if (Session.prefs.getBoolean("notify", true)) PollService.start(this);
    }

    void logout(String message) {
        Session.logout();
        PollService.stop(this);
        stopPolling();
        Images.forget();
        resetTo(new RegisterScreen(this, message));
    }

    void askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    // ------------------------------------------------------------------ сеть

    /** Запрос к серверу в фоне; ответ приходит в cb на главном потоке. Вход и бан обрабатываются здесь. */
    void api(final String method, final String path, final JSONObject body, final Cb cb) {
        final String tok = Session.token;
        io.execute(() -> {
            final Api.Res r = Api.call(method, path, tok, body, 15000);
            runOnUiThread(() -> deliver(tok, r, cb));
        });
    }

    void apiBytes(final String path, final byte[] data, final Cb cb) {
        final String tok = Session.token;
        io.execute(() -> {
            final Api.Res r = Api.postBytes(path, tok, data, 40000);
            runOnUiThread(() -> deliver(tok, r, cb));
        });
    }

    private void deliver(String tok, Api.Res r, Cb cb) {
        if (tok == null || !tok.equals(Session.token)) return;
        if (r.code == 401) {
            logout(getString(R.string.err_account_missing));
            return;
        }
        if (r.code == 403 && r.json != null && "banned".equals(r.json.optString("error"))) {
            showBanned(r.json.optString("reason"));
            return;
        }
        if (cb != null) cb.done(r);
    }

    private void showBanned(String reason) {
        if (bannedShown) return;
        bannedShown = true;
        stopPolling();
        PollService.stop(this);
        resetTo(new BannedScreen(this, reason));
    }

    boolean online() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    /** Текст для плашки об ошибке. Адрес сервера пользователю не показываем. */
    String netMsg() {
        return online() ? getString(R.string.err_server_down) : getString(R.string.err_no_internet);
    }

    String errText(Api.Res r) {
        if (r.netFail) return netMsg();
        if (r.code == 429) return getString(R.string.err_too_fast);
        if (r.code == 403) return getString(R.string.err_forbidden);
        if (r.code == 404) return getString(R.string.err_user_not_found);
        if (r.code == 413) return getString(R.string.err_too_big);
        return getString(R.string.err_server, r.code);
    }

    // ------------------------------------------------------------------ получение сообщений (long-poll)

    private void startPolling() {
        if (running || Session.token == null) return;
        running = true;
        final int gen = ++generation;
        final String tok = Session.token;
        new Thread(() -> pollLoop(gen, tok)).start();
    }

    private void stopPolling() {
        running = false;
        generation++;
    }

    private void pollLoop(final int gen, final String tok) {
        long after = -1;
        boolean wasDown = false;
        while (running && gen == generation) {
            Api.Res r = Api.call("GET", "/updates?fg=1" + (after >= 0 ? "&after=" + after : ""), tok, null, 35000);
            if (!running || gen != generation) return;
            if (r.code == 401) {
                runOnUiThread(() -> {
                    if (gen == generation) logout(getString(R.string.err_account_missing));
                });
                return;
            }
            if (r.code == 403 && r.json != null && "banned".equals(r.json.optString("error"))) {
                final String reason = r.json.optString("reason");
                runOnUiThread(() -> {
                    if (gen == generation) showBanned(reason);
                });
                return;
            }
            if (r.netFail || r.code != 200 || r.json == null) {
                if (!wasDown) {
                    wasDown = true;
                    runOnUiThread(() -> {
                        if (gen == generation) netBanner(true);
                    });
                }
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    return;
                }
                continue;
            }
            final boolean first = after < 0;
            final boolean reset = r.json.optBoolean("reset", false);
            final List<Model.Msg> list = Model.msgs(r.json.optJSONArray("messages"));
            after = r.json.optLong("last", after);
            final boolean recovered = wasDown;
            wasDown = false;
            runOnUiThread(() -> {
                if (gen != generation) return;
                if (recovered) netBanner(false);
                // после первого ответа, сброса базы или обрыва связи подтягиваем актуальное состояние экранов
                if (first || reset || recovered) {
                    for (Screen s : new ArrayList<>(stack)) s.onMeChanged();
                    Screen t = top();
                    if (t != null) t.onShow();
                }
                dispatch(list);
            });
        }
    }

    private TextView netView;

    private void netBanner(boolean show) {
        if (!show) {
            if (netView != null) {
                overlay.removeView(netView);
                netView = null;
            }
            return;
        }
        if (netView != null) return;
        netView = ui.label(netMsg(), 13, Color.WHITE, true);
        netView.setGravity(Gravity.CENTER);
        netView.setBackground(ui.rounded(p.danger, 14));
        netView.setPadding(ui.dp(14), ui.dp(7), ui.dp(14), ui.dp(7));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = ui.dp(10);
        overlay.addView(netView, lp);
    }

    private void dispatch(List<Model.Msg> list) {
        if (list.isEmpty() || Session.me == null) return;
        for (Screen s : new ArrayList<>(stack)) s.onUpdates(list);
        Model.Msg foreign = null;
        Screen t = top();
        for (Model.Msg m : list) {
            if (m.deleted || m.edited) continue;
            if (m.from.equalsIgnoreCase(Session.me)) continue;
            if (t != null && t.showsChat(m)) continue;
            String key = m.chat > 0 ? "c:" + m.chat : "u:" + m.from.toLowerCase();
            if (Session.isMuted(key)) continue;
            foreign = m;
        }
        if (foreign == null) return;
        String body = foreign.photo.isEmpty() ? foreign.text : getString(R.string.msg_photo)
                + (foreign.text.isEmpty() ? "" : ": " + foreign.text);
        String who = foreign.fromName.isEmpty() ? foreign.from : foreign.fromName;
        if (foreign.chat > 0 && !foreign.chatTitle.isEmpty()) who = foreign.chatTitle + " · " + who;
        final Model.Msg fm = foreign;
        showBanner(who, preview(body), foreign.from, foreign.fromAvatar, () -> {
            Model.Row r = new Model.Row();
            if (fm.chat > 0) {
                r.chatId = fm.chat;
                r.kind = "group";
                r.name = fm.chatTitle;
            } else {
                r.user = fm.from;
                r.name = fm.fromName;
                r.avatar = fm.fromAvatar;
            }
            push(new ChatScreen(MainActivity.this, r));
        });
    }

    static String preview(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 70 ? s.substring(0, 70) + "…" : s;
    }

    // ------------------------------------------------------------------ плашки поверх экрана

    /** Плашка о новом сообщении (вместо всплывающих тостов). */
    void showBanner(String title, String text, String user, long avatar, final Runnable onClick) {
        if (bannerView != null) {
            overlay.removeView(bannerView);
            if (bannerHide != null) h.removeCallbacks(bannerHide);
        }
        LinearLayout card = ui.horizontal();
        card.setPadding(ui.dp(12), ui.dp(10), ui.dp(14), ui.dp(10));
        card.setBackground(ui.rounded(p.nav, 22));
        card.setElevation(ui.dp(10));
        AvatarView av = new AvatarView(this, ui.dp(40), 0);
        Images.avatar(av.image(), user, title, avatar, ui.dp(40), Session.token);
        card.addView(av, ui.lpm(ui.dp(40), ui.dp(40), 0, 0, 12, 0));
        LinearLayout col = ui.vertical();
        TextView t1 = ui.label(title, 15, p.text, true);
        t1.setSingleLine(true);
        t1.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView t2 = ui.label(text, 14, p.sub, false);
        t2.setSingleLine(true);
        t2.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(t1);
        col.addView(t2);
        card.addView(col, ui.lpw(0, Ui.WRAP, 1f));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.TOP);
        lp.setMargins(ui.dp(12), ui.dp(10), ui.dp(12), 0);
        overlay.addView(card, lp);
        bannerView = card;
        card.setTranslationY(-ui.dp(120));
        card.animate().translationY(0).setDuration(220).start();
        card.setOnClickListener(v -> {
            hideBanner();
            if (onClick != null) onClick.run();
        });
        bannerHide = this::hideBanner;
        h.postDelayed(bannerHide, 4500);
    }

    private void hideBanner() {
        final View v = bannerView;
        if (v == null) return;
        bannerView = null;
        if (bannerHide != null) h.removeCallbacks(bannerHide);
        v.animate().translationY(-ui.dp(140)).setDuration(180).withEndAction(() -> overlay.removeView(v)).start();
    }

    /** Короткая подпись снизу («Скопировано»). */
    void toast(String s) {
        if (toastView != null) {
            overlay.removeView(toastView);
            if (toastHide != null) h.removeCallbacks(toastHide);
        }
        TextView t = ui.label(s, 14, Session.dark ? Color.BLACK : Color.WHITE, true);
        t.setBackground(ui.rounded(Session.dark ? 0xFFEDEDED : 0xFF2A2A2C, 20));
        t.setPadding(ui.dp(18), ui.dp(11), ui.dp(18), ui.dp(11));
        t.setElevation(ui.dp(8));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = ui.dp(112);
        overlay.addView(t, lp);
        toastView = t;
        t.setAlpha(0f);
        t.animate().alpha(1f).setDuration(150).start();
        final View tv = t;
        toastHide = () -> tv.animate().alpha(0f).setDuration(250).withEndAction(() -> {
            overlay.removeView(tv);
            if (toastView == tv) toastView = null;
        }).start();
        h.postDelayed(toastHide, 2200);
    }

    // ------------------------------------------------------------------ мелочи для экранов

    void pickImage(Screen owner, int req) {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            pickOwner = owner;
            pickReq = req;
            startActivityForResult(Intent.createChooser(i, getString(R.string.pick_image)), REQ_PICK);
        } catch (Exception e) {
            pickOwner = null;
            toast(getString(R.string.err_no_gallery));
        }
    }

    void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("FlauGram", s));
            toast(getString(R.string.copied));
        }
    }

    void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    void cancelNotification(Model.Row r) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(r.isChat() ? PollService.chatTag(r.chatId) : PollService.tag(r.user), PollService.MSG_ID);
    }

    void openUri(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast(getString(R.string.err_no_browser));
        }
    }
}
