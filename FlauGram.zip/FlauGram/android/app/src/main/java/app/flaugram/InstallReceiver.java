package app.flaugram;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

/** Получает от системы результат установки обновления. */
public class InstallReceiver extends BroadcastReceiver {
    static final String ACTION = "app.flaugram.INSTALL_RESULT";

    @Override
    @SuppressWarnings("deprecation")
    public void onReceive(Context c, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm == null) return;
            Updater.onPending();
            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (MainActivity.visible) {
                try {
                    c.startActivity(confirm);
                    return;
                } catch (Exception ignored) {
                    // покажем уведомление
                }
            }
            Updater.Info i = Updater.info;
            Updater.notifyUser(c, c.getString(R.string.update_ready_title, i == null ? "" : i.name),
                    c.getString(R.string.update_tap_install),
                    PendingIntent.getActivity(c, 8, confirm, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            return;
        }
        Updater.onInstallResult(c, status, msg);
    }
}
