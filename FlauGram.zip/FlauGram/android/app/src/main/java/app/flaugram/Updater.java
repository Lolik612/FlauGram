package app.flaugram;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Проверка обновлений через GitHub Releases. Сборка в GitHub Actions публикует релиз с тегом v&lt;versionCode&gt;
 * и файлом FlauGram.apk. Приложение смотрит последний релиз и, если там версия новее, предлагает скачать.
 */
final class Updater {
    private Updater() { }

    static final class Info {
        int code;
        String name = "";
        String url = "";
    }

    static boolean enabled() {
        return BuildConfig.GITHUB_REPO.length() > 0;
    }

    /** Блокирующий вызов. Возвращает null при ошибке сети; Info с code == 0, если релизов нет. */
    static Info check() {
        if (!enabled()) return null;
        Api.Res r = Api.getJsonUrl("https://api.github.com/repos/" + BuildConfig.GITHUB_REPO + "/releases/latest", 10000);
        if (r.netFail) return null;
        Info i = new Info();
        if (r.code != 200 || r.json == null) return r.code == 404 ? i : null;
        String tag = r.json.optString("tag_name", "");
        if (tag.startsWith("v")) tag = tag.substring(1);
        try {
            i.code = Integer.parseInt(tag.trim());
        } catch (NumberFormatException e) {
            return i;
        }
        i.name = r.json.optString("name", tag);
        i.url = "https://github.com/" + BuildConfig.GITHUB_REPO + "/releases/latest/download/FlauGram.apk";
        JSONArray assets = r.json.optJSONArray("assets");
        if (assets != null) {
            for (int k = 0; k < assets.length(); k++) {
                JSONObject a = assets.optJSONObject(k);
                if (a != null && a.optString("name").endsWith(".apk") && a.optString("browser_download_url").length() > 0) {
                    i.url = a.optString("browser_download_url");
                    break;
                }
            }
        }
        return i;
    }

    static boolean isNewer(Info i) {
        return i != null && i.code > BuildConfig.VERSION_CODE;
    }
}
