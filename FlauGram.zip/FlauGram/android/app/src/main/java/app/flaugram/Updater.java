package app.flaugram;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Обновление приложения. Сборка в GitHub Actions публикует релиз v&lt;versionCode&gt; с файлом FlauGram.apk.
 * Приложение проверяет релиз, скачивает APK и ставит его через PackageInstaller.
 * Android 12+ может поставить обновление без вопроса, если приложение уже ставило само себя;
 * в остальных случаях нужно одно нажатие «Установить» в системном окне.
 */
final class Updater {
    private Updater() { }

    static final int IDLE = 0, CHECKING = 1, LATEST = 2, AVAILABLE = 3, DOWNLOADING = 4, READY = 5, INSTALLING = 6, ERROR = 7;
    static final String CHANNEL = "fg_updates";
    private static final long CHECK_EVERY_MS = 6L * 60 * 60 * 1000;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static final class Info {
        int code;
        String name = "";
        String url = "";
        String notes = "";
    }

    static volatile int state = IDLE;
    static volatile int progress;
    static volatile Info info;
    static volatile String error = "";
    static volatile Runnable listener;
    private static boolean busy;

    static boolean enabled() {
        return BuildConfig.GITHUB_REPO.length() > 0;
    }

    static boolean isNewer(Info i) {
        return i != null && i.code > BuildConfig.VERSION_CODE;
    }

    static boolean auto(Context c) {
        return c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getBoolean("auto_update", true);
    }

    static void setAuto(Context c, boolean on) {
        c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putBoolean("auto_update", on).apply();
    }

    private static void set(int s) {
        state = s;
        Runnable l = listener;
        if (l != null) MAIN.post(l);
    }

    static File apkFile(Context c) {
        File d = new File(c.getCacheDir(), "update");
        if (!d.exists()) d.mkdirs();
        return new File(d, "FlauGram.apk");
    }

    static boolean canInstall(Context c) {
        return Build.VERSION.SDK_INT < 26 || c.getPackageManager().canRequestPackageInstalls();
    }

    static Intent permissionIntent(Context c) {
        return new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.getPackageName()));
    }

    // ------------------------------------------------------------------ проверка

    /** Блокирующий вызов. null при ошибке сети; Info с code == 0, если релизов ещё нет. */
    static Info check() {
        if (!enabled()) return null;
        Api.Res r = Api.getJsonUrl("https://api.github.com/repos/" + BuildConfig.GITHUB_REPO + "/releases/latest", 12000);
        if (r.netFail) return null;
        Info i = new Info();
        if (r.code != 200 || r.json == null) return r.code == 404 ? i : null;
        String tag = r.json.optString("tag_name", "");
        if (tag.startsWith("v")) tag = tag.substring(1);
        try {
            i.code = Integer.parseInt(tag.trim());
        } catch (NumberFormatException e) {
            return i;
        }
        i.name = r.json.optString("name", tag);
        i.notes = r.json.optString("body", "");
        i.url = "https://github.com/" + BuildConfig.GITHUB_REPO + "/releases/latest/download/FlauGram.apk";
        JSONArray assets = r.json.optJSONArray("assets");
        if (assets != null) {
            for (int k = 0; k < assets.length(); k++) {
                JSONObject a = assets.optJSONObject(k);
                if (a != null && a.optString("name").endsWith(".apk") && a.optString("browser_download_url").length() > 0) {
                    i.url = a.optString("browser_download_url");
                    break;
                }
            }
        }
        return i;
    }

    /** При запуске приложения: проверка, если прошло больше получаса с прошлой. */
    static void onAppStart(final Context c) {
        if (!enabled()) return;
        final Context app = c.getApplicationContext();
        if (state == IDLE) {
            File f = apkFile(app);
            if (f.exists() && !isUsable(app, f)) f.delete();
        }
        long last = app.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getLong("upd_checked", 0);
        if (System.currentTimeMillis() - last < 30L * 60 * 1000 && state != IDLE) return;
        if (System.currentTimeMillis() - last < 30L * 60 * 1000 && info == null && !hasPending(app)) return;
        new Thread(() -> run(app, false)).start();
    }

    private static boolean hasPending(Context c) {
        return c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getBoolean("upd_pending", false);
    }

    /** Из фоновой службы. Проверяет не чаще раза в несколько часов и, если включено, ставит сама. */
    static void background(final Context c) {
        if (!enabled()) return;
        long last = c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getLong("upd_checked", 0);
        if (System.currentTimeMillis() - last < CHECK_EVERY_MS) return;
        run(c.getApplicationContext(), false);
    }

    /** Ручная проверка из настроек: сразу скачивает и ставит, если есть новее. */
    static void manual(final Context c) {
        final Context app = c.getApplicationContext();
        new Thread(() -> run(app, true)).start();
    }

    /** Блокирующая проверка. Если найдена новая версия и (force или включено автообновление), скачивает и ставит. */
    static void run(Context c, boolean force) {
        synchronized (Updater.class) {
            if (busy) return;
            busy = true;
        }
        try {
            if (state == DOWNLOADING || state == INSTALLING) return;
            set(CHECKING);
            Info i = check();
            if (i == null) {
                error = c.getString(R.string.err_server_down);
                set(force ? ERROR : IDLE);
                return;
            }
            c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putLong("upd_checked", System.currentTimeMillis()).apply();
            if (!isNewer(i)) {
                info = null;
                c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putBoolean("upd_pending", false).apply();
                set(LATEST);
                return;
            }
            c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putBoolean("upd_pending", true).apply();
            info = i;
            set(AVAILABLE);
            if (force || auto(c)) downloadAndInstall(c);
        } finally {
            synchronized (Updater.class) {
                busy = false;
            }
        }
    }

    // ------------------------------------------------------------------ скачивание и установка

    /** Кнопка «Обновить» в настройках. */
    static void installNow(final Context c) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            synchronized (Updater.class) {
                if (busy) return;
                busy = true;
            }
            try {
                if (info == null) return;
                downloadAndInstall(app);
            } finally {
                synchronized (Updater.class) {
                    busy = false;
                }
            }
        }).start();
    }

    private static boolean isUsable(Context c, File f) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (pi == null || !c.getPackageName().equals(pi.packageName)) return false;
            long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            return code > BuildConfig.VERSION_CODE;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void fail(Context c, String text) {
        error = text;
        set(ERROR);
    }

    private static void downloadAndInstall(Context c) {
        Info i = info;
        if (i == null) return;
        File f = apkFile(c);
        if (!(f.exists() && isUsable(c, f))) {
            progress = 0;
            set(DOWNLOADING);
            if (!download(i.url, f)) {
                f.delete();
                fail(c, c.getString(R.string.update_failed_download));
                return;
            }
            if (!isUsable(c, f)) {
                f.delete();
                fail(c, c.getString(R.string.update_bad_file));
                return;
            }
        }
        set(READY);
        if (!canInstall(c)) {
            notifyUser(c, c.getString(R.string.update_ready_title, i.name), c.getString(R.string.update_need_permission),
                    PendingIntent.getActivity(c, 7, new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            return;
        }
        commit(c, f);
    }

    /** Установить уже скачанный файл (после выдачи разрешения). */
    static void installReady(final Context c) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            File f = apkFile(app);
            if (f.exists() && isUsable(app, f) && canInstall(app)) commit(app, f);
            else if (info != null) installNow(app);
        }).start();
    }

    private static boolean download(String url, File out) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "FlauGram");
            if (conn.getResponseCode() != 200) return false;
            long total = conn.getContentLength();
            InputStream in = conn.getInputStream();
            OutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[32768];
            long done = 0;
            int n, lastPct = -1;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                done += n;
                if (total > 0) {
                    int pct = (int) (done * 100 / total);
                    if (pct != lastPct) {
                        lastPct = pct;
                        progress = pct;
                        Runnable l = listener;
                        if (l != null) MAIN.post(l);
                    }
                }
            }
            os.close();
            in.close();
            return out.length() > 100 * 1024;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static void commit(Context c, File f) {
        try {
            set(INSTALLING);
            PackageInstaller pi = c.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            sp.setAppPackageName(c.getPackageName());
            if (Build.VERSION.SDK_INT >= 31) {
                sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
            }
            int id = pi.createSession(sp);
            PackageInstaller.Session s = pi.openSession(id);
            try {
                OutputStream out = s.openWrite("flaugram", 0, f.length());
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                s.fsync(out);
                out.close();
                Intent it = new Intent(c, InstallReceiver.class).setAction(InstallReceiver.ACTION);
                PendingIntent pend = PendingIntent.getBroadcast(c, id, it,
                        PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0));
                s.commit(pend.getIntentSender());
            } finally {
                s.close();
            }
        } catch (Exception e) {
            fail(c, c.getString(R.string.update_install_failed));
        }
    }

    /** Результат установки пришёл от системы (см. InstallReceiver). */
    static void onInstallResult(Context c, int status, String message) {
        if (status == PackageInstaller.STATUS_SUCCESS) {
            set(IDLE);
        } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            set(AVAILABLE);
        } else {
            fail(c, c.getString(R.string.update_install_failed) + (message == null || message.isEmpty() ? "" : " (" + message + ")"));
        }
    }

    // ------------------------------------------------------------------ уведомление

    static void notifyUser(Context c, String title, String text, PendingIntent tap) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, c.getString(R.string.update_channel), NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(c, CHANNEL);
        } else {
            b = new Notification.Builder(c);
        }
        b.setSmallIcon(R.drawable.ic_notify).setContentTitle(title).setContentText(text).setAutoCancel(true);
        if (tap != null) b.setContentIntent(tap);
        try {
            nm.notify(4040, b.build());
        } catch (Exception ignored) {
            // нет разрешения на уведомления
        }
    }
}
