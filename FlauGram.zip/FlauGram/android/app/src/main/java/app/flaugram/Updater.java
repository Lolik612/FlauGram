package app.flaugram;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

/**
 * Обновление приложения. Источники по порядку:
 * 1) наш сервер (/app/version и /app/apk, он сам зеркалит релиз с GitHub, лимитов нет);
 * 2) GitHub Releases (api.github.com).
 * Если один источник не отвечает, берётся другой. Установка: PackageInstaller, а если система
 * молчит или человек закрыл окно, состояние не зависает: есть повтор, ручная установка файла
 * и скачивание в браузере.
 */
final class Updater {
    private Updater() { }

    static final int IDLE = 0, CHECKING = 1, LATEST = 2, AVAILABLE = 3, DOWNLOADING = 4, READY = 5, INSTALLING = 6, ERROR = 7;
    static final String CHANNEL = "fg_updates";
    private static final long CHECK_EVERY_MS = 6L * 60 * 60 * 1000;
    private static final long INSTALL_WAIT_MS = 45 * 1000;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static final class Info {
        int code;
        String name = "";
        String notes = "";
        long size;
        String sha256 = "";
        /** Адреса файла по порядку: сервер, потом GitHub. */
        final List<String> urls = new ArrayList<>();
        /** Ссылка для ручного скачивания в браузере. */
        String browserUrl = "";
    }

    static volatile int state = IDLE;
    static volatile int progress;
    static volatile Info info;
    static volatile String error = "";
    static volatile Runnable listener;
    private static boolean busy;
    private static int installToken;

    static boolean enabled() {
        return true;
    }

    static boolean isNewer(Info i) {
        return i != null && i.code > BuildConfig.VERSION_CODE;
    }

    static boolean auto(Context c) {
        return c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getBoolean("auto_update", true);
    }

    static void setAuto(Context c, boolean on) {
        c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putBoolean("auto_update", on).apply();
    }

    private static void set(int s) {
        state = s;
        Runnable l = listener;
        if (l != null) MAIN.post(l);
    }

    static File apkFile(Context c) {
        File d = new File(c.getCacheDir(), "update");
        if (!d.exists()) d.mkdirs();
        return new File(d, "FlauGram.apk");
    }

    static boolean canInstall(Context c) {
        return Build.VERSION.SDK_INT < 26 || c.getPackageManager().canRequestPackageInstalls();
    }

    static Intent permissionIntent(Context c) {
        return new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.getPackageName()));
    }

    // ------------------------------------------------------------------ проверка

    private static Info fromServer() {
        Api.Res r = Api.call("GET", "/app/version", null, null, 8000);
        if (r.netFail || r.code != 200 || r.json == null) return null;
        Info i = new Info();
        i.code = r.json.optInt("code", 0);
        if (i.code <= 0) return null;       // зеркало ещё пустое
        i.name = r.json.optString("name", "v" + i.code);
        i.notes = r.json.optString("notes", "");
        i.size = r.json.optLong("size", 0);
        i.sha256 = r.json.optString("sha256", "");
        i.urls.add(BuildConfig.SERVER_URL + "/app/apk");
        i.browserUrl = BuildConfig.SERVER_URL + "/app/apk";
        return i;
    }

    private static Info fromGithub() {
        if (BuildConfig.GITHUB_REPO.length() == 0) return null;
        Api.Res r = Api.getJsonUrl("https://api.github.com/repos/" + BuildConfig.GITHUB_REPO + "/releases/latest", 10000);
        if (r.netFail || r.code != 200 || r.json == null) return null;   // 403/429 = лимит API, тоже «нет ответа»
        String tag = r.json.optString("tag_name", "");
        if (tag.startsWith("v")) tag = tag.substring(1);
        Info i = new Info();
        try {
            i.code = Integer.parseInt(tag.trim());
        } catch (NumberFormatException e) {
            return null;
        }
        i.name = r.json.optString("name", tag);
        i.notes = r.json.optString("body", "");
        String url = "https://github.com/" + BuildConfig.GITHUB_REPO + "/releases/latest/download/FlauGram.apk";
        JSONArray assets = r.json.optJSONArray("assets");
        if (assets != null) {
            for (int k = 0; k < assets.length(); k++) {
                JSONObject a = assets.optJSONObject(k);
                if (a != null && a.optString("name").endsWith(".apk") && a.optString("browser_download_url").length() > 0) {
                    url = a.optString("browser_download_url");
                    i.size = a.optLong("size", 0);
                    break;
                }
            }
        }
        i.urls.add(url);
        i.browserUrl = url;
        return i;
    }

    /** Блокирующий вызов. null, если не ответил ни сервер, ни GitHub. */
    static Info check() {
        Info s = fromServer();
        Info g = fromGithub();
        if (s == null && g == null) return null;
        if (s == null) return g;
        if (g == null) return s;
        // оба ответили: берём более новую версию; файл ищем сначала в источнике новой версии
        if (g.code > s.code) {
            g.urls.add(s.code == g.code ? s.urls.get(0) : g.urls.get(0));
            return g;
        }
        if (s.code == g.code) s.urls.add(g.urls.get(0));
        return s;
    }

    private static boolean recentlyChecked(Context c, long ms) {
        return System.currentTimeMillis() - c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getLong("upd_checked", 0) < ms;
    }

    /** При запуске приложения: проверка, если прошло больше получаса с прошлой. */
    static void onAppStart(final Context c) {
        final Context app = c.getApplicationContext();
        if (state == IDLE) {
            File f = apkFile(app);
            if (f.exists() && !isUsable(app, f)) f.delete();
        }
        if (recentlyChecked(app, 30L * 60 * 1000) && (state != IDLE || info == null && !hasPending(app))) return;
        new Thread(() -> run(app, false)).start();
    }

    private static boolean hasPending(Context c) {
        return c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).getBoolean("upd_pending", false);
    }

    /** Из фоновой службы. Проверяет не чаще раза в несколько часов и, если включено, ставит сама. */
    static void background(final Context c) {
        if (recentlyChecked(c, CHECK_EVERY_MS)) return;
        run(c.getApplicationContext(), false);
    }

    /** Ручная проверка из настроек: сразу скачивает и ставит, если есть новее. */
    static void manual(final Context c) {
        final Context app = c.getApplicationContext();
        new Thread(() -> run(app, true)).start();
    }

    private static boolean enter() {
        synchronized (Updater.class) {
            if (busy) return false;
            busy = true;
            return true;
        }
    }

    private static void leave() {
        synchronized (Updater.class) {
            busy = false;
        }
    }

    /** Блокирующая проверка. Если найдена новая версия и (force или включено автообновление), скачивает и ставит. */
    static void run(Context c, boolean force) {
        if (!enter()) return;
        try {
            if (state == DOWNLOADING || state == INSTALLING && !force) return;
            set(CHECKING);
            Info i = check();
            if (i == null) {
                error = c.getString(R.string.update_check_failed);
                set(force ? ERROR : IDLE);
                return;
            }
            c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putLong("upd_checked", System.currentTimeMillis()).apply();
            if (!isNewer(i)) {
                info = null;
                c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putBoolean("upd_pending", false).apply();
                set(LATEST);
                return;
            }
            c.getSharedPreferences("flaugram", Context.MODE_PRIVATE).edit().putBoolean("upd_pending", true).apply();
            info = i;
            set(AVAILABLE);
            if (force || auto(c)) downloadAndInstall(c);
        } catch (Throwable t) {
            fail(c, c.getString(R.string.update_failed));
        } finally {
            leave();
        }
    }

    // ------------------------------------------------------------------ скачивание и установка

    /** Кнопка «Обновить» и «Повторить»: качает (если файла ещё нет) и ставит. */
    static void installNow(final Context c) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            if (!enter()) return;
            try {
                if (info == null) {
                    leave();
                    run(app, true);
                    return;
                }
                downloadAndInstall(app);
            } catch (Throwable t) {
                fail(app, app.getString(R.string.update_failed));
            } finally {
                leave();
            }
        }).start();
    }

    private static boolean isUsable(Context c, File f) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (pi == null || !c.getPackageName().equals(pi.packageName)) return false;
            long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            return code > BuildConfig.VERSION_CODE;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void fail(Context c, String text) {
        error = text;
        set(ERROR);
    }

    private static boolean fileOk(Info i, File f) {
        if (f.length() < 100 * 1024) return false;
        if (i.size > 0 && f.length() != i.size) return false;
        if (i.sha256.length() == 64) {
            String h = sha256(f);
            return h != null && h.equalsIgnoreCase(i.sha256);
        }
        return true;
    }

    private static String sha256(File f) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            in.close();
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private static void downloadAndInstall(Context c) {
        Info i = info;
        if (i == null) return;
        File f = apkFile(c);
        if (!(f.exists() && isUsable(c, f) && fileOk(i, f))) {
            f.delete();
            boolean got = false, bad = false;
            for (String url : i.urls) {
                progress = 0;
                set(DOWNLOADING);
                File tmp = new File(f.getParentFile(), "FlauGram.apk.part");
                if (!download(url, tmp)) {
                    tmp.delete();
                    continue;
                }
                if (!fileOk(i, tmp) || !isUsable(c, tmp)) {
                    tmp.delete();
                    bad = true;
                    continue;
                }
                got = tmp.renameTo(f);
                if (got) break;
            }
            if (!got) {
                fail(c, c.getString(bad ? R.string.update_bad_file : R.string.update_failed_download));
                return;
            }
        }
        set(READY);
        if (!canInstall(c)) {
            notifyUser(c, c.getString(R.string.update_ready_title, i.name), c.getString(R.string.update_need_permission),
                    PendingIntent.getActivity(c, 7, new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            return;
        }
        commit(c, f);
    }

    /** Установить уже скачанный файл (после выдачи разрешения). */
    static void installReady(final Context c) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            File f = apkFile(app);
            if (f.exists() && isUsable(app, f) && canInstall(app)) commit(app, f);
            else installNow(app);
        }).start();
    }

    private static boolean download(String url, File out) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "FlauGram");
            if (conn.getResponseCode() != 200) return false;
            long total = conn.getContentLength();
            InputStream in = conn.getInputStream();
            OutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[32768];
            long done = 0;
            int n, lastPct = -1;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                done += n;
                if (total > 0) {
                    int pct = (int) (done * 100 / total);
                    if (pct != lastPct) {
                        lastPct = pct;
                        progress = pct;
                        Runnable l = listener;
                        if (l != null) MAIN.post(l);
                    }
                }
            }
            os.close();
            in.close();
            return out.length() > 100 * 1024 && (total <= 0 || out.length() == total);
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static void commit(final Context c, File f) {
        try {
            set(INSTALLING);
            PackageInstaller pi = c.getPackageManager().getPackageInstaller();
            // зависшие сессии прошлых попыток мешают новой
            try {
                for (PackageInstaller.SessionInfo si : pi.getMySessions()) pi.abandonSession(si.getSessionId());
            } catch (Exception ignored) {
                // не критично
            }
            PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            sp.setAppPackageName(c.getPackageName());
            if (Build.VERSION.SDK_INT >= 31) {
                sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
            }
            int id = pi.createSession(sp);
            PackageInstaller.Session s = pi.openSession(id);
            try {
                OutputStream out = s.openWrite("flaugram", 0, f.length());
                FileInputStream in = new FileInputStream(f);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                s.fsync(out);
                out.close();
                Intent it = new Intent(c, InstallReceiver.class).setAction(InstallReceiver.ACTION);
                PendingIntent pend = PendingIntent.getBroadcast(c, id, it,
                        PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0));
                s.commit(pend.getIntentSender());
            } finally {
                s.close();
            }
            // Сторож: если система не ответила, не оставляем «Устанавливаю…» навсегда
            final int my = ++installToken;
            MAIN.postDelayed(() -> {
                if (my == installToken && state == INSTALLING) {
                    error = c.getString(R.string.update_stuck);
                    set(ERROR);
                }
            }, INSTALL_WAIT_MS);
        } catch (Exception e) {
            fail(c, c.getString(R.string.update_install_failed));
        }
    }

    /** Система просит подтверждение (окно «Установить?»): ждём человека, сторож не нужен. */
    static void onPending() {
        installToken++;
        if (state == INSTALLING) set(READY);
    }

    /** Результат установки пришёл от системы (см. InstallReceiver). */
    static void onInstallResult(Context c, int status, String message) {
        installToken++;
        if (status == PackageInstaller.STATUS_SUCCESS) {
            set(IDLE);
        } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            set(info != null ? AVAILABLE : IDLE);
        } else {
            fail(c, c.getString(R.string.update_install_failed) + (message == null || message.isEmpty() ? "" : " (" + message + ")"));
        }
    }

    // ------------------------------------------------------------------ запасные способы

    /** Установка скачанного файла обычным системным установщиком (запасной путь). */
    static boolean installManually(Context c) {
        File f = apkFile(c);
        if (!f.exists() || !isUsable(c, f)) return false;
        try {
            Uri u = Uri.parse("content://" + ApkProvider.AUTHORITY + "/FlauGram.apk");
            Intent it = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(it);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Скачивание файла браузером (запасной путь, когда не работает ничего другое). */
    static boolean openInBrowser(Context c) {
        Info i = info;
        String url = i != null && i.browserUrl.length() > 0 ? i.browserUrl
                : "https://github.com/" + BuildConfig.GITHUB_REPO + "/releases/latest";
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean hasFile(Context c) {
        File f = apkFile(c);
        return f.exists() && isUsable(c, f);
    }

    // ------------------------------------------------------------------ уведомление

    static void notifyUser(Context c, String title, String text, PendingIntent tap) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, c.getString(R.string.update_channel), NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(c, CHANNEL);
        } else {
            b = new Notification.Builder(c);
        }
        b.setSmallIcon(R.drawable.ic_notify).setContentTitle(title).setContentText(text).setAutoCancel(true);
        if (tap != null) b.setContentIntent(tap);
        try {
            nm.notify(4040, b.build());
        } catch (Exception ignored) {
            // нет разрешения на уведомления
        }
    }
}
