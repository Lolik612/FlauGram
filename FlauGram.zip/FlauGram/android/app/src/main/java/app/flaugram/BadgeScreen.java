package app.flaugram;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Настройка значка подтверждения: заготовленная иконка или своя из галереи, текст при нажатии. */
final class BadgeScreen extends Screen {
    private static final int REQ_BADGE = 4;

    private final Model.Row u;
    private String kind = "check";
    private String text = "";
    private long customVer;
    private boolean verified;
    private boolean loaded;
    private NameLine preview;
    private TextView previewText;
    private LinearLayout grid;
    private EditText textEd;
    private Toggle toggle;
    private LinearLayout toggleRow, customTile;
    private ImageView customImg;

    BadgeScreen(MainActivity a, Model.Row user) {
        super(a);
        this.u = user;
    }

    @Override
    View build() {
        LinearLayout root = ui.vertical();
        root.setBackgroundColor(p.bg);
        root.addView(topBar(ui.t(R.string.badge_title), null), ui.lp(Ui.MATCH, Ui.WRAP));
        ScrollView sv = new ScrollView(a);
        LinearLayout col = ui.vertical();
        col.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(30));

        // предпросмотр
        LinearLayout pv = ui.card();
        pv.setGravity(Gravity.CENTER_HORIZONTAL);
        pv.setPadding(ui.dp(16), ui.dp(20), ui.dp(16), ui.dp(18));
        AvatarView av = new AvatarView(a, ui.dp(72), ui.dp(130));
        av.bind(u);
        av.setGlow(u.avatar > 0 ? 0xFFFFFFFF : Images.nameColor(u.user));
        pv.addView(av, ui.lp(ui.dp(130), ui.dp(130)));
        preview = new NameLine(a, 21, p.text, true, 20).center();
        pv.addView(preview, ui.lpm(Ui.WRAP, Ui.WRAP, 0, 0, 0, 0));
        previewText = ui.label("", 14, p.sub, false);
        previewText.setGravity(Gravity.CENTER);
        previewText.setPadding(ui.dp(10), ui.dp(8), ui.dp(10), 0);
        pv.addView(previewText, ui.lp(Ui.MATCH, Ui.WRAP));
        col.addView(pv, ui.lp(Ui.MATCH, Ui.WRAP));

        // включить или выключить
        toggle = new Toggle(a, p.accent, 0xFF48484A, false);
        toggleRow = ui.settingRow(R.drawable.ic_verified, 0xFF0A84FF, ui.t(R.string.badge_enabled), ui.t(R.string.badge_enabled_sub), toggle);
        toggleRow.setBackground(ui.ripple(p.surface, 22));
        toggle.setListener(on -> {
            verified = on;
            refresh();
        });
        toggleRow.setOnClickListener(v -> toggle.set(!toggle.isOn(), true));
        col.addView(toggleRow, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        if (u.isOwnerAccount || u.user.equalsIgnoreCase(Session.me)) toggleRow.setVisibility(View.GONE);

        // иконки
        TextView l1 = sectionLabel(ui.t(R.string.badge_icon));
        l1.setPadding(ui.dp(6), ui.dp(18), 0, ui.dp(8));
        col.addView(l1);
        grid = ui.vertical();
        col.addView(grid, ui.lp(Ui.MATCH, Ui.WRAP));

        // своя картинка
        customTile = ui.horizontal();
        customTile.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        customTile.setClickable(true);
        customImg = new ImageView(a);
        customImg.setScaleType(ImageView.ScaleType.FIT_CENTER);
        customTile.addView(customImg, ui.lpm(ui.dp(34), ui.dp(34), 0, 0, 14, 0));
        LinearLayout ct = ui.vertical();
        ct.addView(ui.label(ui.t(R.string.badge_custom), 16, p.text, true));
        ct.addView(ui.label(ui.t(R.string.badge_custom_sub), 13, p.sub, false));
        customTile.addView(ct, ui.lpw(0, Ui.WRAP, 1f));
        customTile.addView(ui.icon(R.drawable.ic_upload, 22, p.accent));
        col.addView(customTile, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        customTile.setOnClickListener(v -> {
            if (customVer > 0 && !"custom".equals(kind)) {
                kind = "custom";
                refresh();
            } else {
                a.pickImage(this, REQ_BADGE);
            }
        });
        customTile.setOnLongClickListener(v -> {
            a.pickImage(this, REQ_BADGE);
            return true;
        });

        // текст
        TextView l2 = sectionLabel(ui.t(R.string.badge_text));
        l2.setPadding(ui.dp(6), ui.dp(18), 0, ui.dp(8));
        col.addView(l2);
        textEd = ui.edit(ui.t(R.string.badge_text_hint, u.user));
        textEd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        textEd.setMinLines(2);
        textEd.setGravity(Gravity.TOP);
        textEd.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        textEd.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void afterTextChanged(Editable e) {
                text = e.toString().trim();
                refreshPreview();
            }
        });
        col.addView(textEd, ui.lp(Ui.MATCH, Ui.WRAP));

        TextView save = ui.button(ui.t(R.string.save));
        save.setOnClickListener(v -> save());
        col.addView(save, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 18, 0, 0));

        sv.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(sv, ui.lpw(Ui.MATCH, 0, 1f));
        refresh();
        return root;
    }

    @Override
    void onShow() {
        if (loaded) return;
        loaded = true;
        a.api("GET", "/user?name=" + Api.enc(u.user), null, r -> {
            if (r.code != 200 || r.json == null) return;
            Model.Row n = Model.user(r.json);
            if (n == null) return;
            u.badge = n.badge;
            u.isOwnerAccount = n.isOwnerAccount;
            verified = n.badge != null;
            if (n.badge != null) {
                kind = n.badge.kind;
                text = n.badge.text;
                customVer = "custom".equals(n.badge.kind) ? n.badge.ver : customVer;
            }
            toggle.set(verified, false);
            textEd.setText(text);
            refresh();
        });
    }

    private Model.Badge current() {
        if (!verified && !u.isOwnerAccount && !u.user.equalsIgnoreCase(Session.me)) return null;
        Model.Badge b = new Model.Badge();
        b.kind = kind;
        b.text = text;
        b.ver = customVer;
        b.owner = u.isOwnerAccount;
        return b;
    }

    private void refreshPreview() {
        Model.Badge b = current();
        preview.set(u.title(), u.user, b);
        preview.badge.setOnClickListener(null);
        preview.badge.setClickable(false);
        previewText.setText(b == null ? ui.t(R.string.badge_off) : BadgeView.message(a, u.user, b));
    }

    private void refresh() {
        refreshPreview();
        grid.removeAllViews();
        LinearLayout row = null;
        for (int i = 0; i < BadgeView.KINDS.length; i++) {
            if (i % 4 == 0) {
                row = ui.horizontal();
                grid.addView(row, ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            }
            final String k = BadgeView.KINDS[i];
            boolean sel = k.equals(kind);
            FrameLayout cell = new FrameLayout(a);
            GradientDrawable bg = ui.rounded(p.surface, 18);
            if (sel) bg.setStroke(ui.dp(2), p.accent);
            cell.setBackground(bg);
            cell.setClickable(true);
            ImageView iv = ui.icon(BadgeView.iconRes(k), 30, BadgeView.iconColor(p, k));
            cell.addView(iv, new FrameLayout.LayoutParams(ui.dp(30), ui.dp(30), Gravity.CENTER));
            cell.setOnClickListener(v -> {
                kind = k;
                refresh();
            });
            LinearLayout.LayoutParams lp = ui.lpm(0, ui.dp(64), 4, 0, 4, 0);
            lp.weight = 1f;
            row.addView(cell, lp);
        }
        GradientDrawable cbg = ui.rounded(p.surface, 18);
        if ("custom".equals(kind)) cbg.setStroke(ui.dp(2), p.accent);
        customTile.setBackground(cbg);
        if (customVer > 0) {
            customImg.setColorFilter(null);
            Images.badge(customImg, u.user, customVer, ui.dp(34), Session.token);
        } else {
            customImg.setTag(null);
            customImg.setImageDrawable(ui.drawable(R.drawable.ic_image, p.sub));
        }
    }

    @Override
    void onResult(int req, final Uri uri) {
        if (req != REQ_BADGE) return;
        a.toast(ui.t(R.string.preparing));
        a.io.execute(() -> {
            final Images.Encoded e = Images.encode(a, uri, 160, true, 120 * 1024);
            a.runOnUiThread(() -> {
                if (e == null) {
                    a.toast(ui.t(R.string.err_bad_image));
                    return;
                }
                a.apiBytes("/admin/badge_image?name=" + Api.enc(u.user), e.data, r -> {
                    Model.Row n = r.code == 200 && r.json != null ? Model.user(r.json) : null;
                    if (n == null || n.badge == null) {
                        a.toast(a.errText(r));
                        return;
                    }
                    Images.forget();
                    customVer = n.badge.ver;
                    kind = "custom";
                    refresh();
                });
            });
        });
    }

    private void save() {
        boolean on = verified || u.isOwnerAccount || u.user.equalsIgnoreCase(Session.me);
        a.api("POST", "/admin/verify", Api.obj("username", u.user, "verified", Boolean.valueOf(on), "kind", kind, "text", text), r -> {
            if (r.code == 200) {
                a.toast(ui.t(R.string.badge_saved));
                Images.forget();
                a.refreshMe();
                a.pop();
            } else if (r.code == 400) {
                a.toast(ui.t(R.string.badge_need_image));
            } else {
                a.toast(a.errText(r));
            }
        });
    }
}
