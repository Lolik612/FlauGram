package app.flaugram;

/** Цвета темы. Чёрная тема по умолчанию (как в референсе: тёмно-серый фон и светло-серые карточки). */
final class Palette {
    final boolean dark;
    final int bg, surface, card, nav, navSel, text, sub, accent, outBubble, inBubble, divider, danger, input, ok, scrim;

    private Palette(boolean dark, int bg, int surface, int card, int nav, int navSel, int text, int sub, int accent,
                    int outBubble, int inBubble, int divider, int danger, int input, int ok, int scrim) {
        this.dark = dark;
        this.bg = bg;
        this.surface = surface;
        this.card = card;
        this.nav = nav;
        this.navSel = navSel;
        this.text = text;
        this.sub = sub;
        this.accent = accent;
        this.outBubble = outBubble;
        this.inBubble = inBubble;
        this.divider = divider;
        this.danger = danger;
        this.input = input;
        this.ok = ok;
        this.scrim = scrim;
    }

    static Palette dark() {
        return new Palette(true,
                0xFF12162F,  // bg (глубокий тёмно-синий, как в референсе)
                0xFF1A1D3C,  // surface (карточки)
                0xFF272F5E,  // card (плитки действий)
                0xFF1C1E44,  // nav (плавающая панель)
                0xFF272F5E,  // navSel
                0xFFFFFFFF,  // text
                0xFF8189B3,  // sub
                0xFF5B84FF,  // accent
                0xFF3A5FE0,  // outBubble
                0xFF1F2350,  // inBubble
                0xFF242954,  // divider
                0xFFFF5A5F,  // danger
                0xFF1F2350,  // input
                0xFF3DDC84,  // ok (в сети)
                0xAA000000); // scrim
    }

    static Palette light() {
        return new Palette(false,
                0xFFF4F4F6,
                0xFFFFFFFF,
                0xFFE6E6EA,
                0xFFFFFFFF,
                0xFFE9E9EE,
                0xFF111111,
                0xFF70707A,
                0xFF2F6BFF,
                0xFF2F6BFF,
                0xFFFFFFFF,
                0xFFE3E3E8,
                0xFFD93025,
                0xFFFFFFFF,
                0xFF1DB954,
                0x66000000);
    }
}
