package app.flaugram;

/** Цвета темы. Чёрная тема по умолчанию (настоящий чёрный фон). */
final class Palette {
    final boolean dark;
    final int bg, bar, surface, text, sub, accent, outBubble, inBubble, divider, danger, input;

    private Palette(boolean dark, int bg, int bar, int surface, int text, int sub, int accent,
                    int outBubble, int inBubble, int divider, int danger, int input) {
        this.dark = dark;
        this.bg = bg;
        this.bar = bar;
        this.surface = surface;
        this.text = text;
        this.sub = sub;
        this.accent = accent;
        this.outBubble = outBubble;
        this.inBubble = inBubble;
        this.divider = divider;
        this.danger = danger;
        this.input = input;
    }

    static Palette dark() {
        return new Palette(true,
                0xFF000000,  // bg
                0xFF0B0B0C,  // bar
                0xFF121214,  // surface
                0xFFF2F2F2,  // text
                0xFF8E8E93,  // sub
                0xFF4C8DFF,  // accent
                0xFF2D5BD6,  // outBubble
                0xFF1C1C1E,  // inBubble
                0xFF1C1C1E,  // divider
                0xFFFF5A5F,  // danger
                0xFF1C1C1E); // input
    }

    static Palette light() {
        return new Palette(false,
                0xFFFFFFFF,
                0xFFF2F2F5,
                0xFFF5F5F7,
                0xFF111111,
                0xFF6B6B70,
                0xFF2F6BFF,
                0xFF2F6BFF,
                0xFFEDEDF0,
                0xFFE3E3E6,
                0xFFD93025,
                0xFFEDEDF0);
    }
}
