package app.flaugram;

/** Цвета темы. Чёрная тема по умолчанию (как в референсе: тёмно-серый фон и светло-серые карточки). */
final class Palette {
    final boolean dark;
    final int bg, surface, card, nav, navSel, text, sub, accent, outBubble, inBubble, divider, danger, input, ok, scrim;

    private Palette(boolean dark, int bg, int surface, int card, int nav, int navSel, int text, int sub, int accent,
                    int outBubble, int inBubble, int divider, int danger, int input, int ok, int scrim) {
        this.dark = dark;
        this.bg = bg;
        this.surface = surface;
        this.card = card;
        this.nav = nav;
        this.navSel = navSel;
        this.text = text;
        this.sub = sub;
        this.accent = accent;
        this.outBubble = outBubble;
        this.inBubble = inBubble;
        this.divider = divider;
        this.danger = danger;
        this.input = input;
        this.ok = ok;
        this.scrim = scrim;
    }

    static Palette dark() {
        return new Palette(true,
                0xFF161617,  // bg
                0xFF212123,  // surface (карточки в настройках)
                0xFF2E2E30,  // card (кнопки действий)
                0xFF1D1D1F,  // nav (плавающая панель)
                0xFF2F2F31,  // navSel
                0xFFFFFFFF,  // text
                0xFF9B9BA1,  // sub
                0xFF4C8DFF,  // accent
                0xFF2D5BD6,  // outBubble
                0xFF262628,  // inBubble
                0xFF2A2A2C,  // divider
                0xFFFF5A5F,  // danger
                0xFF262628,  // input
                0xFF3DDC84,  // ok (в сети)
                0xAA000000); // scrim
    }

    static Palette light() {
        return new Palette(false,
                0xFFF4F4F6,
                0xFFFFFFFF,
                0xFFE6E6EA,
                0xFFFFFFFF,
                0xFFE9E9EE,
                0xFF111111,
                0xFF70707A,
                0xFF2F6BFF,
                0xFF2F6BFF,
                0xFFFFFFFF,
                0xFFE3E3E8,
                0xFFD93025,
                0xFFFFFFFF,
                0xFF1DB954,
                0x66000000);
    }
}
