# FlauGram

FlauGram: один чат на весь мир. Ник вводится при первом запуске.

- `server/server.py` — HTTP-сервер на Python 3.8+, без зависимостей.
- `server/server.js` — то же самое на Node.js 18+ (любой из двух на выбор).
- `android/` — Android-приложение (Java, без сторонних библиотек).

## 1. Сервер

Нужна машина с публичным IP (VPS) и открытым портом.

    cd server
    PORT=8080 python3 server.py      # или: PORT=8080 node server.js

История хранится в `server/messages.jsonl` (последние 1000 сообщений).
Порт берётся из `PORT`, а если его нет, из `SERVER_PORT` (так делают Pterodactyl/Wispbyte).
Если сервер стоит за nginx или Cloudflare, запускай с `TRUST_PROXY=1`.

## 2. APK

Адрес сервера вшивается в APK при сборке.

1. Залей папку в репозиторий на GitHub.
2. Settings -> Secrets and variables -> Actions -> Variables -> New variable:
   `SERVER_URL` = `http://ТВОЙ_IP:ПОРТ` (необязательно: по умолчанию уже вшит `http://78.154.103.45:11630`)
3. Actions -> Build APK -> Run workflow.
4. Скачай `flaugram-apk` из результатов, внутри `app-debug.apk`.

Локально, если установлены Android SDK и Gradle 8.9+:

    cd android
    SERVER_URL=http://ТВОЙ_IP:8080 gradle assembleDebug

Файл: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Протокол

- `GET /messages` — последние 50 сообщений.
- `GET /messages?after=ID` — новые после ID; если новых нет, сервер держит запрос до 25 секунд.
- `POST /send` с телом `{"nick":"...","text":"..."}`.
