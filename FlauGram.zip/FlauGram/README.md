# FlauGram

Мессенджер с личными сообщениями. Регистрация по юзернейму, поиск людей, ответы на сообщения, чёрная тема.

- `server/server.py` — сервер на Python 3.8+, без зависимостей (хранит данные в SQLite).
- `android/` — Android-приложение (Java, без сторонних библиотек).

## 1. Сервер

    cd server
    python3 server.py

Порт берётся из `PORT`, а если его нет, из `SERVER_PORT` (так делают Pterodactyl/Wispbyte).
Данные лежат в `flaugram.db` рядом со скриптом, не удаляйте его.
За nginx или Cloudflare запускайте с `TRUST_PROXY=1`.

Проверка: откройте `http://АДРЕС:ПОРТ/health`, должно быть `flaugram ok`.

## 2. APK

Адрес сервера вшит в `android/app/build.gradle` (строка с `SERVER_URL`). Сменить можно там,
либо переменной `SERVER_URL` в GitHub: Settings -> Secrets and variables -> Actions -> Variables.

Сборка идёт на GitHub: файл `.github/workflows/build.yml` распаковывает `FlauGram.zip` и собирает APK.
Результат: Actions -> последний запуск -> Artifacts -> `flaugram-apk`.

Ключ подписи лежит в `android/app/flaugram.keystore`. Он один для всех сборок, не меняйте и не теряйте его:
без него Android не даст установить обновление поверх старой версии.

## 3. Обновление приложения

Новая версия ставится вручную: соберите APK на GitHub и установите его поверх старого, данные и вход сохранятся.
Это работает только потому, что все сборки подписаны одним ключом (`android/app/flaugram.keystore`).
Перед сборкой увеличьте `versionCode` в `android/app/build.gradle`.

## 4. Уведомления

Приложение держит фоновое соединение с сервером (в шторке висит тихое уведомление «Ждём новые сообщения») и показывает
уведомление о каждом новом сообщении, пока приложение закрыто. Нажатие открывает переписку.
Включить и выключить: меню (три точки) -> «Уведомления». Если на вашем телефоне сообщения приходят с задержкой,
откройте меню -> «Не засыпать в фоне» и отключите для FlauGram оптимизацию батареи.

## Протокол (кратко)

Все запросы, кроме `/health` и `/register`, идут с заголовком `Authorization: Bearer <токен>`.

- `POST /register` `{"username":"..."}` -> `{"token":"...","username":"..."}`
- `GET /me`, `GET /search?q=`, `GET /dialogs`, `GET /history?with=&limit=&before=`
- `POST /send` `{"to":"...","text":"...","reply_to":ID}`, `POST /read` `{"with":"...","upto":ID}`
- `GET /updates?after=ID` — long-poll, держит запрос до 25 секунд
